=========
Copyright
=========

.. include:: ../../COPYRIGHT.rst
