import copy
import json
import pickle

from collections.abc import Callable
from datetime import datetime
from textwrap import dedent
from typing import Any

import pytest

import tomlkit

from tests.util import assert_is_ppo
from tomlkit import parse
from tomlkit import ws
from tomlkit._utils import _utc
from tomlkit.api import document
from tomlkit.exceptions import NonExistentKey
from tomlkit.exceptions import ParseError
from tomlkit.exceptions import TOMLKitError
from tomlkit.toml_document import TOMLDocument


def test_document_is_a_dict(example: Callable[[str], str]) -> None:
    content = example("example")

    doc = parse(content)

    assert isinstance(doc, dict)
    assert "owner" in doc

    # owner
    owner = doc["owner"]
    assert doc.get("owner") == owner
    assert isinstance(owner, dict)
    assert "name" in owner
    assert owner["name"] == "Tom Preston-Werner"
    assert owner["organization"] == "GitHub"
    assert owner["bio"] == "GitHub Cofounder & CEO\nLikes tater tots and beer."
    assert owner["dob"] == datetime(1979, 5, 27, 7, 32, tzinfo=_utc)

    # database
    database = doc["database"]
    assert isinstance(database, dict)
    assert database["server"] == "192.168.1.1"
    assert database["ports"] == [8001, 8001, 8002]
    assert database["connection_max"] == 5000
    assert database["enabled"] is True

    # servers
    servers = doc["servers"]
    assert isinstance(servers, dict)

    alpha = servers["alpha"]
    assert servers.get("alpha") == alpha
    assert isinstance(alpha, dict)
    assert alpha["ip"] == "10.0.0.1"
    assert alpha["dc"] == "eqdc10"

    beta = servers["beta"]
    assert isinstance(beta, dict)
    assert beta["ip"] == "10.0.0.2"
    assert beta["dc"] == "eqdc10"
    assert beta["country"] == "中国"

    # clients
    clients = doc["clients"]
    assert isinstance(clients, dict)

    data = clients["data"]
    assert isinstance(data, list)
    assert data[0] == ["gamma", "delta"]
    assert data[1] == [1, 2]

    assert clients["hosts"] == ["alpha", "omega"]

    # Products
    products = doc["products"]
    assert isinstance(products, list)

    hammer = products[0]
    assert hammer == {"name": "Hammer", "sku": 738594937}

    nail = products[1]
    assert nail["name"] == "Nail"
    assert nail["sku"] == 284758393
    assert nail["color"] == "gray"

    nail["color"] = "black"
    assert nail["color"] == "black"
    assert doc["products"][1]["color"] == "black"
    assert nail.get("color") == "black"

    content = """foo = "bar"
"""

    doc = parse(content)
    doc.update({"bar": "baz"})

    assert (
        doc.as_string()
        == """foo = "bar"
bar = "baz"
"""
    )

    doc.update({"bar": "boom"})

    assert (
        doc.as_string()
        == """foo = "bar"
bar = "boom"
"""
    )

    assert doc.setdefault("bar", "waldo") == "boom"

    assert (
        doc.as_string()
        == """foo = "bar"
bar = "boom"
"""
    )

    assert doc.setdefault("thud", "waldo") == "waldo"

    assert (
        doc.as_string()
        == """foo = "bar"
bar = "boom"
thud = "waldo"
"""
    )


def test_toml_document_without_super_tables() -> None:
    content = """[tool.poetry]
name = "foo"
"""

    doc = parse(content)
    assert "tool" in doc
    assert "poetry" in doc["tool"]

    assert doc["tool"]["poetry"]["name"] == "foo"

    doc["tool"]["poetry"]["name"] = "bar"

    assert (
        doc.as_string()
        == """[tool.poetry]
name = "bar"
"""
    )

    d: dict[str, Any] = {}
    d.update(doc)

    assert "tool" in d


def test_toml_document_unwrap() -> None:
    content = """[tool.poetry]
name = "foo"
"""

    doc = parse(content)
    unwrapped = doc.unwrap()
    assert_is_ppo(unwrapped, dict)
    assert_is_ppo(next(iter(unwrapped)), str)
    assert_is_ppo(unwrapped["tool"], dict)
    assert_is_ppo(next(iter(unwrapped["tool"])), str)
    assert_is_ppo(unwrapped["tool"]["poetry"]["name"], str)


def test_toml_document_with_dotted_keys(example: Callable[[str], str]) -> None:
    content = example("0.5.0")

    doc = parse(content)

    assert "physical" in doc
    assert "color" in doc["physical"]
    assert "shape" in doc["physical"]
    assert doc["physical"]["color"] == "orange"
    assert doc["physical"]["shape"] == "round"

    assert "site" in doc
    assert "google.com" in doc["site"]
    assert doc["site"]["google.com"]

    assert doc["a"]["b"]["c"] == 1
    assert doc["a"]["b"]["d"] == 2


def test_toml_document_super_table_with_different_sub_sections(
    example: Callable[[str], str],
) -> None:
    content = example("pyproject")

    doc = parse(content)
    tool = doc["tool"]

    assert "poetry" in tool
    assert "black" in tool


def test_adding_an_element_to_existing_table_with_ws_remove_ws() -> None:
    content = """[foo]

[foo.bar]

"""

    doc = parse(content)
    doc["foo"]["int"] = 34

    expected = """[foo]
int = 34

[foo.bar]

"""

    assert expected == doc.as_string()


def test_document_with_aot_after_sub_tables() -> None:
    content = """[foo.bar]
name = "Bar"

[foo.bar.baz]
name = "Baz"

[[foo.bar.tests]]
name = "Test 1"
"""

    doc = parse(content)
    assert doc["foo"]["bar"]["tests"][0]["name"] == "Test 1"


def test_subtable_of_aot_element_after_other_table() -> None:
    # A sub-table header that extends the last element of an array of tables
    # is valid even when an unrelated table appears in between (issue #261).
    content = """[[fruit]]
apple.color = "red"

[potato]

[fruit.apple.texture]
smooth = true
"""

    doc = parse(content)

    assert doc["fruit"][0]["apple"]["color"] == "red"
    assert doc["fruit"][0]["apple"]["texture"]["smooth"] is True
    assert doc["potato"] == {}


def test_document_with_new_sub_table_after_other_table() -> None:
    content = """[foo]
name = "Bar"

[bar]
name = "Baz"

[foo.baz]
name = "Test 1"
"""

    doc = parse(content)
    assert doc["foo"]["name"] == "Bar"
    assert doc["bar"]["name"] == "Baz"
    assert doc["foo"]["baz"]["name"] == "Test 1"

    assert doc.as_string() == content


def test_document_with_new_sub_table_after_other_table_delete() -> None:
    content = """[foo]
name = "Bar"

[bar]
name = "Baz"

[foo.baz]
name = "Test 1"
"""

    doc = parse(content)

    del doc["foo"]

    assert (
        doc.as_string()
        == """[bar]
name = "Baz"

"""
    )


def test_document_with_new_sub_table_after_other_table_replace() -> None:
    content = """[foo]
name = "Bar"

[bar]
name = "Baz"

[foo.baz]
name = "Test 1"
"""

    doc = parse(content)

    doc["foo"] = {"a": "b"}

    assert (
        doc.as_string()
        == """[foo]
a = "b"

[bar]
name = "Baz"

"""
    )


def test_inserting_after_element_with_no_new_line_adds_a_new_line() -> None:
    doc = parse("foo = 10")
    doc["bar"] = 11

    expected = """foo = 10
bar = 11
"""

    assert expected == doc.as_string()

    doc = parse("# Comment")
    doc["bar"] = 11

    expected = """# Comment
bar = 11
"""

    assert expected == doc.as_string()


def test_inserting_after_deletion() -> None:
    doc = parse("foo = 10\n")
    del doc["foo"]

    doc["bar"] = 11

    expected = """bar = 11
"""

    assert expected == doc.as_string()


def test_toml_document_with_dotted_keys_inside_table(
    example: Callable[[str], str],
) -> None:
    content = example("0.5.0")

    doc = parse(content)
    t = doc["table"]

    assert "a" in t

    assert t["a"]["b"]["c"] == 1
    assert t["a"]["b"]["d"] == 2
    assert t["a"]["c"] == 3


def test_toml_document_with_super_aot_after_super_table(
    example: Callable[[str], str],
) -> None:
    content = example("pyproject")

    doc = parse(content)
    aot = doc["tool"]["foo"]

    assert isinstance(aot, list)

    first = aot[0]
    assert first["name"] == "first"

    second = aot[1]
    assert second["name"] == "second"


def test_toml_document_has_always_a_new_line_after_table_header() -> None:
    content = """[section.sub]"""

    doc = parse(content)
    assert doc.as_string() == """[section.sub]"""

    doc["section"]["sub"]["foo"] = "bar"
    assert (
        doc.as_string()
        == """[section.sub]
foo = "bar"
"""
    )

    del doc["section"]["sub"]["foo"]

    assert doc.as_string() == """[section.sub]"""


def test_toml_document_is_pickable(example: Callable[[str], str]) -> None:
    content = example("example")

    doc = parse(content)
    assert pickle.loads(pickle.dumps(doc)).as_string() == content


def test_toml_document_set_super_table_element() -> None:
    content = """[site.user]
name = "John"
"""

    doc = parse(content)
    doc["site"]["user"] = "Tom"

    assert (
        doc.as_string()
        == """[site]
user = "Tom"
"""
    )


def test_toml_document_can_be_copied() -> None:
    content = "[foo]\nbar=1"

    doc = parse(content)
    doc = copy.copy(doc)

    assert (
        doc.as_string()
        == """[foo]
bar=1"""
    )

    assert doc == {"foo": {"bar": 1}}
    assert doc["foo"]["bar"] == 1
    assert json.loads(json.dumps(doc)) == {"foo": {"bar": 1}}

    doc = parse(content)
    doc = doc.copy()

    assert (
        doc.as_string()
        == """[foo]
bar=1"""
    )

    assert doc == {"foo": {"bar": 1}}
    assert doc["foo"]["bar"] == 1
    assert json.loads(json.dumps(doc)) == {"foo": {"bar": 1}}


def test_getting_inline_table_is_still_an_inline_table() -> None:
    content = """\
[tool.poetry]
name = "foo"

[tool.poetry.dependencies]

[tool.poetry.dev-dependencies]
"""

    doc = parse(content)
    poetry_section = doc["tool"]["poetry"]
    dependencies = poetry_section["dependencies"]
    dependencies["foo"] = tomlkit.inline_table()
    dependencies["foo"]["version"] = "^2.0"
    dependencies["foo"]["source"] = "local"
    dependencies["bar"] = tomlkit.inline_table()
    dependencies["bar"]["version"] = "^3.0"
    dependencies["bar"]["source"] = "remote"
    dev_dependencies = poetry_section["dev-dependencies"]
    dev_dependencies["baz"] = tomlkit.inline_table()
    dev_dependencies["baz"]["version"] = "^4.0"
    dev_dependencies["baz"]["source"] = "other"

    assert (
        doc.as_string()
        == """\
[tool.poetry]
name = "foo"

[tool.poetry.dependencies]
foo = {version = "^2.0", source = "local"}
bar = {version = "^3.0", source = "remote"}

[tool.poetry.dev-dependencies]
baz = {version = "^4.0", source = "other"}
"""
    )


def test_declare_sub_table_with_intermediate_table() -> None:
    content = """
[students]
tommy = 87
mary = 66

[subjects]
maths = "maths"
english = "english"

[students.bob]
score = 91
"""

    doc = parse(content)
    assert {"tommy": 87, "mary": 66, "bob": {"score": 91}} == doc["students"]
    assert {"tommy": 87, "mary": 66, "bob": {"score": 91}} == doc.get("students")


def test_values_can_still_be_set_for_out_of_order_tables() -> None:
    content = """
[a.a]
key = "value"

[a.b]

[a.a.c]
"""

    doc = parse(content)
    doc["a"]["a"]["key"] = "new_value"

    assert doc["a"]["a"]["key"] == "new_value"

    expected = """
[a.a]
key = "new_value"

[a.b]

[a.a.c]
"""

    assert expected == doc.as_string()

    doc["a"]["a"]["bar"] = "baz"

    expected = """
[a.a]
key = "new_value"
bar = "baz"

[a.b]

[a.a.c]
"""

    assert expected == doc.as_string()

    del doc["a"]["a"]["key"]

    expected = """
[a.a]
bar = "baz"

[a.b]

[a.a.c]
"""

    assert expected == doc.as_string()

    with pytest.raises(NonExistentKey):
        doc["a"]["a"]["key"]

    with pytest.raises(NonExistentKey):
        del doc["a"]["a"]["key"]


def test_out_of_order_table_can_add_multiple_tables() -> None:
    content = """\
[a.a.b]
x = 1
[foo]
bar = 1
[a.a.c]
y = 1
[a.a.d]
z = 1
"""
    doc = parse(content)
    assert doc.as_string() == content
    assert doc["a"]["a"] == {"b": {"x": 1}, "c": {"y": 1}, "d": {"z": 1}}


def test_unwrap_out_of_order_tables() -> None:
    # unwrap() resolves out-of-order tables through the same proxy as item
    # access, so the fragments are merged into one dict.
    doc = parse("[a.x]\np = 1\n[foo]\nbar = 2\n[a.y]\nq = 3\n")
    assert doc.unwrap() == {"a": {"x": {"p": 1}, "y": {"q": 3}}, "foo": {"bar": 2}}


def test_unwrap_preserves_raise_on_invalid_out_of_order_fragment() -> None:
    # Regression guard: this document is actually *invalid* TOML -- `b` is a value
    # under [a], then reopened as a table by the out-of-order [a.b].  The in-order
    # form and stdlib tomllib both reject it.  Since the Container.append concrete-
    # +super fix, tomlkit now rejects it at parse time as well.
    with pytest.raises(ParseError):
        parse("[a]\nb = true\n[zz]\nq = 9\n[a.b]\narr = [1, 2]\n")


def test_reject_out_of_order_dotted_key_redefinition_at_parse() -> None:
    # https://github.com/python-poetry/tomlkit/issues/523
    # A dotted key (b.c) creates an implicit table definition that is later
    # redefined by an explicit [a.b] table header after an unrelated table [zz].
    # This is invalid TOML (defining a table multiple times) and must be rejected
    # at parse, not silently accepted.
    with pytest.raises(ParseError):
        parse("[a]\nb.c = 1\n[zz]\nq = 9\n[a.b]\nd = 2\n")


def test_reject_out_of_order_dotted_prefix_at_parse() -> None:
    # https://github.com/python-poetry/tomlkit/issues/523
    # A non-dotted candidate key (b) that is a prefix of an existing dotted key
    # (b.c) means the table would be defined twice — once implicitly by the
    # dotted key and once explicitly by the table header.  This must raise.
    with pytest.raises((ParseError, TOMLKitError)):
        parse("[a]\nb.c=1\n[a.b]\nd=2\n")


def test_valid_out_of_order_independent_tables() -> None:
    # [zz] splits unrelated tables; the concrete+super merge must not break
    # valid out-of-order extensions.
    doc = parse("[a]\nx=1\n[zz]\n[a.b]\nc=1\n")
    assert doc.unwrap() == {"a": {"x": 1, "b": {"c": 1}}, "zz": {}}
    assert doc.as_string() == "[a]\nx=1\n[zz]\n[a.b]\nc=1\n"


def test_set_value_on_out_of_order_table_with_empty_concrete_part() -> None:
    # A super table defined after its sub-table (the "defining a super-table
    # afterward is ok" spec example) leaves an empty concrete `[x]` part.
    # Adding a plain value must land in that concrete part, not turn the
    # header-less super part into a second `[x]` header -- which produced
    # output with a duplicate header that no longer parsed.
    doc = parse("[x.y.z.w]\n\n[x]\n")
    doc["x"]["c"] = 3

    assert doc["x"]["c"] == 3
    assert doc.as_string() == "[x.y.z.w]\n\n[x]\nc = 3\n"
    assert parse(doc.as_string()).unwrap() == {"x": {"y": {"z": {"w": {}}}, "c": 3}}


def test_out_of_order_table_merges_aot_fragments() -> None:
    # https://github.com/python-poetry/tomlkit/issues/505
    content = """\
[hooks]

[[hooks.Stop]]
matcher = ".*"

[unrelated]
x = 1

[[hooks.Stop]]
matcher = "second"

[hooks.state]
y = 2
"""
    doc = parse(content)
    assert doc.as_string() == content

    hooks = doc["hooks"]
    assert list(hooks.keys()) == ["Stop", "state"]
    assert len(hooks["Stop"]) == 2
    assert hooks["Stop"][1]["matcher"] == "second"
    assert hooks["state"]["y"] == 2

    # element-level mutation still writes through to the document
    hooks["Stop"][1]["matcher"] = "patched"
    assert 'matcher = "patched"' in doc.as_string()


def test_out_of_order_table_merges_three_aot_fragments() -> None:
    # An AoT split across more than two out-of-order parts merges into a single
    # AoT: each later fragment is appended to the growing element list, so the
    # parts keep their order and every element is reachable.
    content = """\
[hooks]

[[hooks.Stop]]
matcher = "a"

[unrelated1]
x = 1

[[hooks.Stop]]
matcher = "b"

[unrelated2]
y = 2

[[hooks.Stop]]
matcher = "c"

[hooks.state]
z = 3
"""
    doc = parse(content)
    assert doc.as_string() == content

    hooks = doc["hooks"]
    assert list(hooks.keys()) == ["Stop", "state"]
    assert [t["matcher"] for t in hooks["Stop"]] == ["a", "b", "c"]
    assert hooks["state"]["z"] == 3


def test_out_of_order_tables_are_still_dicts() -> None:
    content = """
[a.a]
key = "value"

[a.b]

[a.a.c]
"""

    doc = parse(content)
    assert isinstance(doc["a"], dict)
    assert isinstance(doc["a"]["a"], dict)

    table = doc["a"]["a"]
    assert "key" in table
    assert "c" in table
    assert table.get("key") == "value"
    assert {} == table.get("c")
    assert table.get("d") is None
    assert table.get("d", "foo") == "foo"

    assert table.setdefault("d", "bar") == "bar"
    assert table["d"] == "bar"

    assert table.pop("key") == "value"
    assert "key" not in table

    assert table.pop("missing", "baz") == "baz"

    with pytest.raises(KeyError):
        table.pop("missing")


def test_string_output_order_is_preserved_for_out_of_order_tables() -> None:
    content = """
[tool.poetry]
name = "foo"

[tool.poetry.dependencies]
python = "^3.6"
bar = "^1.0"


[build-system]
requires = ["poetry-core"]
backend = "poetry.core.masonry.api"


[tool.other]
a = "b"
"""

    doc = parse(content)
    constraint = tomlkit.inline_table()
    constraint["version"] = "^1.0"
    doc["tool"]["poetry"]["dependencies"]["bar"] = constraint

    assert doc["tool"]["poetry"]["dependencies"]["bar"]["version"] == "^1.0"

    expected = """
[tool.poetry]
name = "foo"

[tool.poetry.dependencies]
python = "^3.6"
bar = {version = "^1.0"}


[build-system]
requires = ["poetry-core"]
backend = "poetry.core.masonry.api"


[tool.other]
a = "b"
"""

    assert expected == doc.as_string()


def test_remove_from_out_of_order_table() -> None:
    content = """[a]
x = 1

[c]
z = 3

[a.b]
y = 2
"""
    document = parse(content)
    del document["a"]["b"]
    assert (
        document.as_string()
        == """[a]
x = 1

[c]
z = 3

"""
    )
    assert json.dumps(document) == '{"a": {"x": 1}, "c": {"z": 3}}'


def test_update_nested_out_of_order_table() -> None:
    doc = parse("""\
[root1.root2.a.b.c]
  value = 2
[WALRUS]
  goo = "gjob"
[root1.root2.x]
  value = 4
""")
    doc["root1"]["root2"]["a"].add("tmp", "hi")
    assert (
        doc.as_string()
        == """\
[root1.root2.a]
tmp = "hi"

[root1.root2.a.b.c]
  value = 2
[WALRUS]
  goo = "gjob"
[root1.root2.x]
  value = 4
"""
    )


def test_updating_nested_value_keeps_correct_indent() -> None:
    content = """
[Key1]
      [key1.Key2]
      Value1 = 10
      Value2 = 30
"""

    doc = parse(content)
    doc["key1"]["Key2"]["Value1"] = 20

    expected = """
[Key1]
      [key1.Key2]
      Value1 = 20
      Value2 = 30
"""

    assert doc.as_string() == expected


def test_repr() -> None:
    content = """
namespace.key1 = "value1"
namespace.key2 = "value2"
[tool.poetry.foo]
option = "test"
[tool.poetry.bar]
option = "test"
inline = {"foo" = "bar", "bar" = "baz"}
"""

    doc = parse(content)

    assert (
        repr(doc)
        == "{'namespace': {'key1': 'value1', 'key2': 'value2'}, 'tool': {'poetry': {'foo': {'option': 'test'}, 'bar': {'option': 'test', 'inline': {'foo': 'bar', 'bar': 'baz'}}}}}"
    )

    assert (
        repr(doc["tool"])
        == "{'poetry': {'foo': {'option': 'test'}, 'bar': {'option': 'test', 'inline': {'foo': 'bar', 'bar': 'baz'}}}}"
    )

    assert repr(doc["namespace"]) == "{'key1': 'value1', 'key2': 'value2'}"


def test_repr_out_of_order_table_proxy() -> None:
    doc = parse("""\
a.b.c = "d"
a.b.e = "f"
""")
    expected = "{'b': {'c': 'd', 'e': 'f'}}"

    assert repr(doc["a"]) == expected
    assert str(doc["a"]) == expected


def test_deepcopy() -> None:
    content = """
[tool]
name = "foo"
[tool.project.section]
option = "test"
"""
    doc = parse(content)
    copied = copy.deepcopy(doc)
    assert copied == doc
    assert copied.as_string() == content


def test_move_table() -> None:
    content = """a = 1
[x]
a = 1

[y]
b = 1
"""
    doc = parse(content)
    doc["a"] = doc.pop("x")
    doc["z"] = doc.pop("y")
    assert (
        doc.as_string()
        == """[a]
a = 1

[z]
b = 1
"""
    )


def test_replace_with_table() -> None:
    content = """a = 1
b = 2
c = 3
"""
    doc = parse(content)
    doc["b"] = {"foo": "bar"}
    assert (
        doc.as_string()
        == """a = 1
c = 3

[b]
foo = "bar"
"""
    )


def test_replace_table_with_value() -> None:
    content = """[foo]
a = 1

[bar]
b = 2
"""
    doc = parse(content)
    doc["bar"] = 42
    assert (
        doc.as_string()
        == """bar = 42

[foo]
a = 1

"""
    )


def test_replace_middle_table_with_value() -> None:
    # https://github.com/python-poetry/tomlkit/issues/504
    content = """[a]
aa = 1

[b]
bb = 2

[c]
cc = 3
"""
    doc = parse(content)
    doc["b"] = 2
    assert (
        doc.as_string()
        == """b = 2

[a]
aa = 1

[c]
cc = 3
"""
    )
    assert parse(doc.as_string())["a"] == {"aa": 1}


def test_replace_preserve_sep() -> None:
    content = """a   =   1

[foo]
b  =  "what"
"""
    doc = parse(content)
    doc["a"] = 2
    doc["foo"]["b"] = "how"
    assert (
        doc.as_string()
        == """a   =   2

[foo]
b  =  "how"
"""
    )


def test_replace_super_table_preserves_whitespace() -> None:
    content = """\
[env.pro1.rst]
name = "x7"

[env2]
name = 2

[env3]
name = 3
"""
    doc = parse(content)

    doc["env"] = doc["env"]

    assert doc.as_string() == content


def test_replace_table_with_itself_preserves_display_name() -> None:
    content = """\
[keys.a]
[keys .'a'.'c']
  'd'	= 'e'
"""
    doc = parse(content)

    for mode in doc["keys"]:
        doc["keys"][mode] = doc["keys"][mode]

    assert doc.as_string() == content


def test_replace_with_table_of_nested() -> None:
    example = """\
    [a]
    x = 1

    [a.b]
    y = 2
    """
    doc = parse(dedent(example))
    doc["c"] = doc.pop("a")
    expected = """\
    [c]
    x = 1

    [c.b]
    y = 2
    """
    assert doc.as_string().strip() == dedent(expected).strip()


def test_replace_with_aot_of_nested() -> None:
    example = """\
    [a]
    x = 1

    [[a.b]]
    y = 2

    [[a.b]]

    [a.b.c]
    z = 2

    [[a.b.c.d]]
    w = 2
    """
    doc = parse(dedent(example))
    doc["f"] = doc.pop("a")
    expected = """\
    [f]
    x = 1

    [[f.b]]
    y = 2

    [[f.b]]

    [f.b.c]
    z = 2

    [[f.b.c.d]]
    w = 2
    """
    assert doc.as_string().strip() == dedent(expected).strip()


def test_replace_dotted_key_with_table() -> None:
    # https://github.com/python-poetry/tomlkit/issues/524
    content = "fruit.apple = true\n"
    doc = parse(content)
    doc["fruit"] = {"a": 1}
    # The dotted prefix must be dropped instead of duplicated onto the header.
    assert (
        doc.as_string()
        == """[fruit]
a = 1
"""
    )
    assert parse(doc.as_string())["fruit"] == {"a": 1}


def test_replace_dotted_key_with_empty_table_keeps_following_sibling() -> None:
    # https://github.com/python-poetry/tomlkit/issues/513
    content = """a.b = 1
c.d = 2
"""
    doc = parse(content)
    doc["a"] = {}
    # ``[a]`` must not swallow the following ``c.d`` dotted key.
    assert (
        doc.as_string()
        == """c.d = 2

[a]
"""
    )
    assert parse(doc.as_string()) == {"c": {"d": 2}, "a": {}}


def test_replace_dotted_key_with_table_keeps_following_sibling() -> None:
    # https://github.com/python-poetry/tomlkit/issues/513
    content = """a.b = 1
c.d = 2
"""
    doc = parse(content)
    doc["a"] = {"x": 9}
    assert (
        doc.as_string()
        == """c.d = 2

[a]
x = 9
"""
    )
    assert parse(doc.as_string()) == {"c": {"d": 2}, "a": {"x": 9}}


def test_replace_dotted_key_with_aot_keeps_following_sibling() -> None:
    # https://github.com/python-poetry/tomlkit/issues/542
    content = """a.b = 1
c.d = 2
"""
    doc = parse(content)
    arr = tomlkit.aot()
    tbl = tomlkit.table()
    tbl["x"] = 9
    arr.append(tbl)
    doc["a"] = arr
    assert (
        doc.as_string()
        == """c.d = 2

[[a]]
x = 9
"""
    )
    assert parse(doc.as_string()) == {"c": {"d": 2}, "a": [{"x": 9}]}


def test_replace_value_with_table_keeps_following_dotted_sibling() -> None:
    # A plain value turning into a table must likewise clear the inline region
    # (including dotted keys) before emitting its header.
    content = """x = 1
c.d = 2
"""
    doc = parse(content)
    doc["x"] = {}
    assert (
        doc.as_string()
        == """c.d = 2

[x]
"""
    )
    assert parse(doc.as_string()) == {"c": {"d": 2}, "x": {}}


def test_replace_with_comment() -> None:
    content = 'a = "1"'
    doc = parse(content)
    a: Any = tomlkit.item(int(doc["a"]))
    a.comment("`a` should be an int")
    doc["a"] = a
    expected = "a = 1 # `a` should be an int"
    assert doc.as_string() == expected

    content = 'a = "1, 2, 3"'
    doc = parse(content)
    a = tomlkit.array()
    a.comment("`a` should be an array")
    for x in doc["a"].split(","):
        a.append(int(x.strip()))
    doc["a"] = a
    expected = "a = [1, 2, 3] # `a` should be an array"
    assert doc.as_string() == expected

    doc = parse(content)
    a = tomlkit.inline_table()
    a.comment("`a` should be an inline-table")
    for x in doc["a"].split(","):
        i = int(x.strip())
        a.append(chr(ord("a") + i - 1), i)
    doc["a"] = a
    expected = "a = {a = 1, b = 2, c = 3} # `a` should be an inline-table"
    assert doc.as_string() == expected


def test_no_spurious_whitespaces() -> None:
    content = """\
    [x]
    a = 1

    [y]
    b = 2
    """
    doc = parse(dedent(content))
    doc["z"] = doc.pop("y")
    expected = """\
    [x]
    a = 1

    [z]
    b = 2
    """
    assert doc.as_string() == dedent(expected)
    doc["w"] = {"c": 3}
    expected = """\
    [x]
    a = 1

    [z]
    b = 2

    [w]
    c = 3
    """
    assert doc.as_string() == dedent(expected)

    doc = parse(dedent(content))
    del doc["x"]
    doc["z"] = {"c": 3}
    expected = """\
    [y]
    b = 2

    [z]
    c = 3
    """
    assert doc.as_string() == dedent(expected)


def test_pop_add_whitespace_and_insert_table_work_togheter() -> None:
    content = """\
    a = 1
    b = 2
    c = 3
    d = 4
    """
    doc = parse(dedent(content))
    doc.pop("a")
    doc.pop("b")
    doc.add(ws("\n"))
    doc["e"] = {"foo": "bar"}
    expected = """\
    c = 3
    d = 4

    [e]
    foo = "bar"
    """
    text = doc.as_string()
    out = parse(text)
    assert out["d"] == 4
    assert "d" not in out["e"]
    assert text == dedent(expected)


def test_add_newline_before_super_table() -> None:
    doc = document()
    doc["a"] = 1
    doc["b"] = {"c": {}}
    doc["d"] = {"e": {}}
    expected = """\
    a = 1

    [b.c]

    [d.e]
    """
    assert doc.as_string() == dedent(expected)


def test_remove_item_from_super_table() -> None:
    content = """\
    [hello.one]
    a = 1

    [hello.two]
    b = 1
    """
    doc = parse(dedent(content))
    del doc["hello"]["two"]
    expected = """\
    [hello.one]
    a = 1

    """
    assert doc.as_string() == dedent(expected)


def test_nested_table_update_display_name() -> None:
    content = """\
    [parent]

    [parent.foo]
    x = 1
    """

    doc = parse(dedent(content))
    sub = """\
    [foo]
    y = 2

    [bar]
    z = 3
    """
    doc["parent"].update(parse(dedent(sub)))
    expected = """\
    [parent]

    [parent.foo]
    y = 2

    [parent.bar]
    z = 3
    """
    assert doc.as_string() == dedent(expected)


def test_build_table_with_dotted_key() -> None:
    doc = tomlkit.document()
    data = {
        "a.b.c": 1,
        "a.b.d": 2,
        "a": {"c": {"foo": "bar"}},
        "a.d.e": 3,
    }

    for key, value in data.items():
        if "." not in key:
            doc.append(key, value)
        else:
            doc.append(tomlkit.key(key.split(".")), value)

    expected = """\
a.b.c = 1
a.b.d = 2
a.d.e = 3

[a.c]
foo = "bar"
"""
    assert doc.as_string() == expected
    assert json.loads(json.dumps(doc)) == {
        "a": {"b": {"c": 1, "d": 2}, "d": {"e": 3}, "c": {"foo": "bar"}}
    }


def test_parse_subtables_no_extra_indent() -> None:
    expected = """\
[a]
    [a.b.c]
        foo = 1

    [a.b.d]
        bar = 2
"""
    doc = parse(expected)
    assert doc.as_string() == expected


def test_item_preserves_the_order() -> None:
    t = tomlkit.inline_table()
    t.update({"a": 1, "b": 2})
    doc = {"name": "foo", "table": t, "age": 42}
    expected = """\
name = "foo"
table = {a = 1, b = 2}
age = 42
"""
    assert tomlkit.dumps(doc) == expected


def test_delete_out_of_order_table_key() -> None:
    content = """\
[foo]
name = "foo"

[bar.a.b]
name = "bar-a-b"

[foo.a]
name = "foo-a"

[bar.a]
name = "bar-a"

[baz]
name = "baz"

[bar.a.c]
name = "bar-a-c"
"""
    doc = parse(content)
    del doc["bar"]["a"]
    assert (
        doc.as_string()
        == """\
[foo]
name = "foo"

[foo.a]
name = "foo-a"

[baz]
name = "baz"

"""
    )


def test_overwrite_out_of_order_table_key() -> None:
    content = """\
[foo]
name = "foo"

[bar.a.b]
name = "bar-a-b"

[foo.a]
name = "foo-a"

[bar.a]
name = "bar-a"

[baz]
name = "baz"

[bar.a.c]
name = "bar-a-c"
"""
    doc = parse(content)
    doc["bar"]["a"] = {"name": "bar-a-updated"}
    assert (
        doc.as_string()
        == """\
[foo]
name = "foo"

[bar.a]
name = "bar-a-updated"
[foo.a]
name = "foo-a"

[baz]
name = "baz"

"""
    )


def test_set_default_int() -> None:
    with pytest.raises(TypeError):
        TOMLDocument().setdefault(4, 5)  # type: ignore[arg-type]


def test_overwriting_out_of_order_table() -> None:
    content = """\
[foo.bar]
open = false

[foo]
x = 1
y = 2
"""
    doc = parse(content)
    doc["foo"]["z"] = 3
    assert (
        doc.as_string()
        == """\
[foo.bar]
open = false

[foo]
x = 1
y = 2
z = 3
"""
    )

    doc["foo"]["bar"] = tomlkit.inline_table()
    doc["foo"]["bar"]["open"] = True
    assert (
        doc.as_string()
        == """\
[foo]
x = 1
y = 2
z = 3
bar = {open = true}
"""
    )


def test_delete_key_from_out_of_order_table() -> None:
    content = """\
[foo.bar.baz]
a = 1
[foo.bar]
b = 2
[other]
c = 3
[foo.tee]
d = 4
"""
    doc = parse(content)
    del doc["foo"]["bar"]
    assert (
        doc.as_string()
        == """\
[other]
c = 3
[foo.tee]
d = 4
"""
    )


def test_parse_aot_without_ending_newline() -> None:
    content = '''\
[[products]]
name = "Hammer"

[foo]

[bar]

[[products]]
name = "Nail"'''
    doc = parse(content)
    assert (
        doc.as_string()
        == """\
[[products]]
name = "Hammer"

[[products]]
name = "Nail"
[foo]

[bar]

"""
    )
    assert doc == {
        "products": [
            {"name": "Hammer"},
            {"name": "Nail"},
        ],
        "foo": {},
        "bar": {},
    }


def test_add_key_after_dotted_inline_table_without_ending_newline() -> None:
    content = "[x]\na.b = {}"
    doc = parse(content)
    doc["x"]["c"] = 3

    assert doc.as_string() == "[x]\na.b = {}\nc = 3\n"

    doc = parse(f"{content}\n")
    doc["x"]["c"] = 3

    assert doc.as_string() == "[x]\na.b = {}\nc = 3\n"


def test_appending_to_super_table() -> None:
    content = """\
[a.b]
value = 5
"""

    doc = parse(content)
    table_a = doc["a"]
    table_a.append(tomlkit.key(["c", "d"]), "foo")

    expected = """\
[a]
c.d = "foo"

[a.b]
value = 5
"""

    assert doc.as_string() == expected


def test_scalar_is_not_captured_by_table_rendered_from_dotted_key() -> None:
    # https://github.com/python-poetry/tomlkit/issues/543
    # A dotted-key super table renders inline (`a.b = 1`) until a child that
    # renders a `[table]` header is added; a scalar appended after that must
    # not land inside the table's scope.
    doc = parse("a.b = 1\n")
    doc["a"]["c"] = {}
    doc["z"] = 2

    expected = """\
z = 2

a.b = 1

[a.c]
"""

    assert doc.as_string() == expected
    assert parse(doc.as_string()) == {"z": 2, "a": {"b": 1, "c": {}}}

    # A purely inline dotted key still gets the scalar appended after it.
    doc = parse("a.b = 1\n")
    doc["z"] = 2

    assert doc.as_string() == "a.b = 1\nz = 2\n"
