from __future__ import annotations

from argparse import Namespace

import pytest
from python_discovery import PythonInfo

from virtualenv.activation import (
    BashActivator,
    BatchActivator,
    CShellActivator,
    FishActivator,
    PowerShellActivator,
    PythonActivator,
    XonshActivator,
)


@pytest.mark.parametrize(
    "activator_class",
    [BatchActivator, PowerShellActivator, PythonActivator, BashActivator, FishActivator, XonshActivator],
)
def test_activator_support_windows(mocker, activator_class) -> None:
    activator = activator_class(Namespace(prompt=None))

    interpreter = mocker.Mock(spec=PythonInfo)
    interpreter.os = "nt"
    assert activator.supports(interpreter)


@pytest.mark.parametrize("activator_class", [CShellActivator])
def test_activator_no_support_windows(mocker, activator_class) -> None:
    activator = activator_class(Namespace(prompt=None))

    interpreter = mocker.Mock(spec=PythonInfo)
    interpreter.os = "nt"
    assert not activator.supports(interpreter)


@pytest.mark.parametrize(
    "activator_class",
    [BashActivator, CShellActivator, FishActivator, PowerShellActivator, PythonActivator, XonshActivator],
)
def test_activator_support_posix(mocker, activator_class) -> None:
    activator = activator_class(Namespace(prompt=None))
    interpreter = mocker.Mock(spec=PythonInfo)
    interpreter.os = "posix"
    assert activator.supports(interpreter)


@pytest.mark.parametrize("activator_class", [BatchActivator])
def test_activator_no_support_posix(mocker, activator_class) -> None:
    activator = activator_class(Namespace(prompt=None))
    interpreter = mocker.Mock(spec=PythonInfo)
    interpreter.os = "posix"
    assert not activator.supports(interpreter)
