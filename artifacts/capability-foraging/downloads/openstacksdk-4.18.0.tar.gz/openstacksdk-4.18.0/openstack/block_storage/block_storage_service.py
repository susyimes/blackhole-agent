# Licensed under the Apache License, Version 2.0 (the "License"); you may
# not use this file except in compliance with the License. You may obtain
# a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
# WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
# License for the specific language governing permissions and limitations
# under the License.

from openstack.block_storage.v2 import _proxy as _v2_proxy
from openstack.block_storage.v3 import _proxy as _v3_proxy
from openstack import service_description


class BlockStorageService(
    service_description.ServiceDescription[_v2_proxy.Proxy | _v3_proxy.Proxy]
):
    """The block storage service."""

    supported_versions = {
        '3': _v3_proxy.Proxy,
        '2': _v2_proxy.Proxy,
    }
