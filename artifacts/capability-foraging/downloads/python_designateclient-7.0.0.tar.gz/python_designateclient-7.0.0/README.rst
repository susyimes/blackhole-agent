=====================================
Python bindings to the Designate API
=====================================

.. image:: https://img.shields.io/pypi/v/python-designateclient.svg
    :target: https://pypi.org/project/python-designateclient/
    :alt: Latest Version

This is a client library for Designate built on the Designate API. It
provides a Python API (the ``designateclient`` module) and a command-line tool
(``designate``).

Development takes place via the usual OpenStack processes as outlined in the
`developer guide <https://docs.openstack.org/infra/manual/developers.html>`_.  The master
repository is in `Git <https://git.openstack.org/cgit/openstack/python-designateclient>`_.

See release notes and more at `<https://docs.openstack.org/python-designateclient/latest/>`_.

* License: Apache License, Version 2.0
* `PyPi`_ - package installation
* `Online Documentation`_
* `Bugs`_ - issue tracking
* `Blueprints`_ - feature specifications
* `Source`_
* `How to Contribute`_
* `Release Notes`_

.. _PyPi: https://pypi.org/project/python-designateclient
.. _Online Documentation: https://docs.openstack.org/python-designateclient/latest/
.. _Bugs: https://bugs.launchpad.net/python-designateclient
.. _Blueprints: https://blueprints.launchpad.net/python-designateclient
.. _Source: https://git.openstack.org/cgit/openstack/python-designateclient
.. _How to Contribute: https://docs.openstack.org/infra/manual/developers.html
.. _Release Notes: https://docs.openstack.org/releasenotes/python-designateclient
