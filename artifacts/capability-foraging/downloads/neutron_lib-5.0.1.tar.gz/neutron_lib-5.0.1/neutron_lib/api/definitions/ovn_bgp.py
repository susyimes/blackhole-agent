# Copyright 2026 Red Hat, LLC
# All Rights Reserved.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

from neutron_lib.api import converters
from neutron_lib.api.definitions import subnet
from neutron_lib.types import (
    ActionMap,
    ResourceAttributeMap,
    SubResourceAttributeMap,
)

ALIAS = 'ovn-bgp'
IS_SHIM_EXTENSION = False
IS_STANDARD_ATTR_EXTENSION = False
NAME = 'OVN BGP'
API_PREFIX = ''
DESCRIPTION = 'Subnet extension to support OVN BGP route leaking'
UPDATED_TIMESTAMP = '2026-07-20T00:00:00-00:00'
RESOURCE_NAME = subnet.RESOURCE_NAME
COLLECTION_NAME = subnet.COLLECTION_NAME

LEAK_ROUTES = 'leak_routes'

RESOURCE_ATTRIBUTE_MAP: ResourceAttributeMap = {
    COLLECTION_NAME: {
        LEAK_ROUTES: {
            'allow_post': False,
            'allow_put': True,
            'default': False,
            'convert_to': converters.convert_to_boolean,
            'is_visible': True,
            'is_filter': False,
            'is_sort_key': False,
            'enforce_policy': True,
        },
    },
}

SUB_RESOURCE_ATTRIBUTE_MAP: SubResourceAttributeMap = {}
ACTION_MAP: ActionMap = {}
REQUIRED_EXTENSIONS = []
OPTIONAL_EXTENSIONS = []
ACTION_STATUS = {}
