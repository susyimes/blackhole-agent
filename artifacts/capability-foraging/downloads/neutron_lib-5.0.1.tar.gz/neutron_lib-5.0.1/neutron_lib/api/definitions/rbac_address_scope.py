#    Copyright (c) 2020 Cloudification GmbH.  All rights reserved.
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

from neutron_lib.types import (
    ActionMap,
    ResourceAttributeMap,
    SubResourceAttributeMap,
)

ALIAS = 'rbac-address-scope'
IS_SHIM_EXTENSION = True
IS_STANDARD_ATTR_EXTENSION = False
NAME = 'Add address_scope type to RBAC'
DESCRIPTION = 'Add address_scope type to RBAC'
UPDATED_TIMESTAMP = '2020-02-12T00:00:00-00:00'
RESOURCE_ATTRIBUTE_MAP: ResourceAttributeMap = {}
SUB_RESOURCE_ATTRIBUTE_MAP: SubResourceAttributeMap = {}
ACTION_MAP: ActionMap = {}
REQUIRED_EXTENSIONS = ['rbac-policies', 'address-scope']
OPTIONAL_EXTENSIONS = []
ACTION_STATUS = {}
