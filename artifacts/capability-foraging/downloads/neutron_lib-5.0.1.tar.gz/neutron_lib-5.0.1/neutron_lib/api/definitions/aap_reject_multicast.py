# Licensed under the Apache License, Version 2.0 (the "License"); you may
# not use this file except in compliance with the License. You may obtain
# a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
# WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
# License for the specific language governing permissions and limitations
# under the License.

from neutron_lib.types import (
    ActionMap,
    ResourceAttributeMap,
    SubResourceAttributeMap,
)

ALIAS = 'aap-reject-multicast'
IS_SHIM_EXTENSION = True
IS_STANDARD_ATTR_EXTENSION = False
NAME = 'Allowed address pairs reject multicast extension'
DESCRIPTION = 'Reject multicast addresses in Allowed Address Pairs'
UPDATED_TIMESTAMP = '2026-04-01T00:00:00-00:00'
RESOURCE_ATTRIBUTE_MAP: ResourceAttributeMap = {}
SUB_RESOURCE_ATTRIBUTE_MAP: SubResourceAttributeMap = {}
ACTION_MAP: ActionMap = {}
REQUIRED_EXTENSIONS = ['allowed-address-pairs']
OPTIONAL_EXTENSIONS = []
ACTION_STATUS = {}
