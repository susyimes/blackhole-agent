# Copyright (C) 2025 Red Hat, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
# implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from unittest import mock
from unittest import TestCase

import cotyledon
from oslo_config import cfg
import pickle

from oslo_service.backend._threading import service
from oslo_service.backend._threading import threadgroup


class DummyService(service.ServiceBase):
    def start(self):
        pass

    def stop(self, graceful=False):
        pass

    def wait(self):
        pass

    def reset(self):
        pass


class CustomService(service.Service):
    """A picklable Service subclass with extra attributes."""

    def __init__(self):
        super().__init__(threads=100)
        self.my_attr = 'preserved'


class UnpicklableService(service.ServiceBase):
    """A service that cannot be pickled due to a lambda attribute."""

    def __init__(self):
        super().__init__()
        self.callback = lambda: None

    def start(self):
        pass

    def stop(self, graceful=False):
        pass

    def wait(self):
        pass

    def reset(self):
        pass


class BaseLauncherTestCase(TestCase):
    def setUp(self):
        super().setUp()
        # Reset ServiceManager singleton so tests may create new instances.
        cotyledon.ServiceManager._process_runner_already_created = False
        self.conf = cfg.ConfigOpts()

    def _test_multiple_launch_service_re_evaluates_context(self, launcher):
        with mock.patch.object(
                service, '_check_spawn_picklable') as mock_check:
            launcher.start_method = 'spawn'
            s1 = DummyService()
            launcher.launch_service(s1)
            s2 = DummyService()
            launcher.launch_service(s2)
            mock_check.assert_called_with(s2, launcher.conf)

    def _test_unpicklable_second_service_rejected_by_spawn(self, launcher):
        launcher.start_method = 'spawn'
        launcher.launch_service(DummyService())
        self.assertEqual(
            launcher._manager_context.get_start_method(), "spawn")
        self.assertRaises(
            (AttributeError, pickle.PicklingError),
            launcher.launch_service,
            UnpicklableService(),
        )


class ProcessLauncherTestCase(BaseLauncherTestCase):
    def test_accepts_wait_interval_and_logs_warning(self):
        # Patch the actual logger used in the module
        with mock.patch('warnings.warn') as mock_warn:
            launcher = service.ProcessLauncher(self.conf, wait_interval=0.1)
            self.assertIsInstance(launcher, service.ProcessLauncher)

            # Ensure warning is logged
            mock_warn.assert_called_once()
            self.assertIn('wait_interval', mock_warn.call_args[0][0])

    def test_no_warning_without_wait_interval(self):
        with mock.patch('warnings.warn') as mock_warn:
            launcher = service.ProcessLauncher(self.conf)
            self.assertIsInstance(launcher, service.ProcessLauncher)
            mock_warn.assert_not_called()

    def test_allows_multiple_launch_service_calls(self):
        launcher = service.ProcessLauncher(self.conf)

        s1 = DummyService()
        s2 = DummyService()

        # Just check that both calls do not raise
        try:
            launcher.launch_service(s1)
            launcher.launch_service(s2)
        except Exception as e:
            self.fail(
                f"Multiple launch_service() calls raised an exception: {e}")

    def test_multiple_launch_service_re_evaluates_context(self):
        launcher = service.ProcessLauncher(self.conf)
        self._test_multiple_launch_service_re_evaluates_context(launcher)

    def test_unpicklable_second_service_rejected_by_spawn(self):
        launcher = service.ProcessLauncher(self.conf)
        self._test_unpicklable_second_service_rejected_by_spawn(launcher)


class ServiceLauncherTestCase(BaseLauncherTestCase):

    def test_multiple_launch_service_re_evaluates_context(self):
        launcher = service.ServiceLauncher(self.conf)
        self._test_multiple_launch_service_re_evaluates_context(launcher)

    def test_unpicklable_second_service_rejected_by_spawn(self):
        launcher = service.ServiceLauncher(self.conf)
        self._test_unpicklable_second_service_rejected_by_spawn(launcher)


class LauncherTestCase(BaseLauncherTestCase):

    def test_picklable_service_uses_fork_by_default(self):
        context = service._select_service_manager_context(
            DummyService(), self.conf)
        self.assertEqual("fork", context.get_start_method())

    def test_explicit_spawn_selects_spawn(self):
        context = service._select_service_manager_context(
            DummyService(), self.conf, "spawn")
        self.assertEqual("spawn", context.get_start_method())

    def test_explicit_spawn_rejects_unpicklable_service(self):
        self.assertRaises(
            (AttributeError, pickle.PicklingError),
            service._select_service_manager_context,
            UnpicklableService(),
            self.conf,
            "spawn",
        )

    def test_explicit_spawn_rejects_unpicklable_conf(self):
        self.conf.register_opt(
            cfg.StrOpt("callback", default=lambda: None))
        self.assertRaises(
            (AttributeError, pickle.PicklingError),
            service._select_service_manager_context,
            DummyService(),
            self.conf,
            "spawn",
        )

    def test_invalid_start_method(self):
        with self.assertRaises(ValueError) as raised:
            service._select_service_manager_context(
                DummyService(), self.conf, "forkserver")
        exc = raised.exception
        self.assertIn("Invalid start_method", str(exc))

    @mock.patch.object(
        service.multiprocessing, "get_all_start_methods",
        return_value=["spawn"])
    def test_spawn_is_default_when_fork_is_unavailable(self, mock_methods):
        context = service._select_service_manager_context(
            DummyService(), self.conf)
        self.assertEqual("spawn", context.get_start_method())

    @mock.patch.object(service.ProcessLauncher, "launch_service")
    def test_launch_propagates_start_method(self, mock_launch_service):
        launcher = service.launch(
            self.conf, DummyService(), workers=2, start_method="spawn")
        self.assertEqual("spawn", launcher.start_method)
        mock_launch_service.assert_called_once()

    def test_no_fork_does_not_validate_spawn_picklability(self):
        launcher = service.ProcessLauncher(
            self.conf, no_fork=True, start_method="spawn")
        unpicklable_service = UnpicklableService()
        with mock.patch.object(unpicklable_service, "start"), \
                mock.patch.object(unpicklable_service, "wait"), \
                mock.patch.object(
                    service, "_check_spawn_picklable") as mock_check:
            launcher.launch_service(unpicklable_service)
        mock_check.assert_not_called()

    def test_graceful_shutdown_timeout_is_registered(self):
        launchers = [service.ProcessLauncher, service.ServiceLauncher]
        for launcher in launchers:
            conf = cfg.ConfigOpts()
            launcher(conf)
            timeout = 50
            conf.set_default("graceful_shutdown_timeout", timeout)
            self.assertEqual(conf.graceful_shutdown_timeout, timeout)

    @mock.patch('cotyledon.ServiceManager.add')
    @mock.patch('cotyledon.oslo_config_glue.link')
    def test_graceful_shutdown_timeout_is_set_in_cotyledon(
        self, mock_link, mock_add):
        launchers = [service.ProcessLauncher, service.ServiceLauncher]
        timeout = 20
        for launcher in launchers:
            with mock.patch.object(cotyledon, 'ServiceManager') as mock_mgr:
                launcher_obj = launcher(self.conf)
                self.conf.set_default("graceful_shutdown_timeout", timeout)
                service1 = DummyService()
                launcher_obj.launch_service(service1)
                # Verify that ServiceManager was called with
                # graceful_shutdown_timeout and mp_context (for
                # spawn-safe support)
                mock_mgr.assert_called_once()
                call_kwargs = mock_mgr.call_args[1]
                self.assertEqual(
                    call_kwargs['graceful_shutdown_timeout'], timeout)
                self.assertIn('mp_context', call_kwargs)


class ServicePickleTestCase(TestCase):

    def test_threading_service_roundtrip(self):
        svc = service.Service(threads=500)
        data = pickle.dumps(svc)
        restored = pickle.loads(data)
        self.assertEqual(restored.tg.thread_pool_size, 500)
        self.assertIsInstance(restored.tg, threadgroup.ThreadGroup)

    def test_subclass_preserves_extra_attrs(self):
        svc = CustomService()
        restored = pickle.loads(pickle.dumps(svc))
        self.assertEqual(restored.my_attr, 'preserved')
        self.assertEqual(restored.tg.thread_pool_size, 100)
        self.assertIsInstance(restored.tg, threadgroup.ThreadGroup)
