// Protocol Buffers - Google's data interchange format
// Copyright 2023 Google LLC.  All rights reserved.
//
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file or at
// https://developers.google.com/open-source/licenses/bsd

#include "upb/reflection/internal/enum_value_def.h"

#include <stddef.h>
#include <stdint.h>
#include <stdlib.h>

#include "upb/base/string_view.h"
#include "upb/mem/arena.h"
#include "upb/reflection/def.h"
#include "upb/reflection/def_type.h"
#include "upb/reflection/descriptor_bootstrap.h"
#include "upb/reflection/enum_def.h"
#include "upb/reflection/enum_value_def.h"
#include "upb/reflection/internal/def_builder.h"
#include "upb/reflection/internal/enum_def.h"
#include "upb/reflection/internal/strdup2.h"
#include "upb/reflection/json_enumvalue_options_bootstrap.h"

// Must be last.
#include "upb/port/def.inc"

struct upb_EnumValueDef {
  UPB_ALIGN_AS(8) const google_protobuf_EnumValueOptions* opts;
  const google_protobuf_FeatureSet* resolved_features;
  const upb_EnumDef* parent;
  const char* full_name;
  const char* json_name;
  int32_t number;
};

upb_EnumValueDef* _upb_EnumValueDef_At(const upb_EnumValueDef* v, int i) {
  return (upb_EnumValueDef*)&v[i];
}

static int _upb_EnumValueDef_Compare(const void* p1, const void* p2) {
  const uint32_t v1 = (*(const upb_EnumValueDef**)p1)->number;
  const uint32_t v2 = (*(const upb_EnumValueDef**)p2)->number;
  return (v1 < v2) ? -1 : (v1 > v2);
}

const upb_EnumValueDef** _upb_EnumValueDefs_Sorted(const upb_EnumValueDef* v,
                                                   size_t n, upb_Arena* a) {
  if (SIZE_MAX / sizeof(void*) < n) return NULL;
  // TODO: Try to replace this arena alloc with a persistent scratch buffer.
  upb_EnumValueDef** out =
      (upb_EnumValueDef**)upb_Arena_Malloc(a, n * sizeof(void*));
  if (!out) return NULL;

  for (size_t i = 0; i < n; i++) {
    out[i] = (upb_EnumValueDef*)&v[i];
  }
  qsort(out, n, sizeof(void*), _upb_EnumValueDef_Compare);

  return (const upb_EnumValueDef**)out;
}

const google_protobuf_EnumValueOptions* upb_EnumValueDef_Options(
    const upb_EnumValueDef* v) {
  return v->opts;
}

bool upb_EnumValueDef_HasOptions(const upb_EnumValueDef* v) {
  return v->opts != (void*)kUpbDefOptDefault;
}

const google_protobuf_FeatureSet* upb_EnumValueDef_ResolvedFeatures(
    const upb_EnumValueDef* e) {
  return e->resolved_features;
}

const upb_EnumDef* upb_EnumValueDef_Enum(const upb_EnumValueDef* v) {
  return v->parent;
}

const char* upb_EnumValueDef_FullName(const upb_EnumValueDef* v) {
  return v->full_name;
}

const char* upb_EnumValueDef_JsonName(const upb_EnumValueDef* v) {
  return v->json_name ? v->json_name : upb_EnumValueDef_Name(v);
}

const char* upb_EnumValueDef_Name(const upb_EnumValueDef* v) {
  return _upb_DefBuilder_FullToShort(v->full_name);
}

int32_t upb_EnumValueDef_Number(const upb_EnumValueDef* v) { return v->number; }

uint32_t upb_EnumValueDef_Index(const upb_EnumValueDef* v) {
  // Compute index in our parent's array.
  return v - upb_EnumDef_Value(v->parent, 0);
}

static const char* _upb_EnumValueDef_ExtractJsonName(
    upb_DefBuilder* ctx, const upb_EnumValueDef* v) {
  if (!upb_EnumValueDef_HasOptions(v)) return NULL;
  const google_protobuf_EnumValueOptions* opts = (const google_protobuf_EnumValueOptions*)v->opts;
  if (!pb_enumvalue_has_json(opts)) return NULL;
  const pb_enumvalue_JsonEnumValueOptions* json_opts = pb_enumvalue_json(opts);
  if (!json_opts || !pb_enumvalue_JsonEnumValueOptions_has_string(json_opts)) {
    return NULL;
  }
  upb_StringView str = pb_enumvalue_JsonEnumValueOptions_string(json_opts);
  return upb_strdup2(str.data, str.size, ctx->arena);
}

static void create_enumvaldef(upb_DefBuilder* ctx, const char* prefix,
                              const google_protobuf_EnumValueDescriptorProto* val_proto,
                              const google_protobuf_FeatureSet* parent_features,
                              upb_EnumDef* e, upb_EnumValueDef* v) {
  UPB_DEF_SET_OPTIONS(v->opts, EnumValueDescriptorProto, EnumValueOptions,
                      val_proto);
  v->resolved_features = _upb_DefBuilder_ResolveFeatures(
      ctx, parent_features, google_protobuf_EnumValueOptions_features(v->opts));

  upb_StringView name = google_protobuf_EnumValueDescriptorProto_name(val_proto);

  v->parent = e;  // Must happen prior to _upb_DefBuilder_Add()
  v->full_name = _upb_DefBuilder_MakeFullName(ctx, prefix, name);
  v->number = google_protobuf_EnumValueDescriptorProto_number(val_proto);
  v->json_name = _upb_EnumValueDef_ExtractJsonName(ctx, v);
  _upb_DefBuilder_Add(ctx, v->full_name,
                      _upb_DefType_Pack(v, UPB_DEFTYPE_ENUMVAL));

  _upb_EnumDef_Insert(ctx, e, v);
}

// Allocate and initialize an array of |n| enum value defs owned by |e|.
upb_EnumValueDef* _upb_EnumValueDefs_New(
    upb_DefBuilder* ctx, const char* prefix, int n,
    const google_protobuf_EnumValueDescriptorProto* const* protos,
    const google_protobuf_FeatureSet* parent_features, upb_EnumDef* e, bool* is_sorted) {
  _upb_DefType_CheckPadding(sizeof(upb_EnumValueDef));

  upb_EnumValueDef* v = UPB_DEFBUILDER_ALLOCARRAY(ctx, upb_EnumValueDef, n);

  *is_sorted = true;
  uint32_t previous = 0;
  for (int i = 0; i < n; i++) {
    create_enumvaldef(ctx, prefix, protos[i], parent_features, e, &v[i]);

    const uint32_t current = v[i].number;
    if (previous > current) *is_sorted = false;
    previous = current;
  }

  return v;
}
