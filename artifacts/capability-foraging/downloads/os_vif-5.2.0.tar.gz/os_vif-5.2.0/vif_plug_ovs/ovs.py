# Derived from nova/virt/libvirt/vif.py
#
# Copyright (C) 2011 Midokura KK
# Copyright (C) 2011 Nicira, Inc
# Copyright 2011 OpenStack Foundation
# All Rights Reserved.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

from __future__ import annotations

from typing import cast, TypeAlias, TypeGuard

from oslo_config import cfg
from oslo_log import log as logging

from os_vif import exception as osv_exception
from os_vif.internal.ip.api import ip as ip_lib
from os_vif import objects
from os_vif import plugin

from vif_plug_ovs import constants
from vif_plug_ovs import exception
from vif_plug_ovs import linux_net
from vif_plug_ovs.ovsdb import api as ovsdb_api
from vif_plug_ovs.ovsdb import ovsdb_lib

LOG = logging.getLogger(__name__)

_OVSVif: TypeAlias = ('objects.VIFBridge | objects.VIFOpenVSwitch | '
                      'objects.VIFVHostUser | objects.VIFHostDevice')


def _is_ovs_vif(vif: objects.VIFBase) -> TypeGuard[_OVSVif]:
    return isinstance(vif, (
        objects.vif.VIFBridge,
        objects.vif.VIFOpenVSwitch,
        objects.vif.VIFVHostUser,
        objects.vif.VIFHostDevice))


def is_trunk_bridge(bridge_name: str) -> bool:
    return bridge_name.startswith(constants.TRUNK_BR_PREFIX)


class OvsPlugin(plugin.PluginBase):
    """An OVS plugin that can setup VIFs in many ways

    The OVS plugin supports several different VIF types, VIFBridge
    and VIFOpenVSwitch, and will choose the appropriate plugging
    action depending on the type of VIF config it receives.

    If given a VIFBridge, then it will create connect the VM via
    a regular Linux bridge device to allow security group rules to
    be applied to VM traffic.
    """

    NIC_NAME_LEN = 14

    CONFIG_OPTS = [
        cfg.IntOpt('network_device_mtu',
                   default=1500,
                   help='MTU setting for network interface.',
                   deprecated_group="DEFAULT"),
        cfg.IntOpt('ovs_vsctl_timeout',
                   default=120,
                   help='Amount of time, in seconds, that ovs_vsctl should '
                   'wait for a response from the database. 0 is to wait '
                   'forever.',
                   deprecated_group="DEFAULT"),
        cfg.StrOpt('ovsdb_connection',
                   default='tcp:127.0.0.1:6640',
                   help='The connection string for the OVSDB backend. '
                   'When executing commands using the native or vsctl '
                   'ovsdb interface drivers this config option defines '
                   'the ovsdb endpoint used.'),
        cfg.StrOpt('ovsdb_interface',
                   choices=list(ovsdb_api.interface_map),
                   default='native',
                   deprecated_for_removal=True,
                   deprecated_since='2.2.0',
                   deprecated_reason="""
                   os-vif has supported ovsdb access via python bindings
                   since Stein (1.15.0), starting in Victoria (2.2.0) the
                   ovs-vsctl driver is now deprecated for removal and
                   in future releases it will be be removed.
                   """,
                   help='The interface for interacting with the OVSDB'),
        # NOTE(sean-k-mooney): This value is a bool for two reasons.
        # First I want to allow this config option to be reusable with
        # non ml2/ovs deployment in the future if required, as such I do not
        # want to encode how the isolation is done in the config option.
        # Second in the case of ml2/ovs the isolation is based on VLAN tags.
        # The 802.1Q IEEE spec that defines the VLAN format reserved two VLAN
        # id values, VLAN ID 0 means the packet is a member of no VLAN
        # and VLAN ID 4095 is reserved for implementation defined use.
        # Using VLAN ID 0 would not provide isolation and all other VLAN IDs
        # except VLAN ID 4095 are valid for the ml2/ovs agent to use for a
        # tenant network's local VLAN ID. As such only VLAN ID 4095 is valid
        # to use for vif isolation which is defined in Neutron as the
        # dead VLAN, a VLAN on which all traffic will be dropped.
        cfg.BoolOpt('isolate_vif', default=False,
                    help='Controls if VIF should be isolated when plugged '
                    'to the ovs bridge. This should only be set to True '
                    'when using the neutron ovs ml2 agent.'),
        cfg.BoolOpt('per_port_bridge', default=False,
                    help='Controls if VIF should be plugged into a per-port '
                    'bridge. This is experimental and controls the plugging '
                    'behavior when not using hybrid-plug.'
                    'This is only used on linux and should be set to false '
                    'in all other cases such as ironic smartnic ports.'),
        cfg.StrOpt('default_qos_type',
                   choices=[
                       'linux-htb', 'linux-hfsc', 'linux-sfq', 'linux-codel',
                       'linux-fq_codel', 'linux-noop'
                       ],
                   default='linux-noop',
                   help="""
                   The default qos type to apply to ovs ports.
                   linux-noop is the default. ovs will not modify
                   the qdisc on the port if linux-noop is specified.
                   This allows operators to manage QOS out of band
                   of OVS. For more information see the ovs man pages
                   https://manpages.debian.org/testing/openvswitch-common/ovs-vswitchd.conf.db.5.en.html#type~4

                   Note: This will only be set when a port is first created
                   on the ovs bridge to ensure that the qos type can be
                   managed via neutron if required for bandwidth limiting
                   and other use-cases.
                   """),
    ]

    def __init__(self, config: cfg.ConfigOpts.GroupAttr) -> None:
        super(OvsPlugin, self).__init__(config)
        self.ovsdb = ovsdb_lib.BaseOVS(self.config)

    @staticmethod
    def gen_port_name(
        prefix: str, vif_id: str, max_length: int = NIC_NAME_LEN
    ) -> str:
        return ("%s%s" % (prefix, vif_id))[:max_length]

    @staticmethod
    def get_veth_pair_names(
        vif: objects.VIFBridge | objects.VIFOpenVSwitch
    ) -> tuple[str, str]:
        return (OvsPlugin.gen_port_name("qvb", vif.id),
                OvsPlugin.gen_port_name("qvo", vif.id))

    @staticmethod
    def _get_vif_network(vif: _OVSVif) -> objects.Network:
        if 'network' not in vif:
            raise ValueError('VIF network is required')
        network = vif.network
        if network is None:
            raise ValueError('VIF network is required')
        return network

    @staticmethod
    def _get_vif_port_profile(
        vif: _OVSVif
    ) -> objects.VIFPortProfileOpenVSwitch:
        if 'port_profile' not in vif:
            raise exception.MissingPortProfile()
        profile = vif.port_profile
        if not isinstance(profile,
                          objects.vif.VIFPortProfileOpenVSwitch):
            raise exception.WrongPortProfile(
                profile=profile.__class__.__name__)
        return profile

    @staticmethod
    def _get_vif_address(vif: _OVSVif) -> str:
        if 'address' not in vif:
            raise ValueError('VIF address is required')
        address = vif.address
        if address is None:
            raise ValueError('VIF address is required')
        return address

    def describe(self) -> objects.HostPluginInfo:
        pp_ovs = objects.host_info.HostPortProfileInfo(
            profile_object_name=objects.vif.VIFPortProfileOpenVSwitch.__name__,  # noqa
            min_version="1.0",
            max_version="1.0",
        )
        pp_ovs_representor = objects.host_info.HostPortProfileInfo(
            profile_object_name=objects.vif.VIFPortProfileOVSRepresentor.__name__,  # noqa
            min_version="1.0",
            max_version="1.0",
        )
        return objects.host_info.HostPluginInfo(
            plugin_name=constants.PLUGIN_NAME,
            vif_info=[
                objects.host_info.HostVIFInfo(
                    vif_object_name=objects.vif.VIFBridge.__name__,
                    min_version="1.0",
                    max_version="1.0",
                    supported_port_profiles=[pp_ovs]),
                objects.host_info.HostVIFInfo(
                    vif_object_name=objects.vif.VIFOpenVSwitch.__name__,
                    min_version="1.0",
                    max_version="1.0",
                    supported_port_profiles=[pp_ovs]),
                objects.host_info.HostVIFInfo(
                    vif_object_name=objects.vif.VIFVHostUser.__name__,
                    min_version="1.0",
                    max_version="1.0",
                    supported_port_profiles=[pp_ovs, pp_ovs_representor]),
                objects.host_info.HostVIFInfo(
                    vif_object_name=objects.vif.VIFHostDevice.__name__,
                    min_version="1.0",
                    max_version="1.0",
                    supported_port_profiles=[pp_ovs, pp_ovs_representor]),
            ])

    def _get_mtu(self, vif: _OVSVif) -> int:
        network = self._get_vif_network(vif)
        if 'mtu' in network and network.mtu:
            return network.mtu
        # oslo.config is untyped
        return cast(int, self.config.network_device_mtu)

    def supports_tc_qdisc(self, vif: _OVSVif) -> bool:
        if self._get_vif_datapath_type(vif) != constants.OVS_DATAPATH_SYSTEM:
            return False
        return True

    def _isolate_vif(self, vif_name: str, bridge: str) -> bool:
        # NOTE(vsaienko): don't break traffic if port already exists,
        # we assume it is called when nova-compute is initialized and
        # since port is present it should be bound already.
        return (self.config.isolate_vif and
                not self.ovsdb.port_exists(vif_name, bridge))

    def _create_vif_port(
        self,
        vif: _OVSVif,
        vif_name: str,
        instance_info: objects.InstanceInfo,
        *,
        bridge: str | None = None,
        interface_type: str | None = None,
        vhost_server_path: str | None = None,
        pf_pci: str | None = None,
        vf_num: str | None = None,
        set_ids: bool = True,
        datapath_type: str | None = None,
    ) -> None:
        mtu = self._get_mtu(vif)
        network = self._get_vif_network(vif)
        profile = self._get_vif_port_profile(vif)
        address = self._get_vif_address(vif)
        # NOTE(sean-k-mooney): As part of a partial fix to bug #1734320
        # we introduced the isolate_vif config option to enable isolation
        # of the vif prior to neutron wiring up the interface. To do
        # this we take advantage of the fact the ml2/ovs uses the
        # implementation defined VLAN 4095 as a dead VLAN to indicate
        # that all packets should be dropped. We only enable this
        # behaviour conditionally as it is not portable to SDN based
        # deployment such as ODL or OVN as such operator must opt-in
        # to this behaviour by setting the isolate_vif config option.
        # TODO(sean-k-mooney): Extend neutron to record what ml2 driver
        # bound the interface in the vif binding details so isolation
        # can be enabled automatically in the future.
        bridge = bridge or network.bridge
        assert isinstance(bridge, str)  # narrow type

        tag: int | None = None
        vlan_mode: str | None = None
        trunks: int | None = None
        # See bug #2069543.
        if (self._isolate_vif(vif_name, bridge) and
                not is_trunk_bridge(bridge)):
            tag = constants.DEAD_VLAN
            vlan_mode = 'trunk'
            trunks = constants.DEAD_VLAN

        qos_type = self._get_qos_type(vif)
        if qos_type is not None:
            # NOTE(sean-k-mooney): If the port is not already created
            # on the bridge we need to set the default qos type to
            # ensure that the port is created with the correct qos
            # type. This is only needed for the linux kernel datapath
            # as the qos type is not managed by neutron for the other
            # datapaths.
            # This is a mitigation for the performance regression
            # introduced by the fix for bug #1734320. See bug #2017868
            # for more details.
            if self.ovsdb.port_exists(vif_name, bridge):
                qos_type = None

        self.ovsdb.create_ovs_vif_port(
            bridge,
            vif_name,
            profile.interface_id,
            address,
            instance_info.uuid,
            mtu=mtu,
            vhost_server_path=vhost_server_path,
            interface_type=interface_type,
            tag=tag,
            pf_pci=pf_pci,
            vf_num=vf_num,
            set_ids=set_ids,
            datapath_type=datapath_type,
            qos_type=qos_type,
            vlan_mode=vlan_mode,
            trunks=trunks,
        )

        # Check if tap creation is requested:
        # - 'field in profile.fields' checks if field exists in schema
        # - 'field in profile' checks if the attribute is set on instance
        create_tap = (
            isinstance(profile, objects.vif.VIFPortProfileOpenVSwitch) and
            'create_tap' in profile.fields and
            'create_tap' in profile and
            profile.create_tap
        )

        if create_tap:
            # Validate VIF type - only VIFOpenVSwitch supports tap creation
            if not isinstance(vif, objects.vif.VIFOpenVSwitch):
                raise exception.TapCreationNotSupported(
                    vif_type=vif.__class__.__name__)

            # Get multiqueue setting from port profile if available
            # 'field in profile.fields' checks schema, 'field in profile'
            # checks if the attribute is set
            multiqueue = ('multiqueue' in profile.fields and
                          'multiqueue' in profile and
                          profile.multiqueue)

            # Create the tap device with proper MAC and MTU if it doesn't
            # already exist (e.g., from a previous plug during init_host)
            if not ip_lib.exists(vif_name):
                linux_net.create_tap(
                    vif_name, mtu, address, multiqueue=multiqueue)

    def _update_vif_port(self, vif: _OVSVif, vif_name: str) -> None:
        mtu = self._get_mtu(vif)
        self.ovsdb.update_ovs_vif_port(vif_name, mtu)

    def _delete_tap_if_required(
        self, vif: _OVSVif, vif_name: str
    ) -> None:
        """Delete tap device if it was created via create_tap flag.

        :param vif: VIF object
        :param vif_name: Name of the tap device
        """
        # Check if this VIF had a tap device created for it:
        # - 'field in profile.fields' checks if field exists in schema
        # - 'field in profile' checks if the attribute is set on instance
        profile = getattr(vif, 'port_profile', None)
        create_tap = (
            profile is not None and
            isinstance(profile, objects.vif.VIFPortProfileOpenVSwitch) and
            isinstance(vif, objects.vif.VIFOpenVSwitch) and
            'create_tap' in profile.fields and
            'create_tap' in profile and
            profile.create_tap
        )

        if create_tap and ip_lib.exists(vif_name):
            linux_net.delete_net_dev(vif_name)

    @staticmethod
    def _get_vif_datapath_type(
        vif: _OVSVif, datapath: str = constants.OVS_DATAPATH_SYSTEM
    ) -> str | None:
        profile = OvsPlugin._get_vif_port_profile(vif)
        if 'datapath_type' not in profile or not profile.datapath_type:
            return datapath
        return profile.datapath_type

    def _plug_vhostuser(
        self, vif: objects.VIFVHostUser, instance_info: objects.InstanceInfo
    ) -> None:
        vif_name = OvsPlugin.gen_port_name(
            constants.OVS_VHOSTUSER_PREFIX, vif.id)
        datapath_type = self._get_vif_datapath_type(
            vif, datapath=constants.OVS_DATAPATH_NETDEV)
        if vif.mode == "client":
            self._create_vif_port(
                vif, vif_name, instance_info,
                interface_type=constants.OVS_VHOSTUSER_INTERFACE_TYPE,
                datapath_type=datapath_type,
            )
        else:
            self._create_vif_port(
                vif, vif_name, instance_info,
                interface_type=constants.OVS_VHOSTUSER_CLIENT_INTERFACE_TYPE,
                datapath_type=datapath_type,
                vhost_server_path=vif.path,
            )

    def _plug_bridge(
        self, vif: objects.VIFBridge, instance_info: objects.InstanceInfo
    ) -> None:
        """Plug using hybrid strategy

        Create a per-VIF linux bridge, then link that bridge to the OVS
        integration bridge via a veth device, setting up the other end
        of the veth device just like a normal OVS port. Then boot the
        VIF on the linux bridge using standard libvirt mechanisms.
        """

        v1_name, v2_name = self.get_veth_pair_names(vif)

        linux_net.ensure_bridge(vif.bridge_name)

        mtu = self._get_mtu(vif)
        network = self._get_vif_network(vif)
        if not ip_lib.exists(v2_name):
            linux_net.create_veth_pair(v1_name, v2_name, mtu)
            linux_net.add_bridge_port(vif.bridge_name, v1_name)
            self.ovsdb.ensure_ovs_bridge(
                network.bridge, self._get_vif_datapath_type(vif))
            self._create_vif_port(vif, v2_name, instance_info)
        else:
            linux_net.update_veth_pair(v1_name, v2_name, mtu)
            self._update_vif_port(vif, v2_name)

    def _plug_port_bridge(
        self, vif: objects.VIFOpenVSwitch, instance_info: objects.InstanceInfo
    ) -> None:
        """Create a per-VIF OVS bridge and patch pair."""

        # NOTE(sean-k-mooney): the port name prefix should not be
        # changed to avoid losing ports on upgrade.
        network = self._get_vif_network(vif)
        port_bridge_name = self.gen_port_name('pb', vif.id)
        port_bridge_patch = self.gen_port_name('pbp', vif.id, max_length=64)
        int_bridge_name = network.bridge
        int_bridge_patch = self.gen_port_name('ibp', vif.id, max_length=64)

        self.ovsdb.ensure_ovs_bridge(
             int_bridge_name, self._get_vif_datapath_type(vif))
        self.ovsdb.ensure_ovs_bridge(
            port_bridge_name, self._get_vif_datapath_type(vif))
        self._create_vif_port(
            vif, vif.vif_name, instance_info, bridge=port_bridge_name,
            set_ids=False
        )
        tag = (constants.DEAD_VLAN
               if self._isolate_vif(int_bridge_patch, int_bridge_name)
               else None)
        iface_id = vif.id
        mac = self._get_vif_address(vif)
        instance_id = instance_info.uuid
        LOG.debug(
            'creating patch port pair \n'
            f'{port_bridge_name}: ({port_bridge_patch}) -> '
            f'{int_bridge_name}: ({int_bridge_patch})'
        )
        self.ovsdb.create_patch_port_pair(
            port_bridge_name, port_bridge_patch, int_bridge_name,
            int_bridge_patch, iface_id, mac, instance_id, tag=tag)

    def _plug_vif_generic(
        self, vif: objects.VIFOpenVSwitch, instance_info: objects.InstanceInfo
    ) -> None:
        """Create a per-VIF OVS port."""
        network = self._get_vif_network(vif)
        profile = self._get_vif_port_profile(vif)
        self.ovsdb.ensure_ovs_bridge(
            network.bridge, self._get_vif_datapath_type(vif))
        # NOTE(sean-k-mooney): as part of a partial revert of
        # change Iaf15fa7a678ec2624f7c12f634269c465fbad930
        # (always create ovs port during plug), we stopped calling
        # self._create_vif_port(vif, vif.vif_name, instance_info).
        # Calling _create_vif_port here was intended to ensure
        # that the vif was wired up by neutron before the vm was
        # spawned on boot or live migration to partially resolve
        # #1734320. When the "always create ovs port during plug" change
        # was written it was understood by me that libvirt would not
        # modify ovs if the port exists but in fact it deletes and
        # recreates the port. This both undoes the effort to resolve
        # bug #1734320 and introduces other issues for neutron.
        # this comment will be removed when we actually fix #1734320 in
        # all cases.

        # NOTE(hamdyk): As a WA to the above note, one can use
        # VIFPortProfileOpenVSwitch.create_port flag to explicitly
        # plug the port to the switch.
        if ("create_port" in profile and profile.create_port):
            self._create_vif_port(vif, vif.vif_name, instance_info)

    def _plug_vf(
        self, vif: objects.VIFHostDevice, instance_info: objects.InstanceInfo
    ) -> None:
        datapath = self._get_vif_datapath_type(vif)
        network = self._get_vif_network(vif)
        self.ovsdb.ensure_ovs_bridge(network.bridge, datapath)
        pci_slot = vif.dev_address
        vf_num = linux_net.get_vf_num_by_pci_address(pci_slot)
        if datapath == constants.OVS_DATAPATH_SYSTEM:
            pf_ifname = linux_net.get_ifname_by_pci_address(
                pci_slot, pf_interface=True, switchdev=True)
            representor = linux_net.get_representor_port(pf_ifname, vf_num)
            linux_net.set_interface_state(representor, 'up')
            self._create_vif_port(vif, representor, instance_info)
        else:
            representor = linux_net.get_dpdk_representor_port_name(
                vif.id)
            pf_pci = linux_net.get_pf_pci_from_vf(pci_slot)
            self._create_vif_port(
                vif, representor, instance_info,
                interface_type=constants.OVS_DPDK_INTERFACE_TYPE,
                pf_pci=pf_pci,
                vf_num=vf_num,
            )

    def plug(
        self, vif: objects.VIFBase, instance_info: objects.InstanceInfo
    ) -> None:
        if 'port_profile' not in vif:
            raise exception.MissingPortProfile()
        if not isinstance(vif.port_profile,
                          objects.vif.VIFPortProfileOpenVSwitch):
            raise exception.WrongPortProfile(
                profile=vif.port_profile.__class__.__name__)
        if not _is_ovs_vif(vif):
            # This should never be raised.
            raise osv_exception.PlugException(
                vif=vif,
                err="This vif type is not supported by this plugin")

        if isinstance(vif, objects.vif.VIFOpenVSwitch):
            if self.config.per_port_bridge:
                self._plug_port_bridge(vif, instance_info)
            else:
                self._plug_vif_generic(vif, instance_info)
        elif isinstance(vif, objects.vif.VIFBridge):
            self._plug_bridge(vif, instance_info)
        elif isinstance(vif, objects.vif.VIFVHostUser):
            self._plug_vhostuser(vif, instance_info)
        elif isinstance(vif, objects.vif.VIFHostDevice):
            self._plug_vf(vif, instance_info)

    def _delete_bridge_if_trunk(self, vif: _OVSVif) -> None:
        network = self._get_vif_network(vif)
        if is_trunk_bridge(network.bridge):
            self.ovsdb.delete_ovs_bridge(network.bridge)

    def _unplug_vhostuser(
        self, vif: objects.VIFVHostUser, instance_info: objects.InstanceInfo
    ) -> None:
        network = self._get_vif_network(vif)
        self.ovsdb.delete_ovs_vif_port(network.bridge,
            OvsPlugin.gen_port_name(
                constants.OVS_VHOSTUSER_PREFIX,
                vif.id))
        self._delete_bridge_if_trunk(vif)

    def _unplug_bridge(
        self,
        vif: objects.VIFBridge | objects.VIFOpenVSwitch,
        instance_info: objects.InstanceInfo,
        linux_bridge_name: str,
    ) -> None:
        """Unplug using hybrid strategy

        Unhook port from OVS, unhook port from bridge, delete
        bridge, and delete both veth devices.
        """

        v1_name, v2_name = self.get_veth_pair_names(vif)

        linux_net.delete_bridge(linux_bridge_name, v1_name)

        qos_type = self._get_qos_type(vif)
        network = self._get_vif_network(vif)
        self.ovsdb.delete_ovs_vif_port(
            network.bridge, v2_name, qos_type=qos_type
        )
        self._delete_bridge_if_trunk(vif)

    def _get_qos_type(self, vif: _OVSVif) -> str | None:
        qos_type = None
        if self.supports_tc_qdisc(vif):
            qos_type = cast(str, self.config.default_qos_type)
        return qos_type

    def _unplug_port_bridge(
        self, vif: objects.VIFOpenVSwitch, instance_info: objects.InstanceInfo
    ) -> None:
        """Create a per-VIF OVS bridge and patch pair."""
        # Delete tap device if it was created
        self._delete_tap_if_required(vif, vif.vif_name)

        # NOTE(sean-k-mooney): the port name prefix should not be
        # changed to avoid loosing ports on upgrade.
        network = self._get_vif_network(vif)
        port_bridge_name = self.gen_port_name('pb', vif.id)
        port_bridge_patch = self.gen_port_name('pbp', vif.id, max_length=64)
        int_bridge_patch = self.gen_port_name('ibp', vif.id, max_length=64)
        self.ovsdb.delete_ovs_vif_port(network.bridge, int_bridge_patch)
        self.ovsdb.delete_ovs_vif_port(port_bridge_name, port_bridge_patch)
        qos_type = self._get_qos_type(vif)
        self.ovsdb.delete_ovs_vif_port(
            port_bridge_name, vif.vif_name, qos_type=qos_type
        )
        self.ovsdb.delete_ovs_bridge(port_bridge_name)
        self._delete_bridge_if_trunk(vif)

    def _unplug_vif_generic(
        self, vif: objects.VIFOpenVSwitch, instance_info: objects.InstanceInfo
    ) -> None:
        """Remove port from OVS."""
        # Delete tap device if it was created
        self._delete_tap_if_required(vif, vif.vif_name)

        # NOTE(sean-k-mooney): even with the partial revert of change
        # Iaf15fa7a678ec2624f7c12f634269c465fbad930 this should be correct
        # so this is not removed.
        qos_type = self._get_qos_type(vif)
        network = self._get_vif_network(vif)
        self.ovsdb.delete_ovs_vif_port(
            network.bridge, vif.vif_name, qos_type=qos_type
        )
        self._delete_bridge_if_trunk(vif)

    def _unplug_vf(self, vif: objects.VIFHostDevice) -> None:
        """Remove port from OVS."""
        datapath = self._get_vif_datapath_type(vif)
        if datapath == constants.OVS_DATAPATH_SYSTEM:
            pci_slot = vif.dev_address
            pf_ifname = linux_net.get_ifname_by_pci_address(
                pci_slot, pf_interface=True, switchdev=True)
            vf_num = linux_net.get_vf_num_by_pci_address(pci_slot)
            representor = linux_net.get_representor_port(pf_ifname, vf_num)
        else:
            representor = linux_net.get_dpdk_representor_port_name(
                vif.id)

        # The representor interface can't be deleted because it bind the
        # SR-IOV VF, therefore we just need to remove it from the ovs bridge
        # and set the status to down
        qos_type = self._get_qos_type(vif)
        network = self._get_vif_network(vif)
        self.ovsdb.delete_ovs_vif_port(
            network.bridge, representor, delete_netdev=False,
            qos_type=qos_type
        )
        if datapath == constants.OVS_DATAPATH_SYSTEM:
            linux_net.set_interface_state(representor, 'down')
        self._delete_bridge_if_trunk(vif)

    def unplug(
        self, vif: objects.VIFBase, instance_info: objects.InstanceInfo
    ) -> None:
        if 'port_profile' not in vif:
            raise exception.MissingPortProfile()
        if not isinstance(vif.port_profile,
                          objects.vif.VIFPortProfileOpenVSwitch):
            raise exception.WrongPortProfile(
                profile=vif.port_profile.__class__.__name__)
        if not _is_ovs_vif(vif):
            # this should never be raised.
            raise osv_exception.UnplugException(
                vif=vif,
                err="This vif type is not supported by this plugin")
        if isinstance(vif, objects.vif.VIFOpenVSwitch):
            if self.config.per_port_bridge:
                self._unplug_port_bridge(vif, instance_info)
            else:
                linux_bridge_name = self.gen_port_name('qbr', vif.id)
                if ip_lib.exists(linux_bridge_name):
                    self._unplug_bridge(vif, instance_info, linux_bridge_name)
                else:
                    self._unplug_vif_generic(vif, instance_info)
        elif isinstance(vif, objects.vif.VIFBridge):
            self._unplug_bridge(vif, instance_info, vif.bridge_name)
        elif isinstance(vif, objects.vif.VIFVHostUser):
            self._unplug_vhostuser(vif, instance_info)
        elif isinstance(vif, objects.vif.VIFHostDevice):
            self._unplug_vf(vif)
