# Copyright (C) 2011 Midokura KK
# Copyright (C) 2011 Nicira, Inc
# Copyright 2011 OpenStack Foundation
# Copyright 2018 Intel Corporation
# All Rights Reserved.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

from __future__ import annotations

from os_vif import objects
from os_vif import plugin


class NoOpPlugin(plugin.PluginBase):
    """A no op plugin

    The no op plugin can be used for any vif type that requires
    no action to be performed on the backend network when a vif
    is plugged. Currently only the VIFVHostUser VIF type is supported.
    This pluggin allows for the use of generic vhost user without ovs.

    """

    def describe(self) -> objects.HostPluginInfo:
        return objects.host_info.HostPluginInfo(
            plugin_name="noop",
            vif_info=[
                objects.host_info.HostVIFInfo(
                    vif_object_name=objects.vif.VIFVHostUser.__name__,
                    min_version="1.0",
                    max_version="1.0",
                    supported_port_profiles=[])
            ])

    def plug(
        self, vif: objects.VIFBase, instance_info: objects.InstanceInfo
    ) -> None:
        pass

    def unplug(
        self, vif: objects.VIFBase, instance_info: objects.InstanceInfo
    ) -> None:
        pass
