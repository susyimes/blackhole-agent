# Changelog

All notable changes to this project will be documented in this file. See [standard-version](https://github.com/conventional-changelog/standard-version) for commit guidelines.

## [2.0.0](https://github.com/crosstype/node-html-markdown/compare/v1.3.0...v2.0.0) (2025-11-14)


### ⚠ BREAKING CHANGES

* Explicitly deny special handling for elements that should not be inside codeblocks

* Explicitly deny special handling for elements that should not be inside codeblocks ([80fd704](https://github.com/crosstype/node-html-markdown/commit/80fd70449ce820cf550ba7439a5e089f211741e5))


### Fixes

* correct nested list indentation to 2 spaces (fixes [#57](https://github.com/crosstype/node-html-markdown/issues/57)) ([9358ccc](https://github.com/crosstype/node-html-markdown/commit/9358ccc3103cd3099d1ee1f491ee9c99f58c9ddc))
* eliminate circular dependency between config and utilities (fixes [#74](https://github.com/crosstype/node-html-markdown/issues/74)) ([3934406](https://github.com/crosstype/node-html-markdown/commit/3934406eab11854fa8f98649967453f63368cce3))
* fixed table parsing issue (closes [#38](https://github.com/crosstype/node-html-markdown/issues/38), closes [#47](https://github.com/crosstype/node-html-markdown/issues/47)) ([5ac217a](https://github.com/crosstype/node-html-markdown/commit/5ac217aba1ae7818a7f5ccb70c013eaf40c9d9cb))
* handle mixed-case HTML tags correctly (fixes [#63](https://github.com/crosstype/node-html-markdown/issues/63)) ([9016420](https://github.com/crosstype/node-html-markdown/commit/9016420e200208c886cc3cb2b45b078c6fa4134b))
* Ignore options overwritten if block element. (fixes [#49](https://github.com/crosstype/node-html-markdown/issues/49)) ([bdc0d09](https://github.com/crosstype/node-html-markdown/commit/bdc0d0900c00ffaa5c87d326985372ce21ba5009))
* preserve whitespace and newlines in code blocks (fixes [#52](https://github.com/crosstype/node-html-markdown/issues/52), [#24](https://github.com/crosstype/node-html-markdown/issues/24)) ([372be6d](https://github.com/crosstype/node-html-markdown/commit/372be6d688c6473f0ad0cc34c6333f79793f2268))
* preserve whitespace before inline formatting elements (fixes [#61](https://github.com/crosstype/node-html-markdown/issues/61), fixes [#34](https://github.com/crosstype/node-html-markdown/issues/34)) ([ba035e6](https://github.com/crosstype/node-html-markdown/commit/ba035e68dc05b2348444644b82fc49b168d0794b))
* Prevent backslash escaping in tables within list items (fixes [#60](https://github.com/crosstype/node-html-markdown/issues/60)) ([f15e482](https://github.com/crosstype/node-html-markdown/commit/f15e4823e2354fd40e44764b5e8c2f87f3f8d931))
* remove perf functions from browser builds (fixes [#58](https://github.com/crosstype/node-html-markdown/issues/58)) ([d1552fd](https://github.com/crosstype/node-html-markdown/commit/d1552fd712f4752608ea12885f306c1aec2984a6))
* trim trailing whitespace while preserving two-space line breaks ([c0062b8](https://github.com/crosstype/node-html-markdown/commit/c0062b8027ffbcf96edf7013c89518f95c2327e6))

## [1.3.0](https://github.com/crosstype/node-html-markdown/compare/v1.2.0...v1.3.0) (2022-12-13)


### Features

* Added `useInlineLinks` option ([c318667](https://github.com/crosstype/node-html-markdown/commit/c318667334d979db3cf7bcd3600f9dd1618ba5b3))
* Added option to customize custom strike tag. ([82cf1e3](https://github.com/crosstype/node-html-markdown/commit/82cf1e3c33662254983f35bb2000c62fc3d5870c))


### Fixes

* Can't get text from TextNode in the browser (fixes [#40](https://github.com/crosstype/node-html-markdown/issues/40)) ([feec660](https://github.com/crosstype/node-html-markdown/commit/feec6609cc4ad5c00ce81835d60c3a00036f82e7))
* perfStart and perfStop breaking code in the browser (fixes [#36](https://github.com/crosstype/node-html-markdown/issues/36) ([7d52c92](https://github.com/crosstype/node-html-markdown/commit/7d52c928b718acae578692736cda1f17d4733ab1))

### [1.2.2](https://github.com/crosstype/node-html-markdown/compare/v1.2.0...v1.2.2) (2022-10-26)


### Fixes

* Can't get text from TextNode in the browser (fixes [#40](https://github.com/crosstype/node-html-markdown/issues/40)) ([feec660](https://github.com/crosstype/node-html-markdown/commit/feec6609cc4ad5c00ce81835d60c3a00036f82e7))
* perfStart and perfStop breaking code in the browser (fixes [#36](https://github.com/crosstype/node-html-markdown/issues/36) ([7d52c92](https://github.com/crosstype/node-html-markdown/commit/7d52c928b718acae578692736cda1f17d4733ab1))

## [1.2.0](https://github.com/crosstype/node-html-markdown/compare/v1.1.3...v1.2.0) (2022-04-20)


### Features

* Added table support ([faaebe8](https://github.com/crosstype/node-html-markdown/commit/faaebe8b8b85a6e4680a286f24ff963db097cc66))

### [1.1.3](https://github.com/crosstype/node-html-markdown/compare/v1.1.2...v1.1.3) (2021-10-24)


### Fixes

* Percent-encode Markdown reserved symbols in URLs ([#26](https://github.com/crosstype/node-html-markdown/issues/26)) ([83d4fff](https://github.com/crosstype/node-html-markdown/commit/83d4fff866eb027ebba052ab45996f679412c42b))

### [1.1.2](https://github.com/crosstype/node-html-markdown/compare/v1.1.1...v1.1.2) (2021-09-18)


### Fixes

* **upstream:** Parser dependency parses invalid nested A improperly (closes [#25](https://github.com/crosstype/node-html-markdown/issues/25)) ([bdc7caa](https://github.com/crosstype/node-html-markdown/commit/bdc7caaac615428c89729f30b23fa2a29d9a6c56))
* Correct nesting and other possible issues in child nodes of A tag (closes [#25](https://github.com/crosstype/node-html-markdown/issues/25)) ([dcd6b20](https://github.com/crosstype/node-html-markdown/commit/dcd6b209f630335c314d67e47fd2290218bd6e79))

### [1.1.1](https://github.com/crosstype/node-html-markdown/compare/v1.1.0...v1.1.1) (2021-08-03)


### Fixes

* Preformatted code block node contents getting trimmed (fixes [#20](https://github.com/crosstype/node-html-markdown/issues/20)) ([af79995](https://github.com/crosstype/node-html-markdown/commit/af799956d94d7a06c50df71746bcfac8f31e342e))

## [1.1.0](https://github.com/crosstype/node-html-markdown/compare/v1.0.1...v1.1.0) (2021-07-26)


### Features

* Added `preserveIfEmpty` translator option to allow triggering translators that do not have children (closes [#19](https://github.com/crosstype/node-html-markdown/issues/19)) ([c3d8829](https://github.com/crosstype/node-html-markdown/commit/c3d88296de6c51b016524406021718218d0c412b))


### Fixes

* Codeblocks apply markdown formatting to contents (fixes [#22](https://github.com/crosstype/node-html-markdown/issues/22)) ([040f81e](https://github.com/crosstype/node-html-markdown/commit/040f81edde8ec21e393a2b38273f9427751bfad2))
* Whitespace not always properly handled (fixes [#20](https://github.com/crosstype/node-html-markdown/issues/20) [#21](https://github.com/crosstype/node-html-markdown/issues/21)) ([8c43a22](https://github.com/crosstype/node-html-markdown/commit/8c43a22c3da5a5f5134fc52e08015b476cfbbb45))

### [1.0.1](https://github.com/crosstype/node-html-markdown/compare/v1.0.0...v1.0.1) (2021-07-13)


### Fixes

* Whitespace between some nodes not properly handled (fixes [#16](https://github.com/crosstype/node-html-markdown/issues/16)) ([a7abf81](https://github.com/crosstype/node-html-markdown/commit/a7abf81add691e199587ca85600fb0f4c6876a01))

## [1.0.0](https://github.com/crosstype/node-html-markdown/compare/v0.1.7...v1.0.0) (2021-07-11)


### Features

* Add useLinkReferenceDefinitions option (closes [#15](https://github.com/crosstype/node-html-markdown/issues/15)) ([a7caef1](https://github.com/crosstype/node-html-markdown/commit/a7caef106a37a5de618e7072ed4e329a1c4c4f95))
* Improved spacing in and around bold, italic, and strikethrough tags ([8198524](https://github.com/crosstype/node-html-markdown/commit/8198524680ec3e6e5d8578b18fe58067158774bb))
* Prefer <inline> links when possible (closes [#17](https://github.com/crosstype/node-html-markdown/issues/17)) ([613e8bb](https://github.com/crosstype/node-html-markdown/commit/613e8bb5d39ca84efcce13c33c1fda8206a9d924))


### Fixes

* Ensure html entities are decoded (Fixes [#14](https://github.com/crosstype/node-html-markdown/issues/14)) ([1e59887](https://github.com/crosstype/node-html-markdown/commit/1e59887ea9baea37d72d977943cfda936e925924))
* Nested text formatting tags can break formatting (fixes [#18](https://github.com/crosstype/node-html-markdown/issues/18)) ([7640e33](https://github.com/crosstype/node-html-markdown/commit/7640e334936e6cd678cc1ea960b77135832afd55))

### [0.1.7](https://github.com/crosstype/node-html-markdown/compare/v0.1.6...v0.1.7) (2021-06-11)


### Fixes

* Allow for leading/trailing spaces in node content (fixes [#9](https://github.com/crosstype/node-html-markdown/issues/9)) ([ff61746](https://github.com/crosstype/node-html-markdown/commit/ff617463d9a0c18f5c58f31feda0c06a69a34d27))

### [0.1.6](https://github.com/crosstype/node-html-markdown/compare/v0.1.5...v0.1.6) (2021-03-28)


### Fixes

* **tsconfig:** Set output target to es2017 to support Node v10+ (Fixes [#7](https://github.com/crosstype/node-html-markdown/issues/7)) ([#8](https://github.com/crosstype/node-html-markdown/issues/8)) ([dd63205](https://github.com/crosstype/node-html-markdown/commit/dd63205a5019ab84ac5010cf0e2f06cbc5ffabb2))

### [0.1.5](https://github.com/crosstype/node-html-markdown/compare/v0.1.4...v0.1.5) (2021-01-03)

### [0.1.3](https://github.com/crosstype/node-html-markdown/compare/v0.1.2...v0.1.3) (2020-11-28)


### Fixes

* Fixed performance bottleneck (doubled speed) ([6d59c27](https://github.com/crosstype/node-html-markdown/commit/6d59c275f5f812d998ad36c09aeafa84191ed0a9))

### [0.1.2](https://github.com/crosstype/node-html-markdown/compare/v0.1.1...v0.1.2) (2020-11-28)


### Fixes

* Fixed wrong install instructions in readme ([e76df44](https://github.com/crosstype/node-html-markdown/commit/e76df44d3244888238a8962b5559e3a19a53675b))

### [0.1.1](https://github.com/crosstype/node-html-markdown/compare/v0.0.3...v0.1.1) (2020-11-28)


### Fixes

* Fixed broken benchmark file speed stats ([d12b702](https://github.com/crosstype/node-html-markdown/commit/d12b702274a2872d38d2b53269929002fc3924b7))


## [0.1.0](https://github.com/crosstype/node-html-markdown/compare/v0.0.3...v0.1.0) (2020-11-28)


### Features

* Added performance enhancements + improved benchmark display ([4777441](https://github.com/crosstype/node-html-markdown/commit/477744167d4e1ffce8c7bcbfbc34b5cd88aabf74))


## [0.0.5](https://github.com/crosstype/node-html-markdown/v0.0.0...v0.0.5) - 2020-11-27

- Released initial version
