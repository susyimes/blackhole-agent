{
    "host": "%(host)s"
}
