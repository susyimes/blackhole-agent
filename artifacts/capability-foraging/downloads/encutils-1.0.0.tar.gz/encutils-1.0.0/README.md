[![](https://img.shields.io/pypi/v/encutils)](https://pypi.org/project/encutils)

![](https://img.shields.io/pypi/pyversions/encutils)

[![](https://github.com/coherent-oss/encutils/actions/workflows/main.yml/badge.svg)](https://github.com/coherent-oss/encutils/actions?query=workflow%3A%22tests%22)

[![Ruff](https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/astral-sh/ruff/main/assets/badge/v2.json)](https://github.com/astral-sh/ruff)

[![Coherent Software Development System](https://img.shields.io/badge/coherent%20system-informational)](https://github.com/coherent-oss/system)

