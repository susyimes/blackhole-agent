
1.1.1 (2026-04-26)
------------------

Improvements:

- Improved type checking with mypy and pyright.

Bug fixes:

- Fixed typing on `PathSpec[TPattern]` to `PathSpec[TPattern_co]`.
- Added missing variant type-hint `type[Pattern]` to `PathSpec.from_lines()` parameter `pattern_factory`.
- Fixed possible type error when using `+` and `+=` operators on `PathSpec`.


1.1.0 (2026-04-22)
------------------

New features:

- `Issue #108`_: Specialize pattern type for `PathSpec` as `PathSpec[TPattern]` for better debugging of `PathSpec().patterns`.

Bug fixes:

- `Issue #93`_: Git discards invalid range notation. `GitIgnoreSpecPattern` now discards patterns with invalid range notation like Git.
- `Pull #106`_: Fix escape() not escaping backslash characters.

Improvements:

- `Pull #110`_: Nicer debug print outs (and str for regex pattern).


.. _`Pull #106`: https://github.com/cpburnz/python-pathspec/pull/106
.. _`Issue #108`: https://github.com/cpburnz/python-pathspec/issues/108
.. _`Pull #110`: https://github.com/cpburnz/python-pathspec/pull/110


1.0.4 (2026-01-26)
------------------

Bug fixes:

- `Issue #103`_: Using re2 fails if pyre2 is also installed.

.. _`Issue #103`: https://github.com/cpburnz/python-pathspec/issues/103


1.0.3 (2026-01-09)
------------------

Bug fixes:

- `Issue #101`_: pyright strict errors with pathspec >= 1.0.0.
- `Issue #102`_: No module named 'tomllib'.


.. _`Issue #101`: https://github.com/cpburnz/python-pathspec/issues/101
.. _`Issue #102`: https://github.com/cpburnz/python-pathspec/issues/102


1.0.2 (2026-01-07)
------------------

Bug fixes:

- Type hint `collections.abc.Callable` does not properly replace `typing.Callable` until Python 3.9.2.


1.0.1 (2026-01-06)
------------------

Bug fixes:

- `Issue #100`_: ValueError(f"{patterns=!r} cannot be empty.") when using black.


.. _`Issue #100`: https://github.com/cpburnz/python-pathspec/issues/100


1.0.0 (2026-01-05)
------------------

Major changes:

- `Issue #91`_: Dropped support of EoL Python 3.8.
- Added concept of backends to allow for faster regular expression matching. The backend can be controlled using the `backend` argument to `PathSpec()`, `PathSpec.from_lines()`, `GitIgnoreSpec()`, and `GitIgnoreSpec.from_lines()`.
- Renamed "gitwildmatch" pattern back to "gitignore". The "gitignore" pattern behaves slightly differently when used with `PathSpec` (*gitignore* as documented) than with `GitIgnoreSpec` (replicates *Git*'s edge cases).

API changes:

- Breaking: protected method `pathspec.pathspec.PathSpec._match_file()` (with a leading underscore) has been removed and replaced by backends. This does not affect normal usage of `PathSpec` or `GitIgnoreSpec`. Only custom subclasses will be affected. If this breaks your usage, let me know by `opening an issue <https://github.com/cpburnz/python-pathspec/issues>`_.
- Deprecated: "gitwildmatch" is now an alias for "gitignore".
- Deprecated: `pathspec.patterns.GitWildMatchPattern` is now an alias for `pathspec.patterns.gitignore.spec.GitIgnoreSpecPattern`.
- Deprecated: `pathspec.patterns.gitwildmatch` module has been replaced by the `pathspec.patterns.gitignore` package.
- Deprecated: `pathspec.patterns.gitwildmatch.GitWildMatchPattern` is now an alias for `pathspec.patterns.gitignore.spec.GitIgnoreSpecPattern`.
- Deprecated: `pathspec.patterns.gitwildmatch.GitWildMatchPatternError` is now an alias for `pathspec.patterns.gitignore.GitIgnorePatternError`.
- Removed: `pathspec.patterns.gitwildmatch.GitIgnorePattern` has been deprecated since v0.4 (2016-07-15).
- Signature of method `pathspec.pattern.RegexPattern.match_file()` has been changed from `def match_file(self, file: str) -> RegexMatchResult | None` to `def match_file(self, file: AnyStr) -> RegexMatchResult | None` to reflect usage.
- Signature of class method `pathspec.pattern.RegexPattern.pattern_to_regex()` has been changed from `def pattern_to_regex(cls, pattern: str) -> tuple[str, bool]` to `def pattern_to_regex(cls, pattern: AnyStr) -> tuple[AnyStr | None, bool | None]` to reflect usage and documentation.

New features:

- Added optional "hyperscan" backend using `hyperscan`_ library. It will automatically be used when installed. This dependency can be installed with ``pip install 'pathspec[hyperscan]'``.
- Added optional "re2" backend using the `google-re2`_ library. It will automatically be used when installed. This dependency can be installed with ``pip install 'pathspec[re2]'``.
- Added optional dependency on `typing-extensions`_ library to improve some type hints.

Bug fixes:

- `Issue #93`_: Do not remove leading spaces.
- `Issue #95`_: Matching for files inside folder does not seem to behave like .gitignore's.
- `Issue #98`_: UnboundLocalError in RegexPattern when initialized with `pattern=None`.
- Type hint on return value of `pathspec.pattern.RegexPattern.match_file()` to match documentation.

Improvements:

- Mark Python 3.13 and 3.14 as supported.
- No-op patterns are now filtered out when matching files, slightly improving performance.
- Fix performance regression in `iter_tree_files()` from v0.10.


.. _`Issue #38`: https://github.com/cpburnz/python-pathspec/issues/38
.. _`Issue #91`: https://github.com/cpburnz/python-pathspec/issues/91
.. _`Issue #93`: https://github.com/cpburnz/python-pathspec/issues/93
.. _`Issue #95`: https://github.com/cpburnz/python-pathspec/issues/95
.. _`Issue #98`: https://github.com/cpburnz/python-pathspec/issues/98
.. _`google-re2`: https://pypi.org/project/google-re2/
.. _`hyperscan`: https://pypi.org/project/hyperscan/
.. _`typing-extensions`: https://pypi.org/project/typing-extensions/
