"""Defines custom Rich styles and their corresponding names for cmd2.

This module provides a centralized and discoverable way to manage Rich styles
used within the cmd2 framework. It defines a StrEnum for style names and a
dictionary that maps these names to their default style objects.

**Notes**

Cmd2 uses Rich for its terminal output, and while this module defines a set of
cmd2-specific styles, it's important to understand that these aren't the only
styles that can appear. Components like Rich tracebacks and the rich-argparse
library, which cmd2 uses for its help output, also apply their own built-in
styles. Additionally, app developers may use other Rich objects that have
their own default styles.

For a complete theming experience, you can create a custom theme that includes
styles from Rich and rich-argparse. The `cmd2.theme.update_theme()` function
automatically updates rich-argparse's styles with any custom styles provided in
your theme dictionary, so you don't have to modify them directly.

You can find Rich's default styles in the `rich.default_styles` module.
For rich-argparse, the style names are defined in the
`rich_argparse.RichHelpFormatter.styles` dictionary.

For prompt-toolkit default styles, see:
https://github.com/prompt-toolkit/python-prompt-toolkit/blob/main/src/prompt_toolkit/styles/defaults.py
"""

from enum import StrEnum

from rich.style import (
    Style,
    StyleType,
)
from rich_argparse import RichHelpFormatter

from .colors import Color


class Cmd2Style(StrEnum):
    """An enumeration of the names of custom Rich styles used in cmd2.

    Using this enum allows for autocompletion and prevents typos when
    referencing cmd2-specific styles.

    This StrEnum is tightly coupled with `DEFAULT_CMD2_STYLES`. Any name
    added here must have a corresponding style definition there.
    """

    COMMAND_LINE = "cmd2.example"  # Command line examples in help text
    COMPLETION_MENU = "cmd2.completion-menu"  # Base style for the entire completion menu container (sets the background)
    COMPLETION_MENU_COMPLETION = "cmd2.completion-menu.completion"  # Style for an individual, non-selected completion item
    COMPLETION_MENU_CURRENT = "cmd2.completion-menu.completion.current"  # Style for the currently selected completion item
    COMPLETION_MENU_META = "cmd2.completion-menu.meta.completion"  # Style for meta information shown alongside a completion
    COMPLETION_MENU_META_CURRENT = "cmd2.completion-menu.meta.completion.current"  # Style for meta information of current item
    ERROR = "cmd2.error"  # Error text (used by perror())
    HELP_HEADER = "cmd2.help.header"  # Help table header text
    HELP_LEADER = "cmd2.help.leader"  # Text right before the help tables are listed
    LEXER_COMMAND = "cmd2.lexer.command"  # Lexer color for commands
    LEXER_ALIAS = "cmd2.lexer.alias"  # Lexer color for aliases
    LEXER_MACRO = "cmd2.lexer.macro"  # Lexer color for macros
    LEXER_FLAG = "cmd2.lexer.flag"  # Lexer color for flags
    LEXER_ARGUMENT = "cmd2.lexer.argument"  # Lexer color for arguments
    SUCCESS = "cmd2.success"  # Success text (used by psuccess())
    TABLE_BORDER = "cmd2.table_border"  # Applied to cmd2's table borders
    WARNING = "cmd2.warning"  # Warning text (used by pwarning())


# Default styles used by cmd2. Used to perform theme resets.
# Tightly coupled with the Cmd2Style enum.
DEFAULT_CMD2_STYLES: dict[str, StyleType] = {
    Cmd2Style.COMMAND_LINE: Style(color=Color.CYAN, bold=True),
    Cmd2Style.COMPLETION_MENU: Style(color="#000000", bgcolor="#bbbbbb"),  # prompt-toolkit default
    Cmd2Style.COMPLETION_MENU_COMPLETION: Style(),  # prompt-toolkit default
    # Defined with swapped FG/BG colors because prompt-toolkit applies 'reverse' by default.
    # This yields a black-on-green highlight in color mode, while maintaining a fallback
    # reverse-video highlight when colors are disabled (e.g. NO_COLOR=1 or allow_style=never).
    Cmd2Style.COMPLETION_MENU_CURRENT: Style(color=Color.GREEN, bgcolor=Color.BLACK),
    Cmd2Style.COMPLETION_MENU_META: Style(color="#000000", bgcolor="#bbbbbb"),  # prompt-toolkit default
    Cmd2Style.COMPLETION_MENU_META_CURRENT: Style(color=Color.BLACK, bgcolor=Color.BRIGHT_GREEN),
    Cmd2Style.ERROR: Style(color=Color.BRIGHT_RED),
    Cmd2Style.HELP_HEADER: Style(color=Color.BRIGHT_GREEN),
    Cmd2Style.HELP_LEADER: Style(color=Color.CYAN),
    Cmd2Style.LEXER_COMMAND: Style(color=Color.GREEN),
    Cmd2Style.LEXER_ALIAS: Style(color=Color.CYAN),
    Cmd2Style.LEXER_MACRO: Style(color=Color.MAGENTA),
    Cmd2Style.LEXER_FLAG: Style(color=Color.RED),
    Cmd2Style.LEXER_ARGUMENT: Style(color=Color.YELLOW),
    Cmd2Style.SUCCESS: Style(color=Color.GREEN),
    Cmd2Style.TABLE_BORDER: Style(color=Color.BRIGHT_GREEN),
    Cmd2Style.WARNING: Style(color=Color.BRIGHT_YELLOW),
}

# Default styles for argparse output. Used to perform theme resets.
# Any cmd2-specific settings or overrides should be added to this dictionary.
DEFAULT_ARGPARSE_STYLES = RichHelpFormatter.styles.copy()
