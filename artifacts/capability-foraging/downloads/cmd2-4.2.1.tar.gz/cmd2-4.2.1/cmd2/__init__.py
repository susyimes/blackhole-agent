"""Import certain things for backwards compatibility."""

import contextlib
import importlib.metadata as importlib_metadata

with contextlib.suppress(importlib_metadata.PackageNotFoundError):
    __version__ = importlib_metadata.version(__name__)

from . import (
    plugin,
    rich_utils,
    string_utils,
)
from .annotated import (
    ArgumentBlock,
    with_annotated,
)
from .argparse_completer import set_default_argparse_completer
from .argparse_utils import (
    Cmd2ArgumentParser,
    SubcommandRecord,
    register_argparse_argument_parameter,
    set_default_argument_parser,
)
from .cmd2 import Cmd
from .colors import Color
from .command_set import CommandSet
from .completion import (
    Choices,
    CompletionItem,
    Completions,
)
from .constants import (
    COMMAND_NAME,
    DEFAULT_SHORTCUTS,
)
from .decorators import (
    as_subcommand_to,
    with_argparser,
    with_argument_list,
    with_category,
)
from .exceptions import (
    Cmd2ArgparseError,
    CommandSetRegistrationError,
    CompletionError,
    PassThroughException,
    SkipPostcommandHooks,
)
from .parsing import Statement
from .py_bridge import CommandResult
from .rich_utils import (
    ArgumentDefaultsCmd2HelpFormatter,
    Cmd2HelpFormatter,
    MetavarTypeCmd2HelpFormatter,
    RawDescriptionCmd2HelpFormatter,
    RawTextCmd2HelpFormatter,
    TextGroup,
)
from .string_utils import stylize
from .styles import Cmd2Style
from .theme import (
    get_theme,
    reset_theme,
    update_theme,
)
from .utils import (
    CustomCompletionSettings,
    Settable,
    categorize,
    set_default_str_sort_key,
)

__all__: list[str] = [  # noqa: RUF022
    "COMMAND_NAME",
    "DEFAULT_SHORTCUTS",
    # Argparse Exports
    "Cmd2ArgumentParser",
    "SubcommandRecord",
    "register_argparse_argument_parameter",
    "set_default_argparse_completer",
    "set_default_argument_parser",
    # Cmd2
    "Cmd",
    "CommandResult",
    "CommandSet",
    "Statement",
    # Colors
    "Color",
    # Completion
    "Choices",
    "CompletionItem",
    "Completions",
    # Annotated commands
    "ArgumentBlock",
    # Decorators
    "with_annotated",
    "with_argument_list",
    "with_argparser",
    "with_category",
    "as_subcommand_to",
    # Exceptions
    "Cmd2ArgparseError",
    "CommandSetRegistrationError",
    "CompletionError",
    "PassThroughException",
    "SkipPostcommandHooks",
    # modules
    "plugin",
    "rich_utils",
    "string_utils",
    # Rich Utils
    "ArgumentDefaultsCmd2HelpFormatter",
    "Cmd2HelpFormatter",
    "MetavarTypeCmd2HelpFormatter",
    "RawDescriptionCmd2HelpFormatter",
    "RawTextCmd2HelpFormatter",
    "TextGroup",
    # String Utils
    "stylize",
    # Styles
    "Cmd2Style",
    # Theme
    "get_theme",
    "reset_theme",
    "update_theme",
    # Utilities
    "categorize",
    "CustomCompletionSettings",
    "Settable",
    "set_default_str_sort_key",
]
