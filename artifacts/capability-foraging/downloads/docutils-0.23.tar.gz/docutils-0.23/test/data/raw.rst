Raw text.
