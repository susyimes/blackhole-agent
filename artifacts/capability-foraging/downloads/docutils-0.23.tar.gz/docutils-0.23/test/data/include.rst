Some include text.
