simple input
