List Tables
-----------

Here's a list table exercising all features:

.. list-table:: list table with integral header
   :class: test
   :width: 95%
   :widths: 10 8 20
   :header-rows: 1
   :stub-columns: 1

   * - Treat
     - Quantity
     - Description
   * - Albatross
     - 2.99
     - On a stick!
   * - Crunchy Frog
     - 1.49
     - If we took the bones out, it wouldn't be
       crunchy, now would it?
   * - Gannet Ripple
     - 1.99
     - On a stick!

.. list-table:: center aligned list table
   :align: center
   :widths: auto

   * - Albatross
     - 2.99
   * - Crunchy Frog
     - 1.49
   * - Gannet Ripple
     - 1.99
