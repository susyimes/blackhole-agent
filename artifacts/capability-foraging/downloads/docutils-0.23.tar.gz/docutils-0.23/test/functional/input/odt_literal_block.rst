literal block ::

  ~~~ ><> ~~ <>< ~~~
