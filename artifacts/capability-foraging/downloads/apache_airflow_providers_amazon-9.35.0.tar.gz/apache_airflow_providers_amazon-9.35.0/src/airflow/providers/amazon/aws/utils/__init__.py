# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.
from __future__ import annotations

import logging
import posixpath
import re
from datetime import datetime, timezone
from enum import Enum
from importlib import metadata
from typing import TYPE_CHECKING, Any

import tenacity
from botocore.exceptions import ClientError

from airflow.providers.common.compat.sdk import AirflowException
from airflow.utils.helpers import prune_dict
from airflow.version import version

if TYPE_CHECKING:
    from airflow.sdk.types import Logger

log = logging.getLogger(__name__)

# AWS briefly rejects a delete call with ResourceInUseException while the target resource is still
# settling from a prior operation (e.g. EKS finalizing a nodegroup removal before the cluster can be
# deleted). Retry with exponential backoff (1s, 2s, 4s, ... capped at RESOURCE_IN_USE_RETRY_MAX_WAIT
# per wait) until RESOURCE_IN_USE_RETRY_TIMEOUT elapses, then give up and re-raise. This rides out the
# settling window without hanging a genuinely wedged resource for long.
RESOURCE_IN_USE_RETRY_TIMEOUT = 300
RESOURCE_IN_USE_RETRY_MAX_WAIT = 60


def is_resource_in_use_error(exception: BaseException) -> bool:
    """Return True if the exception is a transient AWS ``ResourceInUseException``."""
    return (
        isinstance(exception, ClientError)
        and exception.response.get("Error", {}).get("Code") == "ResourceInUseException"
    )


def build_resource_in_use_retry_args(logger: Logger | logging.Logger) -> dict[str, Any]:
    """
    Build tenacity arguments for retrying a call on a transient ``ResourceInUseException``.

    Shared by synchronous operators (``tenacity.Retrying``) and deferrable triggers
    (``tenacity.AsyncRetrying``) so both back off identically. ``reraise=True`` keeps the
    original error as the task failure once the retry timeout is exhausted. Accepts either an
    Airflow structlog logger (``self.log``) or a stdlib ``logging.Logger`` (module-level helpers).
    """
    return {
        "retry": tenacity.retry_if_exception(is_resource_in_use_error),
        "wait": tenacity.wait_exponential(max=RESOURCE_IN_USE_RETRY_MAX_WAIT),
        "stop": tenacity.stop_after_delay(RESOURCE_IN_USE_RETRY_TIMEOUT),
        "before_sleep": tenacity.before_sleep_log(logger, logging.WARNING),
        "reraise": True,
    }


def trim_none_values(obj: dict):
    return prune_dict(obj)


def datetime_to_epoch(date_time: datetime) -> int:
    """Convert a datetime object to an epoch integer (seconds)."""
    return int(date_time.timestamp())


def datetime_to_epoch_ms(date_time: datetime) -> int:
    """Convert a datetime object to an epoch integer (milliseconds)."""
    return int(date_time.timestamp() * 1_000)


def datetime_to_epoch_utc_ms(date_time: datetime) -> int:
    """Convert a datetime object to an epoch integer (milliseconds) in UTC timezone."""
    return int(date_time.replace(tzinfo=timezone.utc).timestamp() * 1_000)


def datetime_to_epoch_us(date_time: datetime) -> int:
    """Convert a datetime object to an epoch integer (microseconds)."""
    return int(date_time.timestamp() * 1_000_000)


def get_airflow_version() -> tuple[int, ...]:
    match = re.match(r"(\d+)\.(\d+)\.(\d+)", version)
    if match is None:  # Not theoratically possible.
        raise RuntimeError(f"Broken Airflow version: {version}")
    return tuple(int(x) for x in match.groups())


def get_botocore_version() -> tuple[int, ...]:
    """Return the version number of the installed botocore package in the form of a tuple[int,...]."""
    return tuple(map(int, metadata.version("botocore").split(".")[:3]))


def validate_execute_complete_event(event: dict[str, Any] | None = None) -> dict[str, Any]:
    if event is None:
        err_msg = "Trigger error: event is None"
        log.error(err_msg)
        raise AirflowException(err_msg)
    return event


def validate_destination_path(destination: str, base_path: str, *, base_name: str) -> None:
    """
    Ensure ``destination`` stays within ``base_path`` once resolved.

    In multi-file transfers the destination is ``base_path`` concatenated with a key suffix
    returned by ``list_keys``. S3 object names are arbitrary strings controlled by whoever can
    write to the source bucket, so ``..`` segments or an absolute name could place the upload
    outside ``base_path`` once the remote server resolves it on its host. ``base_name`` is the
    operator argument name used in the error message (e.g. ``sftp_path`` or ``ftp_path``).
    """
    base = posixpath.normpath(base_path)
    resolved = posixpath.normpath(destination)
    escapes = (
        resolved == ".."
        or resolved.startswith("../")
        or (posixpath.isabs(resolved) and not posixpath.isabs(base))
        or (base != "." and resolved != base and not resolved.startswith(base.rstrip("/") + "/"))
    )
    if escapes:
        raise ValueError(
            f"Refusing to upload S3 object to {destination!r}: resolved path "
            f"escapes configured {base_name} {base_path!r}."
        )


class _StringCompareEnum(Enum):
    """
    An Enum class which can be compared with regular `str` and subclasses.

    This class avoids multiple inheritance such as AwesomeEnum(str, Enum)
    which does not work well with templated_fields and Jinja templates.
    """

    def __eq__(self, other):
        if isinstance(other, str):
            return self.value == other
        return super().__eq__(other)

    def __hash__(self):
        return super().__hash__()  # Need to set because we redefine __eq__
