'use strict';

require('./internal/is_nil.js');
require('./is_string.js');
var coerce_to_string = require('./internal/coerce_to_string.js');
require('./internal/const.js');
var const_extended = require('./internal/const_extended.js');

/**
 * Checks whether `subject` contains only alpha and digit characters.
 *
 * @function isAlphaDigit
 * @static
 * @since 1.0.0
 * @memberOf Query
 * @param {string} [subject=''] The string to verify.
 * @return {boolean} Returns `true` if `subject` contains only alpha and digit characters or `false` otherwise.
 * @example
 * v.isAlphaDigit('year2020');
 * // => true
 *
 * v.isAlphaDigit('1448');
 * // => true
 *
 * v.isAlphaDigit('40-20');
 * // => false
 */

function isAlphaDigit(subject) {
  var subjectString = coerce_to_string.coerceToString(subject);
  return const_extended.REGEXP_ALPHA_DIGIT.test(subjectString);
}

module.exports = isAlphaDigit;
