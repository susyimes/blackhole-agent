'use strict';

require('./internal/is_nil.js');
require('./is_string.js');
var coerce_to_string = require('./internal/coerce_to_string.js');
require('./internal/const.js');
require('./internal/const_extended.js');
var is_alpha = require('./is_alpha.js');

/**
 * Checks whether `subject` has only lower case characters.
 *
 * @function isLowerCase
 * @static
 * @since 1.0.0
 * @memberOf Query
 * @param {string} [subject=''] The string to verify.
 * @return {boolean} Returns `true` if `subject` is lower case or `false` otherwise.
 * @example
 * v.isLowerCase('motorcycle');
 * // => true
 *
 * v.isLowerCase('John');
 * // => false
 *
 * v.isLowerCase('T1000');
 * // => false
 */

function isLowerCase(subject) {
  var valueString = coerce_to_string.coerceToString(subject);
  return is_alpha(valueString) && valueString.toLowerCase() === valueString;
}

module.exports = isLowerCase;
