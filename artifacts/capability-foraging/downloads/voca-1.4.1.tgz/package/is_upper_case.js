'use strict';

require('./internal/is_nil.js');
require('./is_string.js');
var coerce_to_string = require('./internal/coerce_to_string.js');
require('./internal/const.js');
require('./internal/const_extended.js');
var is_alpha = require('./is_alpha.js');

/**
 * Checks whether `subject` contains only upper case characters.
 *
 * @function isUpperCase
 * @static
 * @since 1.0.0
 * @memberOf Query
 * @param {string} [subject=''] The string to verify.
 * @return {boolean} Returns `true` if `subject` is upper case or `false` otherwise.
 * @example
 * v.isUpperCase('ACDC');
 * // => true
 *
 * v.isUpperCase('Morning');
 * // => false
 */

function isUpperCase(subject) {
  var subjectString = coerce_to_string.coerceToString(subject);
  return is_alpha(subjectString) && subjectString.toUpperCase() === subjectString;
}

module.exports = isUpperCase;
