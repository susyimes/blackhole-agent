'use strict';

var is_nil = require('./internal/is_nil.js');
require('./is_string.js');
var coerce_to_string = require('./internal/coerce_to_string.js');
var _const = require('./internal/const.js');
var to_string = require('./internal/to_string.js');
require('./internal/to_integer.js');
var includes = require('./includes.js');

var reduceRight = Array.prototype.reduceRight;
/**
 * Removes whitespaces from the right side of the `subject`.
 *
 * @function trimRight
 * @static
 * @since 1.0.0
 * @memberOf Manipulate
 * @param {string} [subject=''] The string to trim.
 * @param {string} [whitespace=whitespace] The whitespace characters to trim. List all characters that you want to be stripped.
 * @return {string} Returns the trimmed string.
 * @example
 * v.trimRight('the fire rises   ');
 * // => 'the fire rises'
 *
 * v.trimRight('do you feel in charge?!!!', '!');
 * // => 'do you feel in charge?'
 */

function trimRight(subject, whitespace) {
  var subjectString = coerce_to_string.coerceToString(subject);

  if (whitespace === '' || subjectString === '') {
    return subjectString;
  }

  var whitespaceString = to_string.toString(whitespace);

  if (is_nil.isNil(whitespaceString)) {
    return subjectString.replace(_const.REGEXP_TRIM_RIGHT, '');
  }

  var matchWhitespace = true;
  return reduceRight.call(subjectString, function (trimmed, character) {
    if (matchWhitespace && includes(whitespaceString, character)) {
      return trimmed;
    }

    matchWhitespace = false;
    return character + trimmed;
  }, '');
}

module.exports = trimRight;
