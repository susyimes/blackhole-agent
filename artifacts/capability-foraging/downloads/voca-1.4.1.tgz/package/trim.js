'use strict';

var is_nil = require('./internal/is_nil.js');
require('./is_string.js');
var coerce_to_string = require('./internal/coerce_to_string.js');
require('./internal/const.js');
var to_string = require('./internal/to_string.js');
require('./internal/to_integer.js');
require('./includes.js');
var trim_left = require('./trim_left.js');
var trim_right = require('./trim_right.js');

/**
 * Removes whitespaces from left and right sides of the `subject`.
 *
 * @function trim
 * @static
 * @since 1.0.0
 * @memberOf Manipulate
 * @param {string} [subject=''] The string to trim.
 * @param {string} [whitespace=whitespace] The whitespace characters to trim. List all characters that you want to be stripped.
 * @return {string} Returns the trimmed string.
 * @example
 * v.trim(' Mother nature ');
 * // => 'Mother nature'
 *
 * v.trim('--Earth--', '-');
 * // => 'Earth'
 */

function trim(subject, whitespace) {
  var subjectString = coerce_to_string.coerceToString(subject);

  if (whitespace === '' || subjectString === '') {
    return subjectString;
  }

  var whitespaceString = to_string.toString(whitespace);

  if (is_nil.isNil(whitespaceString)) {
    return subjectString.trim();
  }

  return trim_right(trim_left(subjectString, whitespaceString), whitespaceString);
}

module.exports = trim;
