'use strict';

var is_nil = require('./internal/is_nil.js');
require('./is_string.js');
var coerce_to_string = require('./internal/coerce_to_string.js');
var to_integer = require('./internal/to_integer.js');

/**
 * Truncates `subject` to a new `length`.
 *
 * @function truncate
 * @static
 * @since 1.0.0
 * @memberOf Chop
 * @param  {string} [subject=''] The string to truncate.
 * @param  {int}    length       The length to truncate the string.
 * @param  {string} [end='...']  The string to be added at the end.
 * @return {string}              Returns the truncated string.
 * @example
 * v.truncate('Once upon a time', 7);
 * // => 'Once...'
 *
 * v.truncate('Good day, Little Red Riding Hood', 14, ' (...)');
 * // => 'Good day (...)'
 *
 * v.truncate('Once upon', 10);
 * // => 'Once upon'
 */

function truncate(subject, length, end) {
  var subjectString = coerce_to_string.coerceToString(subject);
  var lengthInt = is_nil.isNil(length) ? subjectString.length : to_integer.clipNumber(to_integer.toInteger(length), 0, to_integer.MAX_SAFE_INTEGER);
  var endString = coerce_to_string.coerceToString(end, '...');

  if (lengthInt >= subjectString.length) {
    return subjectString;
  }

  return subjectString.substr(0, length - endString.length) + endString;
}

module.exports = truncate;
