'use strict';

var is_nil = require('./internal/is_nil.js');
require('./is_string.js');
var coerce_to_string = require('./internal/coerce_to_string.js');
var to_integer = require('./internal/to_integer.js');
require('./repeat.js');
var build_padding = require('./internal/build_padding.js');

/**
 * Pads `subject` to a new `length`.
 *
 * @function pad
 * @static
 * @since 1.0.0
 * @memberOf Manipulate
 * @param {string} [subject=''] The string to pad.
 * @param {int} [length=0] The length to pad the string. No changes are made if `length` is less than `subject.length`.
 * @param {string} [pad=' '] The string to be used for padding.
 * @return {string} Returns the padded string.
 * @example
 * v.pad('dog', 5);
 * // => ' dog '
 *
 * v.pad('bird', 6, '-');
 * // => '-bird-'
 *
 * v.pad('cat', 6, '-=');
 * // => '-cat-='
 */

function pad(subject, length, pad) {
  var subjectString = coerce_to_string.coerceToString(subject);
  var lengthInt = is_nil.isNil(length) ? 0 : to_integer.clipNumber(to_integer.toInteger(length), 0, to_integer.MAX_SAFE_INTEGER);
  var padString = coerce_to_string.coerceToString(pad, ' ');

  if (lengthInt <= subjectString.length) {
    return subjectString;
  }

  var paddingLength = lengthInt - subjectString.length;
  var paddingSideLength = to_integer.toInteger(paddingLength / 2);
  var paddingSideRemainingLength = paddingLength % 2;
  return build_padding.buildPadding(padString, paddingSideLength) + subjectString + build_padding.buildPadding(padString, paddingSideLength + paddingSideRemainingLength);
}

module.exports = pad;
