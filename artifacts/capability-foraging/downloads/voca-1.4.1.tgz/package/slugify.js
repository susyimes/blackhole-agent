'use strict';

require('./internal/is_nil.js');
require('./is_string.js');
var coerce_to_string = require('./internal/coerce_to_string.js');
require('./lower_case.js');
var _const = require('./internal/const.js');
require('./internal/const_extended.js');
require('./internal/nil_default.js');
require('./internal/to_string.js');
require('./words.js');
var kebab_case = require('./kebab_case.js');
var latinise = require('./latinise.js');

/**
 * Slugifies the `subject`. Cleans the `subject` by replacing diacritics with corresponding latin characters.
 *
 * @function slugify
 * @static
 * @since 1.0.0
 * @memberOf Manipulate
 * @param {string} [subject=''] The string to slugify.
 * @return {string} Returns the slugified string.
 * @example
 * v.slugify('Italian cappuccino drink');
 * // => 'italian-cappuccino-drink'
 *
 * v.slugify('caffé latté');
 * // => 'caffe-latte'
 *
 * v.slugify('хорошая погода');
 * // => 'horoshaya-pogoda'
 */

function slugify(subject) {
  var subjectString = coerce_to_string.coerceToString(subject);

  if (subjectString === '') {
    return '';
  }

  var cleanSubjectString = latinise(subjectString).replace(_const.REGEXP_NON_LATIN, '-');
  return kebab_case(cleanSubjectString);
}

module.exports = slugify;
