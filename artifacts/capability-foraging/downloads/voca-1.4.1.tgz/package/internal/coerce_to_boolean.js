'use strict';

var is_nil = require('./is_nil.js');

/**
 * Converts the `value` to a boolean. If `value` is `undefined` or `null`, returns `defaultValue`.
 *
 * @ignore
 * @function toBoolean
 * @param {*} value The value to convert.
 * @param {boolean} [defaultValue=false] The default value.
 * @return {boolean} Returns the coercion to boolean.
 */

function coerceToBoolean(value) {
  var defaultValue = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : false;

  if (is_nil.isNil(value)) {
    return defaultValue;
  }

  return Boolean(value);
}

exports.coerceToBoolean = coerceToBoolean;
