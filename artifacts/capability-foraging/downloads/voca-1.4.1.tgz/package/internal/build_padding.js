'use strict';

var to_integer = require('./to_integer.js');
var repeat = require('../repeat.js');

/**
 * Creates the padding string.
 *
 * @ignore
 * @param {string} padCharacters The characters to create padding string.
 * @param {number} length The padding string length.
 * @return {string} The padding string.
 */

function buildPadding(padCharacters, length) {
  var padStringRepeat = to_integer.toInteger(length / padCharacters.length);
  var padStringRest = length % padCharacters.length;
  return repeat(padCharacters, padStringRepeat + padStringRest).substr(0, length);
}

exports.buildPadding = buildPadding;
