'use strict';

/**
 * A regular expression string matching digits
 *
 * @type {string}
 * @ignore
 */
var digit = '\\d';
/**
 * A regular expression string matching whitespace
 *
 * @type {string}
 * @ignore
 */

var whitespace = '\\s\\uFEFF\\xA0';
/**
 * A regular expression string matching high surrogate
 *
 * @type {string}
 * @ignore
 */

var highSurrogate = '\\uD800-\\uDBFF';
/**
 * A regular expression string matching low surrogate
 *
 * @type {string}
 * @ignore
 */

var lowSurrogate = '\\uDC00-\\uDFFF';
/**
 * A regular expression string matching diacritical mark
 *
 * @type {string}
 * @ignore
 */

var diacriticalMark = '\\u0300-\\u036F\\u1AB0-\\u1AFF\\u1DC0-\\u1DFF\\u20D0-\\u20FF\\uFE20-\\uFE2F';
/**
 * A regular expression to match the base character for a combining mark
 *
 * @type {string}
 * @ignore
 */

var base = '\\0-\\u02FF\\u0370-\\u1AAF\\u1B00-\\u1DBF\\u1E00-\\u20CF\\u2100-\\uD7FF\\uE000-\\uFE1F\\uFE30-\\uFFFF';
/**
 * Regular expression to match combining marks
 *
 * @see http://unicode.org/faq/char_combmark.html
 * @type {RegExp}
 * @ignore
 */

var REGEXP_COMBINING_MARKS = new RegExp('([' + base + ']|[' + highSurrogate + '][' + lowSurrogate + ']|[' + highSurrogate + '](?![' + lowSurrogate + '])|(?:[^' + highSurrogate + ']|^)[' + lowSurrogate + '])([' + diacriticalMark + ']+)', 'g');
/**
 * Regular expression to match surrogate pairs
 *
 * @see http://www.unicode.org/faq/utf_bom.html#utf16-2
 * @type {RegExp}
 * @ignore
 */

var REGEXP_SURROGATE_PAIRS = new RegExp('([' + highSurrogate + '])([' + lowSurrogate + '])', 'g');
/**
 * Regular expression to match a unicode character
 *
 * @type {RegExp}
 * @ignore
 */

var REGEXP_UNICODE_CHARACTER = new RegExp('((?:[' + base + ']|[' + highSurrogate + '][' + lowSurrogate + ']|[' + highSurrogate + '](?![' + lowSurrogate + '])|(?:[^' + highSurrogate + ']|^)[' + lowSurrogate + '])(?:[' + diacriticalMark + ']+))|\
([' + highSurrogate + '][' + lowSurrogate + '])|\
([\\n\\r\\u2028\\u2029])|\
(.)', 'g');
/**
 * Regular expression to match whitespaces
 *
 * @type {RegExp}
 * @ignore
 */

var REGEXP_WHITESPACE = new RegExp('[' + whitespace + ']');
/**
 * Regular expression to match whitespaces from the left side
 *
 * @type {RegExp}
 * @ignore
 */

var REGEXP_TRIM_LEFT = new RegExp('^[' + whitespace + ']+');
/**
 * Regular expression to match whitespaces from the right side
 *
 * @type {RegExp}
 * @ignore
 */

var REGEXP_TRIM_RIGHT = new RegExp('[' + whitespace + ']+$');
/**
 * Regular expression to match digit characters
 *
 * @type {RegExp}
 * @ignore
 */

var REGEXP_DIGIT = new RegExp('^' + digit + '+$');
/**
 * Regular expression to match regular expression special characters
 *
 * @type {RegExp}
 * @ignore
 */

var REGEXP_SPECIAL_CHARACTERS = /[-[\]{}()*+!<=:?./\\^$|#,]/g;
/**
 * Regular expression to match not latin characters
 *
 * @type {RegExp}
 * @ignore
 */

var REGEXP_NON_LATIN = /[^A-Za-z0-9]/g;
/**
 * Regular expression to match HTML special characters.
 *
 * @type {RegExp}
 * @ignore
 */

var REGEXP_HTML_SPECIAL_CHARACTERS = /[<>&"'`]/g;
/**
 * Regular expression to match sprintf format string
 *
 * @type {RegExp}
 * @ignore
 */

var REGEXP_CONVERSION_SPECIFICATION = /(%{1,2})(?:(\d+)\$)?(\+)?([ 0]|'.{1})?(-)?(\d+)?(?:\.(\d+))?([bcdiouxXeEfgGs])?/g;
/**
 * Regular expression to match trailing zeros in a number
 *
 * @type {RegExp}
 * @ignore
 */

var REGEXP_TRAILING_ZEROS = /\.?0+$/g;
/**
 * Regular expression to match a list of tags.
 *
 * @see https://html.spec.whatwg.org/multipage/syntax.html#syntax-tag-name
 * @type {RegExp}
 * @ignore
 */

var REGEXP_TAG_LIST = /<([A-Za-z0-9]+)>/g;

exports.REGEXP_COMBINING_MARKS = REGEXP_COMBINING_MARKS;
exports.REGEXP_CONVERSION_SPECIFICATION = REGEXP_CONVERSION_SPECIFICATION;
exports.REGEXP_DIGIT = REGEXP_DIGIT;
exports.REGEXP_HTML_SPECIAL_CHARACTERS = REGEXP_HTML_SPECIAL_CHARACTERS;
exports.REGEXP_NON_LATIN = REGEXP_NON_LATIN;
exports.REGEXP_SPECIAL_CHARACTERS = REGEXP_SPECIAL_CHARACTERS;
exports.REGEXP_SURROGATE_PAIRS = REGEXP_SURROGATE_PAIRS;
exports.REGEXP_TAG_LIST = REGEXP_TAG_LIST;
exports.REGEXP_TRAILING_ZEROS = REGEXP_TRAILING_ZEROS;
exports.REGEXP_TRIM_LEFT = REGEXP_TRIM_LEFT;
exports.REGEXP_TRIM_RIGHT = REGEXP_TRIM_RIGHT;
exports.REGEXP_UNICODE_CHARACTER = REGEXP_UNICODE_CHARACTER;
exports.REGEXP_WHITESPACE = REGEXP_WHITESPACE;
exports.diacriticalMark = diacriticalMark;
exports.digit = digit;
exports.whitespace = whitespace;
