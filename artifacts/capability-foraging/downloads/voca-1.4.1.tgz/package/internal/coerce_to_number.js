'use strict';

var is_nil = require('./is_nil.js');

/**
 * Get the number representation of the `value`.
 * Converts the `value` to number.
 * If `value` is `null` or `undefined`, return `defaultValue`.
 *
 * @ignore
 * @function toString
 * @param {*} value             The value to convert.
 * @param {*} [defaultValue=''] The default value to return.
 * @return {number|null}        Returns the number representation of `value`. Returns `defaultValue` if `value` is
 *                              `null` or `undefined`.
 */

function coerceToNumber(value) {
  var defaultValue = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;

  if (is_nil.isNil(value)) {
    return defaultValue;
  }

  if (typeof value === 'number') {
    return value;
  }

  return Number(value);
}

exports.coerceToNumber = coerceToNumber;
