'use strict';

var is_nil = require('./is_nil.js');
var is_string = require('../is_string.js');

/**
 * Get the string representation of the `value`.
 * Converts the `value` to string.
 * If `value` is `null` or `undefined`, return `defaultValue`.
 *
 * @ignore
 * @function toString
 * @param {*} value             The value to convert.
 * @param {*} [defaultValue=''] The default value to return.
 * @return {string|null}        Returns the string representation of `value`. Returns `defaultValue` if `value` is
 *                              `null` or `undefined`.
 */

function coerceToString(value) {
  var defaultValue = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : '';

  if (is_nil.isNil(value)) {
    return defaultValue;
  }

  if (is_string(value)) {
    return value;
  }

  return String(value);
}

exports.coerceToString = coerceToString;
