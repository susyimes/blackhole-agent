'use strict';

var is_nil = require('./is_nil.js');
var is_string = require('../is_string.js');

/**
 * Get the string representation of the `value`.
 * Converts the `value` to string.
 *
 * @ignore
 * @function toString
 * @param {*} value             The value to convert.
 * @return {string|null}        Returns the string representation of `value`.
 */

function toString(value) {
  if (is_nil.isNil(value)) {
    return null;
  }

  if (is_string(value)) {
    return value;
  }

  return String(value);
}

exports.toString = toString;
