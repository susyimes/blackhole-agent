'use strict';

/**
 * Clip the number to interval `downLimit` to `upLimit`.
 *
 * @ignore
 * @function clipNumber
 * @param {number} value The number to clip
 * @param {number} downLimit The down limit
 * @param {number} upLimit The upper limit
 * @return {number} The clipped number
 */
function clipNumber(value, downLimit, upLimit) {
  if (value <= downLimit) {
    return downLimit;
  }

  if (value >= upLimit) {
    return upLimit;
  }

  return value;
}

/**
 * Max save integer value
 *
 * @ignore
 * @type {number}
 */
var MAX_SAFE_INTEGER = 0x1fffffffffffff;

/**
 * Transforms `value` to an integer.
 *
 * @ignore
 * @function toInteger
 * @param {number} value The number to transform.
 * @returns {number} Returns the transformed integer.
 */

function toInteger(value) {
  if (value === Infinity) {
    return MAX_SAFE_INTEGER;
  }

  if (value === -Infinity) {
    return -MAX_SAFE_INTEGER;
  }

  return ~~value;
}

exports.MAX_SAFE_INTEGER = MAX_SAFE_INTEGER;
exports.clipNumber = clipNumber;
exports.toInteger = toInteger;
