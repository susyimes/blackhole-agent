'use strict';

require('./internal/is_nil.js');
require('./is_string.js');
var coerce_to_string = require('./internal/coerce_to_string.js');
var lower_case = require('./lower_case.js');
require('./internal/const.js');
require('./internal/const_extended.js');
require('./internal/nil_default.js');
require('./internal/to_string.js');
var words = require('./words.js');

/**
 * Converts the `subject` to <a href="https://en.wikipedia.org/wiki/Snake_case">snake case</a>.
 *
 * @function snakeCase
 * @static
 * @since 1.0.0
 * @memberOf Case
 * @param  {string} [subject=''] The string to convert to snake case.
 * @return {string}              Returns the snake case string.
 * @example
 * v.snakeCase('learning to fly');
 * // => 'learning_to_fly'
 *
 * v.snakeCase('LearningToFly');
 * // => 'learning_to_fly'
 *
 * v.snakeCase('-Learning-To-Fly-');
 * // => 'learning_to_fly'
 */

function snakeCase(subject) {
  var subjectString = coerce_to_string.coerceToString(subject);

  if (subjectString === '') {
    return '';
  }

  return words(subjectString).map(lower_case).join('_');
}

module.exports = snakeCase;
