'use strict';

require('./internal/is_nil.js');
require('./is_string.js');
var coerce_to_string = require('./internal/coerce_to_string.js');

/**
 * Converts the first character of `subject` to lower case.
 *
 * @function decapitalize
 * @static
 * @since 1.0.0
 * @memberOf Case
 * @param  {string} [subject=''] The string to decapitalize.
 * @return {string}              Returns the decapitalized string.
 * @example
 * v.decapitalize('Sun');
 * // => 'sun'
 *
 * v.decapitalize('moon');
 * // => 'moon'
 */

function decapitalize(subject) {
  var subjectString = coerce_to_string.coerceToString(subject);

  if (subjectString === '') {
    return '';
  }

  return subjectString.substr(0, 1).toLowerCase() + subjectString.substr(1);
}

module.exports = decapitalize;
