'use strict';

require('./internal/is_nil.js');
var coerce_to_boolean = require('./internal/coerce_to_boolean.js');
require('./is_string.js');
var coerce_to_string = require('./internal/coerce_to_string.js');

/**
 * Converts the first character of `subject` to upper case. If `restToLower` is `true`, convert the rest of
 * `subject` to lower case.
 *
 * @function capitalize
 * @static
 * @since 1.0.0
 * @memberOf Case
 * @param  {string}  [subject='']        The string to capitalize.
 * @param  {boolean} [restToLower=false] Convert the rest of `subject` to lower case.
 * @return {string}                      Returns the capitalized string.
 * @example
 * v.capitalize('apple');
 * // => 'Apple'
 *
 * v.capitalize('aPPle', true);
 * // => 'Apple'
 */

function capitalize(subject, restToLower) {
  var subjectString = coerce_to_string.coerceToString(subject);
  var restToLowerCaseBoolean = coerce_to_boolean.coerceToBoolean(restToLower);

  if (subjectString === '') {
    return '';
  }

  if (restToLowerCaseBoolean) {
    subjectString = subjectString.toLowerCase();
  }

  return subjectString.substr(0, 1).toUpperCase() + subjectString.substr(1);
}

module.exports = capitalize;
