'use strict';

require('./internal/is_nil.js');
require('./internal/coerce_to_boolean.js');
require('./is_string.js');
var coerce_to_string = require('./internal/coerce_to_string.js');
var capitalize = require('./capitalize.js');
require('./internal/const.js');
var const_extended = require('./internal/const_extended.js');

/**
 * Converts the subject to title case.
 *
 * @function titleCase
 * @static
 * @since 1.4.0
 * @memberOf Case
 * @param  {string} [subject=''] The string to convert to title case.
 * @param  {Array}  [noSplit]    Do not split words at the specified characters.
 * @return {string}              Returns the title case string.
 * @example
 * v.titleCase('learning to fly');
 * // => 'Learning To Fly'
 *
 * v.titleCase('jean-luc is good-looking', ['-']);
 * // => 'Jean-luc Is Good-looking'
 */

function titleCase(subject, noSplit) {
  var subjectString = coerce_to_string.coerceToString(subject);
  var noSplitArray = Array.isArray(noSplit) ? noSplit : [];
  var wordsRegExp = const_extended.REGEXP_EXTENDED_ASCII.test(subjectString) ? const_extended.REGEXP_LATIN_WORD : const_extended.REGEXP_WORD;
  return subjectString.replace(wordsRegExp, function (word, index) {
    var isNoSplit = index > 0 && noSplitArray.indexOf(subjectString[index - 1]) >= 0;
    return isNoSplit ? word.toLowerCase() : capitalize(word, true);
  });
}

module.exports = titleCase;
