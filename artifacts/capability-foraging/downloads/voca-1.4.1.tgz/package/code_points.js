'use strict';

require('./internal/is_nil.js');
require('./is_string.js');
var coerce_to_string = require('./internal/coerce_to_string.js');
var code_point_at = require('./code_point_at.js');
require('./internal/coerce_to_number.js');
require('./internal/nan_default.js');

/**
 * Returns an array of Unicode code point values from characters of `subject`.
 *
 * @function codePoints
 * @static
 * @since 1.0.0
 * @memberOf Split
 * @param  {string} [subject=''] The string to extract from.
 * @return {Array} Returns an array of non-negative numbers less than or equal to `0x10FFFF`.
 * @example
 * v.codePoints('rain');
 * // => [114, 97, 105, 110], or
 * //    [0x72, 0x61, 0x69, 0x6E]
 *
 * v.codePoints('\uD83D\uDE00 smile'); // or '😀 smile'
 * // => [128512, 32, 115, 109, 105, 108, 101], or
 * //    [0x1F600, 0x20, 0x73, 0x6D, 0x69, 0x6C, 0x65]
 */

function codePoints(subject) {
  var subjectString = coerce_to_string.coerceToString(subject);
  var subjectStringLength = subjectString.length;
  var codePointArray = [];
  var index = 0;
  var codePointNumber;

  while (index < subjectStringLength) {
    codePointNumber = code_point_at(subjectString, index);
    codePointArray.push(codePointNumber);
    index += codePointNumber > 0xffff ? 2 : 1;
  }

  return codePointArray;
}

module.exports = codePoints;
