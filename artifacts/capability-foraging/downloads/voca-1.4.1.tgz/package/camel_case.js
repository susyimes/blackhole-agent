'use strict';

require('./internal/is_nil.js');
require('./internal/coerce_to_boolean.js');
require('./is_string.js');
var coerce_to_string = require('./internal/coerce_to_string.js');
var capitalize = require('./capitalize.js');
var lower_case = require('./lower_case.js');
require('./internal/const.js');
require('./internal/const_extended.js');
require('./internal/nil_default.js');
require('./internal/to_string.js');
var words = require('./words.js');

/**
 * Transforms the `word` into camel case chunk.
 *
 * @param  {string} word  The word string
 * @param  {number} index The index of the word in phrase.
 * @return {string}       The transformed word.
 * @ignore
 */

function wordToCamel(word, index) {
  return index === 0 ? lower_case(word) : capitalize(word, true);
}
/**
 * Converts the `subject` to <a href="https://en.wikipedia.org/wiki/CamelCase">camel case</a>.
 *
 * @function camelCase
 * @static
 * @since 1.0.0
 * @memberOf Case
 * @param  {string} [subject=''] The string to convert to camel case.
 * @return {string}              The camel case string.
 * @example
 * v.camelCase('bird flight');
 * // => 'birdFlight'
 *
 * v.camelCase('BirdFlight');
 * // => 'birdFlight'
 *
 * v.camelCase('-BIRD-FLIGHT-');
 * // => 'birdFlight'
 */


function camelCase(subject) {
  var subjectString = coerce_to_string.coerceToString(subject);

  if (subjectString === '') {
    return '';
  }

  return words(subjectString).map(wordToCamel).join('');
}

module.exports = camelCase;
