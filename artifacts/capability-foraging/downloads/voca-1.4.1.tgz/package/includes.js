'use strict';

var is_nil = require('./internal/is_nil.js');
require('./is_string.js');
var coerce_to_string = require('./internal/coerce_to_string.js');
var to_string = require('./internal/to_string.js');
var to_integer = require('./internal/to_integer.js');

/**
 * Checks whether `subject` includes `search` starting from `position`.
 *
 * @function includes
 * @static
 * @since 1.0.0
 * @memberOf Query
 * @param {string} [subject=''] The string where to search.
 * @param {string} search The string to search.
 * @param {number} [position=0] The position to start searching.
 * @return {boolean} Returns `true` if `subject` includes `search` or `false` otherwise.
 * @example
 * v.includes('starship', 'star');
 * // => true
 *
 * v.includes('galaxy', 'g', 1);
 * // => false
 */

function includes(subject, search, position) {
  var subjectString = coerce_to_string.coerceToString(subject);
  var searchString = to_string.toString(search);

  if (searchString === null) {
    return false;
  }

  if (searchString === '') {
    return true;
  }

  position = is_nil.isNil(position) ? 0 : to_integer.clipNumber(to_integer.toInteger(position), 0, subjectString.length);
  return subjectString.indexOf(searchString, position) !== -1;
}

module.exports = includes;
