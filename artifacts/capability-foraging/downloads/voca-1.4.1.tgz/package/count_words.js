'use strict';

require('./internal/is_nil.js');
require('./is_string.js');
require('./internal/coerce_to_string.js');
require('./internal/const.js');
require('./internal/const_extended.js');
require('./internal/nil_default.js');
require('./internal/to_string.js');
var words = require('./words.js');

/**
 * Counts the number of words in `subject`.
 *
 * @function countWords
 * @static
 * @since 1.0.0
 * @memberOf Count
 * @param {string} [subject=''] The string to split into words.
 * @param {string|RegExp} [pattern] The pattern to watch words. If `pattern` is not RegExp, it is transformed to `new RegExp(pattern, flags)`.
 * @param {string} [flags=''] The regular expression flags. Applies when `pattern` is string type.
 * @return {number} Returns the number of words.
 * @example
 * v.countWords('gravity can cross dimensions');
 * // => 4
 *
 * v.countWords('GravityCanCrossDimensions');
 * // => 4
 *
 * v.countWords('Gravity - can cross dimensions!');
 * // => 4
 *
 * v.words('Earth gravity', /[^\s]+/g);
 * // => 2
 */

function countWords(subject, pattern, flags) {
  return words(subject, pattern, flags).length;
}

module.exports = countWords;
