'use strict';

var is_nil = require('./internal/is_nil.js');
require('./is_string.js');
var coerce_to_string = require('./internal/coerce_to_string.js');
var to_string = require('./internal/to_string.js');
var to_integer = require('./internal/to_integer.js');

/**
 * Checks whether `subject` starts with `start`.
 *
 * @function startsWith
 * @static
 * @since 1.0.0
 * @memberOf Query
 * @param {string} [subject=''] The string to verify.
 * @param {string} start The starting string.
 * @param {number} [position=0] The position to start searching.
 * @return {boolean} Returns `true` if `subject` starts with `start` or `false` otherwise.
 * @example
 * v.startsWith('say hello to my little friend', 'say hello');
 * // => true
 *
 * v.startsWith('tony', 'on', 1);
 * // => true
 *
 * v.startsWith('the world is yours', 'world');
 * // => false
 */

function startsWith(subject, start, position) {
  var subjectString = coerce_to_string.coerceToString(subject);
  var startString = to_string.toString(start);

  if (startString === null) {
    return false;
  }

  if (startString === '') {
    return true;
  }

  position = is_nil.isNil(position) ? 0 : to_integer.clipNumber(to_integer.toInteger(position), 0, subjectString.length);
  return subjectString.substr(position, startString.length) === startString;
}

module.exports = startsWith;
