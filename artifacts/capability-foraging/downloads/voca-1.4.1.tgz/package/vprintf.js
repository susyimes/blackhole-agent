'use strict';

require('./internal/is_nil.js');
require('./is_string.js');
require('./internal/coerce_to_string.js');
require('./internal/const.js');
var nil_default = require('./internal/nil_default.js');
require('./internal/to_string.js');
require('./internal/coerce_to_number.js');
require('./internal/to_integer.js');
require('./truncate.js');
var sprintf = require('./sprintf.js');
require('./repeat.js');
require('./internal/build_padding.js');
require('./pad_left.js');
require('./pad_right.js');
var _rollupPluginBabelHelpers = require('./internal/_rollupPluginBabelHelpers.js');

/**
 * Produces a string according to `format`. Works exactly like <a href="#sprintf"><code>sprintf()</code></a>,
 * with the only difference that accepts the formatting arguments in an array `values`.<br/>
 * See <a href="#sprintf-format">here</a> `format` string specifications.
 *
 * @function vprintf
 * @static
 * @since 1.0.0
 * @memberOf Format
 * @param  {string} format='']  The format string.
 * @param  {Array} replacements The array of replacements to produce the string.
 * @return {string}             Returns the produced string.
 * @example
 * v.vprintf('%s', ['Welcome'])
 * // => 'Welcome'
 *
 * v.vprintf('%s has %d apples', ['Alexandra', 3]);
 * // => 'Alexandra has 3 apples'
 */

function vprintf(format, replacements) {
  return sprintf.apply(void 0, [format].concat(_rollupPluginBabelHelpers._toConsumableArray(nil_default.nilDefault(replacements, []))));
}

module.exports = vprintf;
