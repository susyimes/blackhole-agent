'use strict';

var is_nil = require('./internal/is_nil.js');
require('./is_string.js');
var coerce_to_string = require('./internal/coerce_to_string.js');
require('./internal/const.js');
var const_extended = require('./internal/const_extended.js');
var to_integer = require('./internal/to_integer.js');

/**
 * Truncates `subject` to a new `length` and does not break the words. Guarantees that the truncated string is no longer
 * than `length`.
 *
 * @static
 * @function prune
 * @since 1.0.0
 * @memberOf Chop
 * @param  {string} [subject=''] The string to prune.
 * @param  {int}    length       The length to prune the string.
 * @param  {string} [end='...']  The string to be added at the end.
 * @return {string}              Returns the pruned string.
 * @example
 * v.prune('Once upon a time', 7);
 * // => 'Once...'
 *
 * v.prune('Good day, Little Red Riding Hood', 16, ' (more)');
 * // => 'Good day (more)'
 *
 * v.prune('Once upon', 10);
 * // => 'Once upon'
 */

function prune(subject, length, end) {
  var subjectString = coerce_to_string.coerceToString(subject);
  var lengthInt = is_nil.isNil(length) ? subjectString.length : to_integer.clipNumber(to_integer.toInteger(length), 0, to_integer.MAX_SAFE_INTEGER);
  var endString = coerce_to_string.coerceToString(end, '...');

  if (lengthInt >= subjectString.length) {
    return subjectString;
  }

  var pattern = const_extended.REGEXP_EXTENDED_ASCII.test(subjectString) ? const_extended.REGEXP_LATIN_WORD : const_extended.REGEXP_WORD;
  var truncatedLength = 0;
  subjectString.replace(pattern, function (word, offset) {
    var wordInsertLength = offset + word.length;

    if (wordInsertLength <= lengthInt - endString.length) {
      truncatedLength = wordInsertLength;
    }
  });
  return subjectString.substr(0, truncatedLength) + endString;
}

module.exports = prune;
