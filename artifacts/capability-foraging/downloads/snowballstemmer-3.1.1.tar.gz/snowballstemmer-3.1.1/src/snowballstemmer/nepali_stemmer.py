# Generated from nepali.sbl by Snowball 3.1.1 - https://snowballstem.org/

from .basestemmer import BaseStemmer
from .among import Among


class NepaliStemmer(BaseStemmer):
    '''
    This class implements the stemming algorithm defined by a snowball script.
    Generated from nepali.sbl by Snowball 3.1.1 - https://snowballstem.org/
    '''


    def __r_remove_category_1(self):
        self.ket = self.cursor
        among_var = self.find_among_b(NepaliStemmer.a_0)
        if among_var == 0:
            return False
        self.bra = self.cursor
        if among_var == 1:
            self.slice_del()
        else:
            while True:
                try:
                    if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "\u090F":
                        raise lab0()
                    self.cursor -= 1
                    break
                except lab0: pass
                try:
                    if self.cursor <= self.limit_backward or self.current[self.cursor - 1] != "\u0947":
                        raise lab0()
                    self.cursor -= 1
                    break
                except lab0: pass
                self.slice_del()
                break
        return True

    def __r_remove_category_2(self):
        self.ket = self.cursor
        among_var = self.find_among_b(NepaliStemmer.a_1)
        if among_var == 0:
            return False
        self.bra = self.cursor
        if among_var == 1:
            while True:
                try:
                    if not self.eq_s_b("\u092F\u094C"):
                        raise lab0()
                    break
                except lab0: pass
                try:
                    if not self.eq_s_b("\u091B\u094C"):
                        raise lab0()
                    break
                except lab0: pass
                try:
                    if not self.eq_s_b("\u0928\u094C"):
                        raise lab0()
                    break
                except lab0: pass
                if not self.eq_s_b("\u0925\u0947"):
                    return False
                break
            self.slice_del()
        else:
            if not self.eq_s_b("\u0924\u094D\u0930"):
                return False
            self.slice_del()
        return True

    def __r_remove_category_3(self):
        self.ket = self.cursor
        if self.find_among_b(NepaliStemmer.a_2) == 0:
            return False
        self.bra = self.cursor
        self.slice_del()
        return True

    def _stem(self):
        self.limit_backward = self.cursor
        self.cursor = self.limit
        v_1 = self.limit - self.cursor
        self.__r_remove_category_1()
        self.cursor = self.limit - v_1
        while True:
            v_2 = self.limit - self.cursor
            try:
                v_3 = self.limit - self.cursor
                self.__r_remove_category_2()
                self.cursor = self.limit - v_3
                if not self.__r_remove_category_3():
                    raise lab0()
                continue
            except lab0: pass
            self.cursor = self.limit - v_2
            break
        self.cursor = self.limit_backward
        return True

    a_0 = [
        Among("\u0932\u093E\u0907", -1, 1),
        Among("\u0932\u093E\u0908", -1, 1),
        Among("\u0938\u0901\u0917", -1, 1),
        Among("\u0938\u0902\u0917", -1, 1),
        Among("\u092E\u093E\u0930\u094D\u092B\u0924", -1, 1),
        Among("\u0930\u0924", -1, 1),
        Among("\u0915\u093E", -1, 2),
        Among("\u092E\u093E", -1, 1),
        Among("\u0926\u094D\u0935\u093E\u0930\u093E", -1, 1),
        Among("\u0915\u093F", -1, 2),
        Among("\u092A\u091B\u093F", -1, 1),
        Among("\u0915\u0940", -1, 2),
        Among("\u0932\u0947", -1, 1),
        Among("\u0915\u0948", -1, 2),
        Among("\u0938\u0901\u0917\u0948", -1, 1),
        Among("\u092E\u0948", -1, 1),
        Among("\u0915\u094B", -1, 2)
    ]

    a_1 = [
        Among("\u0901", -1, 1),
        Among("\u0902", -1, 1),
        Among("\u0948", -1, 2)
    ]

    a_2 = [
        Among("\u0925\u093F\u090F", -1, 1),
        Among("\u091B", -1, 1),
        Among("\u0907\u091B", 1, 1),
        Among("\u090F\u091B", 1, 1),
        Among("\u093F\u091B", 1, 1),
        Among("\u0947\u091B", 1, 1),
        Among("\u0928\u0947\u091B", 5, 1),
        Among("\u0939\u0941\u0928\u0947\u091B", 6, 1),
        Among("\u0907\u0928\u094D\u091B", 1, 1),
        Among("\u093F\u0928\u094D\u091B", 1, 1),
        Among("\u0939\u0941\u0928\u094D\u091B", 1, 1),
        Among("\u090F\u0915\u093E", -1, 1),
        Among("\u0907\u090F\u0915\u093E", 11, 1),
        Among("\u093F\u090F\u0915\u093E", 11, 1),
        Among("\u0947\u0915\u093E", -1, 1),
        Among("\u0928\u0947\u0915\u093E", 14, 1),
        Among("\u0926\u093E", -1, 1),
        Among("\u0907\u0926\u093E", 16, 1),
        Among("\u093F\u0926\u093E", 16, 1),
        Among("\u0926\u0947\u0916\u093F", -1, 1),
        Among("\u092E\u093E\u0925\u093F", -1, 1),
        Among("\u090F\u0915\u0940", -1, 1),
        Among("\u0907\u090F\u0915\u0940", 21, 1),
        Among("\u093F\u090F\u0915\u0940", 21, 1),
        Among("\u0947\u0915\u0940", -1, 1),
        Among("\u0926\u0947\u0916\u0940", -1, 1),
        Among("\u0925\u0940", -1, 1),
        Among("\u0926\u0940", -1, 1),
        Among("\u091B\u0941", -1, 1),
        Among("\u090F\u091B\u0941", 28, 1),
        Among("\u0947\u091B\u0941", 28, 1),
        Among("\u0928\u0947\u091B\u0941", 30, 1),
        Among("\u0928\u0941", -1, 1),
        Among("\u0939\u0930\u0941", -1, 1),
        Among("\u0939\u0930\u0942", -1, 1),
        Among("\u091B\u0947", -1, 1),
        Among("\u0925\u0947", -1, 1),
        Among("\u0928\u0947", -1, 1),
        Among("\u090F\u0915\u0948", -1, 1),
        Among("\u0947\u0915\u0948", -1, 1),
        Among("\u0928\u0947\u0915\u0948", 39, 1),
        Among("\u0926\u0948", -1, 1),
        Among("\u0907\u0926\u0948", 41, 1),
        Among("\u093F\u0926\u0948", 41, 1),
        Among("\u090F\u0915\u094B", -1, 1),
        Among("\u0907\u090F\u0915\u094B", 44, 1),
        Among("\u093F\u090F\u0915\u094B", 44, 1),
        Among("\u0947\u0915\u094B", -1, 1),
        Among("\u0928\u0947\u0915\u094B", 47, 1),
        Among("\u0926\u094B", -1, 1),
        Among("\u0907\u0926\u094B", 49, 1),
        Among("\u093F\u0926\u094B", 49, 1),
        Among("\u092F\u094B", -1, 1),
        Among("\u0907\u092F\u094B", 52, 1),
        Among("\u092D\u092F\u094B", 52, 1),
        Among("\u093F\u092F\u094B", 52, 1),
        Among("\u0925\u093F\u092F\u094B", 55, 1),
        Among("\u0926\u093F\u092F\u094B", 55, 1),
        Among("\u0925\u094D\u092F\u094B", 52, 1),
        Among("\u091B\u094C", -1, 1),
        Among("\u0907\u091B\u094C", 59, 1),
        Among("\u090F\u091B\u094C", 59, 1),
        Among("\u093F\u091B\u094C", 59, 1),
        Among("\u0947\u091B\u094C", 59, 1),
        Among("\u0928\u0947\u091B\u094C", 63, 1),
        Among("\u092F\u094C", -1, 1),
        Among("\u0925\u093F\u092F\u094C", 65, 1),
        Among("\u091B\u094D\u092F\u094C", 65, 1),
        Among("\u0925\u094D\u092F\u094C", 65, 1),
        Among("\u091B\u0928\u094D", -1, 1),
        Among("\u0907\u091B\u0928\u094D", 69, 1),
        Among("\u090F\u091B\u0928\u094D", 69, 1),
        Among("\u093F\u091B\u0928\u094D", 69, 1),
        Among("\u0947\u091B\u0928\u094D", 69, 1),
        Among("\u0928\u0947\u091B\u0928\u094D", 73, 1),
        Among("\u0932\u093E\u0928\u094D", -1, 1),
        Among("\u091B\u093F\u0928\u094D", -1, 1),
        Among("\u0925\u093F\u0928\u094D", -1, 1),
        Among("\u092A\u0930\u094D", -1, 1),
        Among("\u0907\u0938\u094D", -1, 1),
        Among("\u0925\u093F\u0907\u0938\u094D", 79, 1),
        Among("\u091B\u0938\u094D", -1, 1),
        Among("\u0907\u091B\u0938\u094D", 81, 1),
        Among("\u090F\u091B\u0938\u094D", 81, 1),
        Among("\u093F\u091B\u0938\u094D", 81, 1),
        Among("\u0947\u091B\u0938\u094D", 81, 1),
        Among("\u0928\u0947\u091B\u0938\u094D", 85, 1),
        Among("\u093F\u0938\u094D", -1, 1),
        Among("\u0925\u093F\u0938\u094D", 87, 1),
        Among("\u091B\u0947\u0938\u094D", -1, 1),
        Among("\u0939\u094B\u0938\u094D", -1, 1)
    ]


class lab0(BaseException): pass
