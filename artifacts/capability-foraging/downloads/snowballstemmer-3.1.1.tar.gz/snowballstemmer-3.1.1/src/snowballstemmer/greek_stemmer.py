# Generated from greek.sbl by Snowball 3.1.1 - https://snowballstem.org/

from .basestemmer import BaseStemmer
from .among import Among


class GreekStemmer(BaseStemmer):
    '''
    This class implements the stemming algorithm defined by a snowball script.
    Generated from greek.sbl by Snowball 3.1.1 - https://snowballstem.org/
    '''

    g_v = {"α", "ε", "η", "ι", "ο", "υ", "ω"}

    g_v2 = {"α", "ε", "η", "ι", "ο", "ω"}

    B_test1 = False

    def __r_tolower(self):
        while True:
            v_1 = self.limit - self.cursor
            try:
                self.ket = self.cursor
                among_var = self.find_among_b(GreekStemmer.a_0)
                self.bra = self.cursor
                if among_var == 1:
                    self.slice_from("α")
                elif among_var == 2:
                    self.slice_from("β")
                elif among_var == 3:
                    self.slice_from("γ")
                elif among_var == 4:
                    self.slice_from("δ")
                elif among_var == 5:
                    self.slice_from("ε")
                elif among_var == 6:
                    self.slice_from("ζ")
                elif among_var == 7:
                    self.slice_from("η")
                elif among_var == 8:
                    self.slice_from("θ")
                elif among_var == 9:
                    self.slice_from("ι")
                elif among_var == 10:
                    self.slice_from("κ")
                elif among_var == 11:
                    self.slice_from("λ")
                elif among_var == 12:
                    self.slice_from("μ")
                elif among_var == 13:
                    self.slice_from("ν")
                elif among_var == 14:
                    self.slice_from("ξ")
                elif among_var == 15:
                    self.slice_from("ο")
                elif among_var == 16:
                    self.slice_from("π")
                elif among_var == 17:
                    self.slice_from("ρ")
                elif among_var == 18:
                    self.slice_from("σ")
                elif among_var == 19:
                    self.slice_from("τ")
                elif among_var == 20:
                    self.slice_from("υ")
                elif among_var == 21:
                    self.slice_from("φ")
                elif among_var == 22:
                    self.slice_from("χ")
                elif among_var == 23:
                    self.slice_from("ψ")
                elif among_var == 24:
                    self.slice_from("ω")
                else:
                    if self.cursor <= self.limit_backward:
                        raise lab0()
                    self.cursor -= 1
                continue
            except lab0: pass
            self.cursor = self.limit - v_1
            break
        return True

    def __r_step_1(self):
        self.ket = self.cursor
        among_var = self.find_among_b(GreekStemmer.a_1)
        if among_var == 0:
            return False
        self.bra = self.cursor
        self.slice_from(GreekStemmer.as_1[among_var - 1])
        self.B_test1 = False
        return True

    def __r_step_s1(self):
        self.ket = self.cursor
        if self.find_among_b(GreekStemmer.a_3) == 0:
            return False
        self.bra = self.cursor
        self.slice_del()
        self.B_test1 = False
        self.ket = self.cursor
        self.bra = self.cursor
        among_var = self.find_among_b(GreekStemmer.a_2)
        if among_var == 0:
            return False
        if self.cursor > self.limit_backward:
            return False
        self.slice_from(GreekStemmer.as_2[among_var - 1])
        return True

    def __r_step_s2(self):
        self.ket = self.cursor
        if self.find_among_b(GreekStemmer.a_5) == 0:
            return False
        self.bra = self.cursor
        self.slice_del()
        self.B_test1 = False
        self.ket = self.cursor
        self.bra = self.cursor
        if self.find_among_b(GreekStemmer.a_4) == 0:
            return False
        if self.cursor > self.limit_backward:
            return False
        self.slice_from("ων")
        return True

    def __r_step_s3(self):
        while True:
            v_1 = self.limit - self.cursor
            try:
                self.ket = self.cursor
                if not self.eq_s_b("ισα"):
                    raise lab0()
                self.bra = self.cursor
                if self.cursor > self.limit_backward:
                    raise lab0()
                self.slice_from("ισ")
                break
            except lab0: pass
            self.cursor = self.limit - v_1
            self.ket = self.cursor
            break
        if self.find_among_b(GreekStemmer.a_7) == 0:
            return False
        self.bra = self.cursor
        self.slice_del()
        self.B_test1 = False
        self.ket = self.cursor
        self.bra = self.cursor
        among_var = self.find_among_b(GreekStemmer.a_6)
        if among_var == 0:
            return False
        if self.cursor > self.limit_backward:
            return False
        self.slice_from(GreekStemmer.as_6[among_var - 1])
        return True

    def __r_step_s4(self):
        self.ket = self.cursor
        if self.find_among_b(GreekStemmer.a_9) == 0:
            return False
        self.bra = self.cursor
        self.slice_del()
        self.B_test1 = False
        self.ket = self.cursor
        self.bra = self.cursor
        if self.find_among_b(GreekStemmer.a_8) == 0:
            return False
        if self.cursor > self.limit_backward:
            return False
        self.slice_from("ι")
        return True

    def __r_step_s5(self):
        self.ket = self.cursor
        if self.find_among_b(GreekStemmer.a_11) == 0:
            return False
        self.bra = self.cursor
        self.slice_del()
        self.B_test1 = False
        self.ket = self.cursor
        self.bra = self.cursor
        among_var = self.find_among_b(GreekStemmer.a_10)
        if among_var == 0:
            return False
        if self.cursor > self.limit_backward:
            return False
        self.slice_from(GreekStemmer.as_10[among_var - 1])
        return True

    def __r_step_s6(self):
        self.ket = self.cursor
        if self.find_among_b(GreekStemmer.a_14) == 0:
            return False
        self.bra = self.cursor
        self.slice_del()
        self.B_test1 = False
        while True:
            v_1 = self.limit - self.cursor
            try:
                self.ket = self.cursor
                self.bra = self.cursor
                among_var = self.find_among_b(GreekStemmer.a_12)
                if among_var == 0:
                    raise lab0()
                if self.cursor > self.limit_backward:
                    raise lab0()
                self.slice_from(GreekStemmer.as_12[among_var - 1])
                break
            except lab0: pass
            self.cursor = self.limit - v_1
            self.ket = self.cursor
            among_var = self.find_among_b(GreekStemmer.a_13)
            if among_var == 0:
                return False
            self.bra = self.cursor
            self.slice_from(GreekStemmer.as_13[among_var - 1])
            break
        return True

    def __r_step_s7(self):
        self.ket = self.cursor
        if self.find_among_b(GreekStemmer.a_16) == 0:
            return False
        self.bra = self.cursor
        self.slice_del()
        self.B_test1 = False
        self.ket = self.cursor
        self.bra = self.cursor
        if self.find_among_b(GreekStemmer.a_15) == 0:
            return False
        if self.cursor > self.limit_backward:
            return False
        self.slice_from("αρακ")
        return True

    def __r_step_s8(self):
        self.ket = self.cursor
        if self.find_among_b(GreekStemmer.a_18) == 0:
            return False
        self.bra = self.cursor
        self.slice_del()
        self.B_test1 = False
        while True:
            v_1 = self.limit - self.cursor
            try:
                self.ket = self.cursor
                self.bra = self.cursor
                among_var = self.find_among_b(GreekStemmer.a_17)
                if among_var == 0:
                    raise lab0()
                if self.cursor > self.limit_backward:
                    raise lab0()
                self.slice_from(GreekStemmer.as_17[among_var - 1])
                break
            except lab0: pass
            self.cursor = self.limit - v_1
            self.ket = self.cursor
            self.bra = self.cursor
            if not self.eq_s_b("κορ"):
                return False
            self.slice_from("ιτσ")
            break
        return True

    def __r_step_s9(self):
        self.ket = self.cursor
        if self.find_among_b(GreekStemmer.a_21) == 0:
            return False
        self.bra = self.cursor
        self.slice_del()
        self.B_test1 = False
        while True:
            v_1 = self.limit - self.cursor
            try:
                self.ket = self.cursor
                self.bra = self.cursor
                if self.find_among_b(GreekStemmer.a_19) == 0:
                    raise lab0()
                if self.cursor > self.limit_backward:
                    raise lab0()
                self.slice_from("ιδ")
                break
            except lab0: pass
            self.cursor = self.limit - v_1
            self.ket = self.cursor
            self.bra = self.cursor
            if self.find_among_b(GreekStemmer.a_20) == 0:
                return False
            self.slice_from("ιδ")
            break
        return True

    def __r_step_s10(self):
        self.ket = self.cursor
        if self.find_among_b(GreekStemmer.a_23) == 0:
            return False
        self.bra = self.cursor
        self.slice_del()
        self.B_test1 = False
        self.ket = self.cursor
        self.bra = self.cursor
        if self.find_among_b(GreekStemmer.a_22) == 0:
            return False
        if self.cursor > self.limit_backward:
            return False
        self.slice_from("ισκ")
        return True

    def __r_step_2a(self):
        self.ket = self.cursor
        if self.find_among_b(GreekStemmer.a_24) == 0:
            return False
        self.bra = self.cursor
        self.slice_del()
        v_1 = self.limit - self.cursor
        try:
            if self.find_among_b(GreekStemmer.a_25) == 0:
                raise lab0()
            return False
        except lab0: pass
        self.cursor = self.limit - v_1
        c = self.cursor
        self.insert(self.cursor, self.cursor, "αδ")
        self.cursor = c
        return True

    def __r_step_2b(self):
        self.ket = self.cursor
        if self.find_among_b(GreekStemmer.a_26) == 0:
            return False
        self.bra = self.cursor
        self.slice_del()
        self.ket = self.cursor
        self.bra = self.cursor
        if self.find_among_b(GreekStemmer.a_27) == 0:
            return False
        self.slice_from("εδ")
        return True

    def __r_step_2c(self):
        self.ket = self.cursor
        if self.find_among_b(GreekStemmer.a_28) == 0:
            return False
        self.bra = self.cursor
        self.slice_del()
        self.ket = self.cursor
        self.bra = self.cursor
        if self.find_among_b(GreekStemmer.a_29) == 0:
            return False
        self.slice_from("ουδ")
        return True

    def __r_step_2d(self):
        self.ket = self.cursor
        if self.find_among_b(GreekStemmer.a_30) == 0:
            return False
        self.bra = self.cursor
        self.slice_del()
        self.B_test1 = False
        self.ket = self.cursor
        self.bra = self.cursor
        if self.find_among_b(GreekStemmer.a_31) == 0:
            return False
        if self.cursor > self.limit_backward:
            return False
        self.slice_from("ε")
        return True

    def __r_step_3(self):
        self.ket = self.cursor
        if self.find_among_b(GreekStemmer.a_32) == 0:
            return False
        self.bra = self.cursor
        self.slice_del()
        self.B_test1 = False
        self.ket = self.cursor
        self.bra = self.cursor
        if not self.in_grouping_b(GreekStemmer.g_v):
            return False
        self.slice_from("ι")
        return True

    def __r_step_4(self):
        self.ket = self.cursor
        if self.find_among_b(GreekStemmer.a_33) == 0:
            return False
        self.bra = self.cursor
        self.slice_del()
        self.B_test1 = False
        while True:
            v_1 = self.limit - self.cursor
            try:
                self.ket = self.cursor
                self.bra = self.cursor
                if not self.in_grouping_b(GreekStemmer.g_v):
                    raise lab0()
                self.slice_from("ικ")
                break
            except lab0: pass
            self.cursor = self.limit - v_1
            self.ket = self.cursor
            break
        self.bra = self.cursor
        if self.find_among_b(GreekStemmer.a_34) == 0:
            return False
        if self.cursor > self.limit_backward:
            return False
        self.slice_from("ικ")
        return True

    def __r_step_5a(self):
        v_1 = self.limit - self.cursor
        try:
            self.ket = self.cursor
            if not self.eq_s_b("αγαμε"):
                raise lab0()
            self.bra = self.cursor
            if self.cursor > self.limit_backward:
                raise lab0()
            self.slice_from("αγαμ")
        except lab0: pass
        self.cursor = self.limit - v_1
        v_2 = self.limit - self.cursor
        try:
            self.ket = self.cursor
            if self.find_among_b(GreekStemmer.a_35) == 0:
                raise lab0()
            self.bra = self.cursor
            self.slice_del()
            self.B_test1 = False
        except lab0: pass
        self.cursor = self.limit - v_2
        self.ket = self.cursor
        if not self.eq_s_b("αμε"):
            return False
        self.bra = self.cursor
        self.slice_del()
        self.B_test1 = False
        self.ket = self.cursor
        self.bra = self.cursor
        if self.find_among_b(GreekStemmer.a_36) == 0:
            return False
        if self.cursor > self.limit_backward:
            return False
        self.slice_from("αμ")
        return True

    def __r_step_5b(self):
        v_1 = self.limit - self.cursor
        try:
            self.ket = self.cursor
            if self.find_among_b(GreekStemmer.a_38) == 0:
                raise lab0()
            self.bra = self.cursor
            self.slice_del()
            self.B_test1 = False
            self.ket = self.cursor
            self.bra = self.cursor
            if self.find_among_b(GreekStemmer.a_37) == 0:
                raise lab0()
            if self.cursor > self.limit_backward:
                raise lab0()
            self.slice_from("αγαν")
        except lab0: pass
        self.cursor = self.limit - v_1
        self.ket = self.cursor
        if not self.eq_s_b("ανε"):
            return False
        self.bra = self.cursor
        self.slice_del()
        self.B_test1 = False
        while True:
            v_2 = self.limit - self.cursor
            try:
                self.ket = self.cursor
                self.bra = self.cursor
                if not self.in_grouping_b(GreekStemmer.g_v2):
                    raise lab0()
                self.slice_from("αν")
                break
            except lab0: pass
            self.cursor = self.limit - v_2
            self.ket = self.cursor
            break
        self.bra = self.cursor
        if self.find_among_b(GreekStemmer.a_39) == 0:
            return False
        if self.cursor > self.limit_backward:
            return False
        self.slice_from("αν")
        return True

    def __r_step_5c(self):
        v_1 = self.limit - self.cursor
        try:
            self.ket = self.cursor
            if not self.eq_s_b("ησετε"):
                raise lab0()
            self.bra = self.cursor
            self.slice_del()
            self.B_test1 = False
        except lab0: pass
        self.cursor = self.limit - v_1
        self.ket = self.cursor
        if not self.eq_s_b("ετε"):
            return False
        self.bra = self.cursor
        self.slice_del()
        self.B_test1 = False
        while True:
            v_2 = self.limit - self.cursor
            try:
                self.ket = self.cursor
                self.bra = self.cursor
                if not self.in_grouping_b(GreekStemmer.g_v2):
                    raise lab0()
                self.slice_from("ετ")
                break
            except lab0: pass
            self.cursor = self.limit - v_2
            try:
                self.ket = self.cursor
                self.bra = self.cursor
                if self.find_among_b(GreekStemmer.a_40) == 0:
                    raise lab0()
                self.slice_from("ετ")
                break
            except lab0: pass
            self.cursor = self.limit - v_2
            self.ket = self.cursor
            break
        self.bra = self.cursor
        if self.find_among_b(GreekStemmer.a_41) == 0:
            return False
        if self.cursor > self.limit_backward:
            return False
        self.slice_from("ετ")
        return True

    def __r_step_5d(self):
        self.ket = self.cursor
        if self.find_among_b(GreekStemmer.a_42) == 0:
            return False
        self.bra = self.cursor
        self.slice_del()
        self.B_test1 = False
        while True:
            v_1 = self.limit - self.cursor
            try:
                self.ket = self.cursor
                self.bra = self.cursor
                if not self.eq_s_b("αρχ"):
                    raise lab0()
                if self.cursor > self.limit_backward:
                    raise lab0()
                self.slice_from("οντ")
                break
            except lab0: pass
            self.cursor = self.limit - v_1
            self.ket = self.cursor
            self.bra = self.cursor
            if not self.eq_s_b("κρε"):
                return False
            self.slice_from("ωντ")
            break
        return True

    def __r_step_5e(self):
        self.ket = self.cursor
        if self.find_among_b(GreekStemmer.a_43) == 0:
            return False
        self.bra = self.cursor
        self.slice_del()
        self.B_test1 = False
        self.ket = self.cursor
        self.bra = self.cursor
        if not self.eq_s_b("ον"):
            return False
        if self.cursor > self.limit_backward:
            return False
        self.slice_from("ομαστ")
        return True

    def __r_step_5f(self):
        v_1 = self.limit - self.cursor
        try:
            self.ket = self.cursor
            if not self.eq_s_b("ιεστε"):
                raise lab0()
            self.bra = self.cursor
            self.slice_del()
            self.B_test1 = False
            self.ket = self.cursor
            self.bra = self.cursor
            if self.find_among_b(GreekStemmer.a_44) == 0:
                raise lab0()
            if self.cursor > self.limit_backward:
                raise lab0()
            self.slice_from("ιεστ")
        except lab0: pass
        self.cursor = self.limit - v_1
        self.ket = self.cursor
        if not self.eq_s_b("εστε"):
            return False
        self.bra = self.cursor
        self.slice_del()
        self.B_test1 = False
        self.ket = self.cursor
        self.bra = self.cursor
        if self.find_among_b(GreekStemmer.a_45) == 0:
            return False
        if self.cursor > self.limit_backward:
            return False
        self.slice_from("ιεστ")
        return True

    def __r_step_5g(self):
        v_1 = self.limit - self.cursor
        try:
            self.ket = self.cursor
            if self.find_among_b(GreekStemmer.a_46) == 0:
                raise lab0()
            self.bra = self.cursor
            self.slice_del()
            self.B_test1 = False
        except lab0: pass
        self.cursor = self.limit - v_1
        self.ket = self.cursor
        if self.find_among_b(GreekStemmer.a_49) == 0:
            return False
        self.bra = self.cursor
        self.slice_del()
        self.B_test1 = False
        while True:
            v_2 = self.limit - self.cursor
            try:
                self.ket = self.cursor
                self.bra = self.cursor
                if self.find_among_b(GreekStemmer.a_47) == 0:
                    raise lab0()
                self.slice_from("ηκ")
                break
            except lab0: pass
            self.cursor = self.limit - v_2
            self.ket = self.cursor
            self.bra = self.cursor
            if self.find_among_b(GreekStemmer.a_48) == 0:
                return False
            if self.cursor > self.limit_backward:
                return False
            self.slice_from("ηκ")
            break
        return True

    def __r_step_5h(self):
        self.ket = self.cursor
        if self.find_among_b(GreekStemmer.a_52) == 0:
            return False
        self.bra = self.cursor
        self.slice_del()
        self.B_test1 = False
        while True:
            v_1 = self.limit - self.cursor
            try:
                self.ket = self.cursor
                self.bra = self.cursor
                if self.find_among_b(GreekStemmer.a_50) == 0:
                    raise lab0()
                self.slice_from("ουσ")
                break
            except lab0: pass
            self.cursor = self.limit - v_1
            self.ket = self.cursor
            self.bra = self.cursor
            if self.find_among_b(GreekStemmer.a_51) == 0:
                return False
            if self.cursor > self.limit_backward:
                return False
            self.slice_from("ουσ")
            break
        return True

    def __r_step_5i(self):
        self.ket = self.cursor
        if self.find_among_b(GreekStemmer.a_55) == 0:
            return False
        self.bra = self.cursor
        self.slice_del()
        self.B_test1 = False
        while True:
            v_1 = self.limit - self.cursor
            try:
                self.ket = self.cursor
                self.bra = self.cursor
                if not self.eq_s_b("κολλ"):
                    raise lab0()
                self.slice_from("αγ")
                break
            except lab0: pass
            self.cursor = self.limit - v_1
            while True:
                v_2 = self.limit - self.cursor
                try:
                    self.ket = self.cursor
                    self.bra = self.cursor
                    among_var = self.find_among_b(GreekStemmer.a_53)
                    if among_var == 0:
                        raise lab0()
                    if among_var == 1:
                        self.slice_from("αγ")
                    break
                except lab0: pass
                self.cursor = self.limit - v_2
                self.ket = self.cursor
                self.bra = self.cursor
                if self.find_among_b(GreekStemmer.a_54) == 0:
                    return False
                if self.cursor > self.limit_backward:
                    return False
                self.slice_from("αγ")
                break
            break
        return True

    def __r_step_5j(self):
        self.ket = self.cursor
        if self.find_among_b(GreekStemmer.a_56) == 0:
            return False
        self.bra = self.cursor
        self.slice_del()
        self.B_test1 = False
        self.ket = self.cursor
        self.bra = self.cursor
        if self.find_among_b(GreekStemmer.a_57) == 0:
            return False
        if self.cursor > self.limit_backward:
            return False
        self.slice_from("ησ")
        return True

    def __r_step_5k(self):
        self.ket = self.cursor
        if not self.eq_s_b("ηστε"):
            return False
        self.bra = self.cursor
        self.slice_del()
        self.B_test1 = False
        self.ket = self.cursor
        self.bra = self.cursor
        if self.find_among_b(GreekStemmer.a_58) == 0:
            return False
        if self.cursor > self.limit_backward:
            return False
        self.slice_from("ηστ")
        return True

    def __r_step_5l(self):
        self.ket = self.cursor
        if self.find_among_b(GreekStemmer.a_59) == 0:
            return False
        self.bra = self.cursor
        self.slice_del()
        self.B_test1 = False
        self.ket = self.cursor
        self.bra = self.cursor
        if self.find_among_b(GreekStemmer.a_60) == 0:
            return False
        if self.cursor > self.limit_backward:
            return False
        self.slice_from("ουν")
        return True

    def __r_step_5m(self):
        self.ket = self.cursor
        if self.find_among_b(GreekStemmer.a_61) == 0:
            return False
        self.bra = self.cursor
        self.slice_del()
        self.B_test1 = False
        self.ket = self.cursor
        self.bra = self.cursor
        if self.find_among_b(GreekStemmer.a_62) == 0:
            return False
        if self.cursor > self.limit_backward:
            return False
        self.slice_from("ουμ")
        return True

    def __r_step_6(self):
        v_1 = self.limit - self.cursor
        try:
            self.ket = self.cursor
            if self.find_among_b(GreekStemmer.a_63) == 0:
                raise lab0()
            self.bra = self.cursor
            self.slice_from("μα")
        except lab0: pass
        self.cursor = self.limit - v_1
        if not self.B_test1:
            return False
        self.ket = self.cursor
        if self.find_among_b(GreekStemmer.a_64) == 0:
            return False
        self.bra = self.cursor
        self.slice_del()
        return True

    def __r_step_7(self):
        self.ket = self.cursor
        if self.find_among_b(GreekStemmer.a_65) == 0:
            return False
        self.bra = self.cursor
        self.slice_del()
        return True

    def _stem(self):
        self.limit_backward = self.cursor
        self.cursor = self.limit
        v_1 = self.limit - self.cursor
        self.__r_tolower()
        self.cursor = self.limit - v_1
        if len(self.current) < 3:
            return False
        self.B_test1 = True
        v_2 = self.limit - self.cursor
        self.__r_step_1()
        self.cursor = self.limit - v_2
        v_3 = self.limit - self.cursor
        self.__r_step_s1()
        self.cursor = self.limit - v_3
        v_4 = self.limit - self.cursor
        self.__r_step_s2()
        self.cursor = self.limit - v_4
        v_5 = self.limit - self.cursor
        self.__r_step_s3()
        self.cursor = self.limit - v_5
        v_6 = self.limit - self.cursor
        self.__r_step_s4()
        self.cursor = self.limit - v_6
        v_7 = self.limit - self.cursor
        self.__r_step_s5()
        self.cursor = self.limit - v_7
        v_8 = self.limit - self.cursor
        self.__r_step_s6()
        self.cursor = self.limit - v_8
        v_9 = self.limit - self.cursor
        self.__r_step_s7()
        self.cursor = self.limit - v_9
        v_10 = self.limit - self.cursor
        self.__r_step_s8()
        self.cursor = self.limit - v_10
        v_11 = self.limit - self.cursor
        self.__r_step_s9()
        self.cursor = self.limit - v_11
        v_12 = self.limit - self.cursor
        self.__r_step_s10()
        self.cursor = self.limit - v_12
        v_13 = self.limit - self.cursor
        self.__r_step_2a()
        self.cursor = self.limit - v_13
        v_14 = self.limit - self.cursor
        self.__r_step_2b()
        self.cursor = self.limit - v_14
        v_15 = self.limit - self.cursor
        self.__r_step_2c()
        self.cursor = self.limit - v_15
        v_16 = self.limit - self.cursor
        self.__r_step_2d()
        self.cursor = self.limit - v_16
        v_17 = self.limit - self.cursor
        self.__r_step_3()
        self.cursor = self.limit - v_17
        v_18 = self.limit - self.cursor
        self.__r_step_4()
        self.cursor = self.limit - v_18
        v_19 = self.limit - self.cursor
        self.__r_step_5a()
        self.cursor = self.limit - v_19
        v_20 = self.limit - self.cursor
        self.__r_step_5b()
        self.cursor = self.limit - v_20
        v_21 = self.limit - self.cursor
        self.__r_step_5c()
        self.cursor = self.limit - v_21
        v_22 = self.limit - self.cursor
        self.__r_step_5d()
        self.cursor = self.limit - v_22
        v_23 = self.limit - self.cursor
        self.__r_step_5e()
        self.cursor = self.limit - v_23
        v_24 = self.limit - self.cursor
        self.__r_step_5f()
        self.cursor = self.limit - v_24
        v_25 = self.limit - self.cursor
        self.__r_step_5g()
        self.cursor = self.limit - v_25
        v_26 = self.limit - self.cursor
        self.__r_step_5h()
        self.cursor = self.limit - v_26
        v_27 = self.limit - self.cursor
        self.__r_step_5j()
        self.cursor = self.limit - v_27
        v_28 = self.limit - self.cursor
        self.__r_step_5i()
        self.cursor = self.limit - v_28
        v_29 = self.limit - self.cursor
        self.__r_step_5k()
        self.cursor = self.limit - v_29
        v_30 = self.limit - self.cursor
        self.__r_step_5l()
        self.cursor = self.limit - v_30
        v_31 = self.limit - self.cursor
        self.__r_step_5m()
        self.cursor = self.limit - v_31
        v_32 = self.limit - self.cursor
        self.__r_step_6()
        self.cursor = self.limit - v_32
        v_33 = self.limit - self.cursor
        self.__r_step_7()
        self.cursor = self.limit - v_33
        self.cursor = self.limit_backward
        return True

    a_0 = [
        Among("", -1, 25),
        Among("Ά", 0, 1),
        Among("Έ", 0, 5),
        Among("Ή", 0, 7),
        Among("Ί", 0, 9),
        Among("Ό", 0, 15),
        Among("Ύ", 0, 20),
        Among("Ώ", 0, 24),
        Among("ΐ", 0, 7),
        Among("Α", 0, 1),
        Among("Β", 0, 2),
        Among("Γ", 0, 3),
        Among("Δ", 0, 4),
        Among("Ε", 0, 5),
        Among("Ζ", 0, 6),
        Among("Η", 0, 7),
        Among("Θ", 0, 8),
        Among("Ι", 0, 9),
        Among("Κ", 0, 10),
        Among("Λ", 0, 11),
        Among("Μ", 0, 12),
        Among("Ν", 0, 13),
        Among("Ξ", 0, 14),
        Among("Ο", 0, 15),
        Among("Π", 0, 16),
        Among("Ρ", 0, 17),
        Among("Σ", 0, 18),
        Among("Τ", 0, 19),
        Among("Υ", 0, 20),
        Among("Φ", 0, 21),
        Among("Χ", 0, 22),
        Among("Ψ", 0, 23),
        Among("Ω", 0, 24),
        Among("Ϊ", 0, 9),
        Among("Ϋ", 0, 20),
        Among("ά", 0, 1),
        Among("έ", 0, 5),
        Among("ή", 0, 7),
        Among("ί", 0, 9),
        Among("ΰ", 0, 20),
        Among("ς", 0, 18),
        Among("ϊ", 0, 7),
        Among("ϋ", 0, 20),
        Among("ό", 0, 15),
        Among("ύ", 0, 20),
        Among("ώ", 0, 24)
    ]

    a_1 = [
        Among("σκαγια", -1, 2),
        Among("φαγια", -1, 1),
        Among("ολογια", -1, 3),
        Among("σογια", -1, 4),
        Among("τατογια", -1, 5),
        Among("κρεατα", -1, 6),
        Among("περατα", -1, 7),
        Among("τερατα", -1, 8),
        Among("γεγονοτα", -1, 11),
        Among("καθεστωτα", -1, 10),
        Among("φωτα", -1, 9),
        Among("περατη", -1, 7),
        Among("σκαγιων", -1, 2),
        Among("φαγιων", -1, 1),
        Among("ολογιων", -1, 3),
        Among("σογιων", -1, 4),
        Among("τατογιων", -1, 5),
        Among("κρεατων", -1, 6),
        Among("περατων", -1, 7),
        Among("τερατων", -1, 8),
        Among("γεγονοτων", -1, 11),
        Among("καθεστωτων", -1, 10),
        Among("φωτων", -1, 9),
        Among("κρεασ", -1, 6),
        Among("περασ", -1, 7),
        Among("τερασ", -1, 8),
        Among("γεγονοσ", -1, 11),
        Among("κρεατοσ", -1, 6),
        Among("περατοσ", -1, 7),
        Among("τερατοσ", -1, 8),
        Among("γεγονοτοσ", -1, 11),
        Among("καθεστωτοσ", -1, 10),
        Among("φωτοσ", -1, 9),
        Among("καθεστωσ", -1, 10),
        Among("φωσ", -1, 9),
        Among("σκαγιου", -1, 2),
        Among("φαγιου", -1, 1),
        Among("ολογιου", -1, 3),
        Among("σογιου", -1, 4),
        Among("τατογιου", -1, 5)
    ]
    as_1 = ("φα", "σκα", "ολο", "σο", "τατο", "κρε", "περ", "τερ", "φω", "καθεστ", "γεγον")

    a_2 = [
        Among("πα", -1, 1),
        Among("ξαναπα", 0, 1),
        Among("επα", 0, 1),
        Among("περιπα", 0, 1),
        Among("αναμπα", 0, 1),
        Among("εμπα", 0, 1),
        Among("β", -1, 2),
        Among("δανε", -1, 1),
        Among("βαθυρι", -1, 2),
        Among("βαρκ", -1, 2),
        Among("μαρκ", -1, 2),
        Among("λ", -1, 2),
        Among("μ", -1, 2),
        Among("κορν", -1, 2),
        Among("αθρο", -1, 1),
        Among("συναθρο", 14, 1),
        Among("π", -1, 2),
        Among("ιμπ", 16, 2),
        Among("ρ", -1, 2),
        Among("μαρ", 18, 2),
        Among("αμπαρ", 18, 2),
        Among("γκρ", 18, 2),
        Among("βολβορ", 18, 2),
        Among("γλυκορ", 18, 2),
        Among("πιπερορ", 18, 2),
        Among("πρ", 18, 2),
        Among("μπρ", 25, 2),
        Among("αρρ", 18, 2),
        Among("γλυκυρ", 18, 2),
        Among("πολυρ", 18, 2),
        Among("λου", -1, 2)
    ]
    as_2 = ("ι", "ιζ")

    a_3 = [
        Among("ιζα", -1, 1),
        Among("ιζε", -1, 1),
        Among("ιζαμε", -1, 1),
        Among("ιζουμε", -1, 1),
        Among("ιζανε", -1, 1),
        Among("ιζουνε", -1, 1),
        Among("ιζατε", -1, 1),
        Among("ιζετε", -1, 1),
        Among("ιζει", -1, 1),
        Among("ιζαν", -1, 1),
        Among("ιζουν", -1, 1),
        Among("ιζεσ", -1, 1),
        Among("ιζεισ", -1, 1),
        Among("ιζω", -1, 1)
    ]

    a_4 = [
        Among("βι", -1, 1),
        Among("λι", -1, 1),
        Among("αλ", -1, 1),
        Among("εν", -1, 1),
        Among("σ", -1, 1),
        Among("χ", -1, 1),
        Among("υψ", -1, 1),
        Among("ζω", -1, 1)
    ]

    a_5 = [
        Among("ωθηκα", -1, 1),
        Among("ωθηκε", -1, 1),
        Among("ωθηκαμε", -1, 1),
        Among("ωθηκανε", -1, 1),
        Among("ωθηκατε", -1, 1),
        Among("ωθηκαν", -1, 1),
        Among("ωθηκεσ", -1, 1)
    ]

    a_6 = [
        Among("ξαναπα", -1, 1),
        Among("επα", -1, 1),
        Among("περιπα", -1, 1),
        Among("αναμπα", -1, 1),
        Among("εμπα", -1, 1),
        Among("χαρτοπα", -1, 1),
        Among("εξαρχα", -1, 1),
        Among("γε", -1, 2),
        Among("γκε", -1, 2),
        Among("κλε", -1, 1),
        Among("εκλε", 9, 1),
        Among("απεκλε", 10, 1),
        Among("αποκλε", 9, 1),
        Among("εσωκλε", 9, 1),
        Among("δανε", -1, 1),
        Among("πε", -1, 1),
        Among("επε", 15, 1),
        Among("μετεπε", 16, 1),
        Among("εσε", -1, 1),
        Among("γκ", -1, 2),
        Among("μ", -1, 2),
        Among("πουκαμ", 20, 2),
        Among("κομ", 20, 2),
        Among("αν", -1, 2),
        Among("ολο", -1, 2),
        Among("αθρο", -1, 1),
        Among("συναθρο", 25, 1),
        Among("π", -1, 2),
        Among("λαρ", -1, 2),
        Among("δημοκρατ", -1, 2),
        Among("αφ", -1, 2),
        Among("γιγαντοαφ", 30, 2)
    ]
    as_6 = ("ι", "ισ")

    a_7 = [
        Among("ισα", -1, 1),
        Among("ισαμε", -1, 1),
        Among("ισανε", -1, 1),
        Among("ισε", -1, 1),
        Among("ισατε", -1, 1),
        Among("ισαν", -1, 1),
        Among("ισεσ", -1, 1)
    ]

    a_8 = [
        Among("ξαναπα", -1, 1),
        Among("επα", -1, 1),
        Among("περιπα", -1, 1),
        Among("αναμπα", -1, 1),
        Among("εμπα", -1, 1),
        Among("χαρτοπα", -1, 1),
        Among("εξαρχα", -1, 1),
        Among("κλε", -1, 1),
        Among("εκλε", 7, 1),
        Among("απεκλε", 8, 1),
        Among("αποκλε", 7, 1),
        Among("εσωκλε", 7, 1),
        Among("δανε", -1, 1),
        Among("πε", -1, 1),
        Among("επε", 13, 1),
        Among("μετεπε", 14, 1),
        Among("εσε", -1, 1),
        Among("αθρο", -1, 1),
        Among("συναθρο", 17, 1)
    ]

    a_9 = [
        Among("ισουμε", -1, 1),
        Among("ισουνε", -1, 1),
        Among("ισετε", -1, 1),
        Among("ισει", -1, 1),
        Among("ισουν", -1, 1),
        Among("ισεισ", -1, 1),
        Among("ισω", -1, 1)
    ]

    a_10 = [
        Among("ατα", -1, 2),
        Among("φα", -1, 2),
        Among("ηφα", 1, 2),
        Among("μεγ", -1, 2),
        Among("λυγ", -1, 2),
        Among("ηδ", -1, 2),
        Among("κλε", -1, 1),
        Among("εσωκλε", 6, 1),
        Among("πλε", -1, 1),
        Among("δανε", -1, 1),
        Among("σε", -1, 1),
        Among("ασε", 10, 1),
        Among("καθ", -1, 2),
        Among("εχθ", -1, 2),
        Among("κακ", -1, 2),
        Among("μακ", -1, 2),
        Among("σκ", -1, 2),
        Among("φιλ", -1, 2),
        Among("κυλ", -1, 2),
        Among("μ", -1, 2),
        Among("γεμ", 19, 2),
        Among("αχν", -1, 2),
        Among("συναθρο", -1, 1),
        Among("π", -1, 2),
        Among("απ", 23, 2),
        Among("εμπ", 23, 2),
        Among("ευπ", 23, 2),
        Among("αρ", -1, 2),
        Among("αορ", -1, 2),
        Among("γυρ", -1, 2),
        Among("χρ", -1, 2),
        Among("χωρ", -1, 2),
        Among("κτ", -1, 2),
        Among("ακτ", 32, 2),
        Among("χτ", -1, 2),
        Among("αχτ", 34, 2),
        Among("ταχ", -1, 2),
        Among("σχ", -1, 2),
        Among("ασχ", 37, 2),
        Among("υψ", -1, 2)
    ]
    as_10 = ("ι", "ιστ")

    a_11 = [
        Among("ιστα", -1, 1),
        Among("ιστε", -1, 1),
        Among("ιστη", -1, 1),
        Among("ιστοι", -1, 1),
        Among("ιστων", -1, 1),
        Among("ιστο", -1, 1),
        Among("ιστεσ", -1, 1),
        Among("ιστησ", -1, 1),
        Among("ιστοσ", -1, 1),
        Among("ιστουσ", -1, 1),
        Among("ιστου", -1, 1)
    ]

    a_12 = [
        Among("εγκλε", -1, 1),
        Among("αποκλε", -1, 1),
        Among("δανε", -1, 2),
        Among("αντιδανε", 2, 2),
        Among("σε", -1, 1),
        Among("μετασε", 4, 1),
        Among("μικροσε", 4, 1)
    ]
    as_12 = ("ισμ", "ι")

    a_13 = [
        Among("ατομικ", -1, 2),
        Among("εθνικ", -1, 4),
        Among("τοπικ", -1, 7),
        Among("εκλεκτικ", -1, 5),
        Among("σκεπτικ", -1, 6),
        Among("γνωστικ", -1, 3),
        Among("αγνωστικ", 5, 1),
        Among("αλεξανδριν", -1, 8),
        Among("θεατριν", -1, 10),
        Among("βυζαντιν", -1, 9)
    ]
    as_13 = ("αγνωστ", "ατομ", "γνωστ", "εθν", "εκλεκτ", "σκεπτ", "τοπ", "αλεξανδρ", "βυζαντ", "θεατρ")

    a_14 = [
        Among("ισμοι", -1, 1),
        Among("ισμων", -1, 1),
        Among("ισμο", -1, 1),
        Among("ισμοσ", -1, 1),
        Among("ισμουσ", -1, 1),
        Among("ισμου", -1, 1)
    ]

    a_15 = [
        Among("σ", -1, 1),
        Among("χ", -1, 1)
    ]

    a_16 = [
        Among("ουδακια", -1, 1),
        Among("αρακια", -1, 1),
        Among("ουδακι", -1, 1),
        Among("αρακι", -1, 1)
    ]

    a_17 = [
        Among("β", -1, 2),
        Among("βαμβ", 0, 1),
        Among("σλοβ", 0, 1),
        Among("τσεχοσλοβ", 2, 1),
        Among("καρδ", -1, 2),
        Among("ζ", -1, 2),
        Among("τζ", 5, 1),
        Among("κ", -1, 1),
        Among("καπακ", 7, 1),
        Among("σοκ", 7, 1),
        Among("σκ", 7, 1),
        Among("βαλ", -1, 2),
        Among("μαλ", -1, 1),
        Among("γλ", -1, 2),
        Among("τριπολ", -1, 2),
        Among("πλ", -1, 1),
        Among("λουλ", -1, 1),
        Among("φυλ", -1, 1),
        Among("καιμ", -1, 1),
        Among("κλιμ", -1, 1),
        Among("φαρμ", -1, 1),
        Among("γιαν", -1, 2),
        Among("σπαν", -1, 1),
        Among("ηγουμεν", -1, 2),
        Among("κον", -1, 1),
        Among("μακρυν", -1, 2),
        Among("π", -1, 2),
        Among("κατραπ", 26, 1),
        Among("ρ", -1, 1),
        Among("βρ", 28, 1),
        Among("λαβρ", 29, 1),
        Among("αμβρ", 29, 1),
        Among("μερ", 28, 1),
        Among("πατερ", 28, 2),
        Among("ανθρ", 28, 1),
        Among("κορ", 28, 1),
        Among("σ", -1, 1),
        Among("ναγκασ", 36, 1),
        Among("τοσ", 36, 2),
        Among("μουστ", -1, 1),
        Among("ρυ", -1, 1),
        Among("φ", -1, 1),
        Among("σφ", 41, 1),
        Among("αλισφ", 42, 1),
        Among("νυφ", 41, 2),
        Among("χ", -1, 1)
    ]
    as_17 = ("ακ", "ιτσ")

    a_18 = [
        Among("ακια", -1, 1),
        Among("αρακια", 0, 1),
        Among("ιτσα", -1, 1),
        Among("ακι", -1, 1),
        Among("αρακι", 3, 1),
        Among("ιτσων", -1, 1),
        Among("ιτσασ", -1, 1),
        Among("ιτσεσ", -1, 1)
    ]

    a_19 = [
        Among("ψαλ", -1, 1),
        Among("αιφν", -1, 1),
        Among("ολο", -1, 1),
        Among("ιρ", -1, 1)
    ]

    a_20 = [
        Among("ε", -1, 1),
        Among("παιχν", -1, 1)
    ]

    a_21 = [
        Among("ιδια", -1, 1),
        Among("ιδιων", -1, 1),
        Among("ιδιο", -1, 1)
    ]

    a_22 = [
        Among("ιβ", -1, 1),
        Among("δ", -1, 1),
        Among("φραγκ", -1, 1),
        Among("λυκ", -1, 1),
        Among("οβελ", -1, 1),
        Among("μην", -1, 1),
        Among("ρ", -1, 1)
    ]

    a_23 = [
        Among("ισκε", -1, 1),
        Among("ισκο", -1, 1),
        Among("ισκοσ", -1, 1),
        Among("ισκου", -1, 1)
    ]

    a_24 = [
        Among("αδων", -1, 1),
        Among("αδεσ", -1, 1)
    ]

    a_25 = [
        Among("γιαγι", -1, -1),
        Among("θει", -1, -1),
        Among("οκ", -1, -1),
        Among("μαμ", -1, -1),
        Among("μαν", -1, -1),
        Among("μπαμπ", -1, -1),
        Among("πεθερ", -1, -1),
        Among("πατερ", -1, -1),
        Among("κυρ", -1, -1),
        Among("νταντ", -1, -1)
    ]

    a_26 = [
        Among("εδων", -1, 1),
        Among("εδεσ", -1, 1)
    ]

    a_27 = [
        Among("μιλ", -1, 1),
        Among("δαπ", -1, 1),
        Among("γηπ", -1, 1),
        Among("ιπ", -1, 1),
        Among("εμπ", -1, 1),
        Among("οπ", -1, 1),
        Among("κρασπ", -1, 1),
        Among("υπ", -1, 1)
    ]

    a_28 = [
        Among("ουδων", -1, 1),
        Among("ουδεσ", -1, 1)
    ]

    a_29 = [
        Among("τραγ", -1, 1),
        Among("φε", -1, 1),
        Among("καλιακ", -1, 1),
        Among("αρκ", -1, 1),
        Among("σκ", -1, 1),
        Among("πεταλ", -1, 1),
        Among("βελ", -1, 1),
        Among("λουλ", -1, 1),
        Among("φλ", -1, 1),
        Among("χν", -1, 1),
        Among("πλεξ", -1, 1),
        Among("σπ", -1, 1),
        Among("φρ", -1, 1),
        Among("σ", -1, 1),
        Among("λιχ", -1, 1)
    ]

    a_30 = [
        Among("εων", -1, 1),
        Among("εωσ", -1, 1)
    ]

    a_31 = [
        Among("δ", -1, 1),
        Among("ιδ", 0, 1),
        Among("θ", -1, 1),
        Among("γαλ", -1, 1),
        Among("ελ", -1, 1),
        Among("ν", -1, 1),
        Among("π", -1, 1),
        Among("παρ", -1, 1)
    ]

    a_32 = [
        Among("ια", -1, 1),
        Among("ιων", -1, 1),
        Among("ιου", -1, 1)
    ]

    a_33 = [
        Among("ικα", -1, 1),
        Among("ικων", -1, 1),
        Among("ικο", -1, 1),
        Among("ικου", -1, 1)
    ]

    a_34 = [
        Among("αδ", -1, 1),
        Among("συναδ", 0, 1),
        Among("καταδ", 0, 1),
        Among("αντιδ", -1, 1),
        Among("ενδ", -1, 1),
        Among("φυλοδ", -1, 1),
        Among("υποδ", -1, 1),
        Among("πρωτοδ", -1, 1),
        Among("εξωδ", -1, 1),
        Among("ηθ", -1, 1),
        Among("ανηθ", 9, 1),
        Among("ξικ", -1, 1),
        Among("αλ", -1, 1),
        Among("αμμοχαλ", 12, 1),
        Among("συνομηλ", -1, 1),
        Among("μπολ", -1, 1),
        Among("μουλ", -1, 1),
        Among("τσαμ", -1, 1),
        Among("βρωμ", -1, 1),
        Among("αμαν", -1, 1),
        Among("μπαν", -1, 1),
        Among("καλλιν", -1, 1),
        Among("ποστελν", -1, 1),
        Among("φιλον", -1, 1),
        Among("καλπ", -1, 1),
        Among("γερ", -1, 1),
        Among("χασ", -1, 1),
        Among("μποσ", -1, 1),
        Among("πλιατσ", -1, 1),
        Among("πετσ", -1, 1),
        Among("πιτσ", -1, 1),
        Among("φυσ", -1, 1),
        Among("μπαγιατ", -1, 1),
        Among("νιτ", -1, 1),
        Among("πικαντ", -1, 1),
        Among("σερτ", -1, 1)
    ]

    a_35 = [
        Among("αγαμε", -1, 1),
        Among("ηκαμε", -1, 1),
        Among("ηθηκαμε", 1, 1),
        Among("ησαμε", -1, 1),
        Among("ουσαμε", -1, 1)
    ]

    a_36 = [
        Among("βουβ", -1, 1),
        Among("ξεθ", -1, 1),
        Among("πεθ", -1, 1),
        Among("αποθ", -1, 1),
        Among("αποκ", -1, 1),
        Among("ουλ", -1, 1),
        Among("αναπ", -1, 1),
        Among("πικρ", -1, 1),
        Among("ποτ", -1, 1),
        Among("αποστ", -1, 1),
        Among("χ", -1, 1),
        Among("σιχ", 10, 1)
    ]

    a_37 = [
        Among("τρ", -1, 1),
        Among("τσ", -1, 1)
    ]

    a_38 = [
        Among("αγανε", -1, 1),
        Among("ηκανε", -1, 1),
        Among("ηθηκανε", 1, 1),
        Among("ησανε", -1, 1),
        Among("ουσανε", -1, 1),
        Among("οντανε", -1, 1),
        Among("ιοντανε", 5, 1),
        Among("ουντανε", -1, 1),
        Among("ιουντανε", 7, 1),
        Among("οτανε", -1, 1),
        Among("ιοτανε", 9, 1)
    ]

    a_39 = [
        Among("ταβ", -1, 1),
        Among("νταβ", 0, 1),
        Among("ψηλοταβ", 0, 1),
        Among("λιβ", -1, 1),
        Among("κλιβ", 3, 1),
        Among("ξηροκλιβ", 4, 1),
        Among("γ", -1, 1),
        Among("αγ", 6, 1),
        Among("τραγ", 7, 1),
        Among("τσαγ", 7, 1),
        Among("αθιγγ", 6, 1),
        Among("τσιγγ", 6, 1),
        Among("ατσιγγ", 11, 1),
        Among("στεγ", 6, 1),
        Among("απηγ", 6, 1),
        Among("σιγ", 6, 1),
        Among("ανοργ", 6, 1),
        Among("ενοργ", 6, 1),
        Among("καλπουζ", -1, 1),
        Among("θ", -1, 1),
        Among("μωαμεθ", 19, 1),
        Among("πιθ", 19, 1),
        Among("απιθ", 21, 1),
        Among("δεκ", -1, 1),
        Among("πελεκ", -1, 1),
        Among("ικ", -1, 1),
        Among("ανικ", 25, 1),
        Among("βουλκ", -1, 1),
        Among("βασκ", -1, 1),
        Among("βραχυκ", -1, 1),
        Among("γαλ", -1, 1),
        Among("καταγαλ", 30, 1),
        Among("ολογαλ", 30, 1),
        Among("βαθυγαλ", 30, 1),
        Among("μελ", -1, 1),
        Among("καστελ", -1, 1),
        Among("πορτολ", -1, 1),
        Among("πλ", -1, 1),
        Among("διπλ", 37, 1),
        Among("λαοπλ", 37, 1),
        Among("ψυχοπλ", 37, 1),
        Among("ουλ", -1, 1),
        Among("μ", -1, 1),
        Among("ολιγοδαμ", 42, 1),
        Among("μουσουλμ", 42, 1),
        Among("δραδουμ", 42, 1),
        Among("βραχμ", 42, 1),
        Among("ν", -1, 1),
        Among("αμερικαν", 47, 1),
        Among("π", -1, 1),
        Among("αδαπ", 49, 1),
        Among("χαμηλοδαπ", 49, 1),
        Among("πολυδαπ", 49, 1),
        Among("κοπ", 49, 1),
        Among("υποκοπ", 53, 1),
        Among("τσοπ", 49, 1),
        Among("σπ", 49, 1),
        Among("ερ", -1, 1),
        Among("γερ", 57, 1),
        Among("βετερ", 57, 1),
        Among("λουθηρ", -1, 1),
        Among("κορμορ", -1, 1),
        Among("περιτρ", -1, 1),
        Among("ουρ", -1, 1),
        Among("σ", -1, 1),
        Among("βασ", 64, 1),
        Among("πολισ", 64, 1),
        Among("σαρακατσ", 64, 1),
        Among("θυσ", 64, 1),
        Among("διατ", -1, 1),
        Among("πλατ", -1, 1),
        Among("τσαρλατ", -1, 1),
        Among("τετ", -1, 1),
        Among("πουριτ", -1, 1),
        Among("σουλτ", -1, 1),
        Among("μαιντ", -1, 1),
        Among("ζωντ", -1, 1),
        Among("καστ", -1, 1),
        Among("φ", -1, 1),
        Among("διαφ", 78, 1),
        Among("στεφ", 78, 1),
        Among("φωτοστεφ", 80, 1),
        Among("περηφ", 78, 1),
        Among("υπερηφ", 82, 1),
        Among("κοιλαρφ", 78, 1),
        Among("πενταρφ", 78, 1),
        Among("ορφ", 78, 1),
        Among("χ", -1, 1),
        Among("αμηχ", 87, 1),
        Among("βιομηχ", 87, 1),
        Among("μεγλοβιομηχ", 89, 1),
        Among("καπνοβιομηχ", 89, 1),
        Among("μικροβιομηχ", 89, 1),
        Among("πολυμηχ", 87, 1),
        Among("λιχ", 87, 1)
    ]

    a_40 = [
        Among("ενδ", -1, 1),
        Among("συνδ", -1, 1),
        Among("οδ", -1, 1),
        Among("διαθ", -1, 1),
        Among("καθ", -1, 1),
        Among("ραθ", -1, 1),
        Among("ταθ", -1, 1),
        Among("τιθ", -1, 1),
        Among("εκθ", -1, 1),
        Among("ενθ", -1, 1),
        Among("συνθ", -1, 1),
        Among("ροθ", -1, 1),
        Among("υπερθ", -1, 1),
        Among("σθ", -1, 1),
        Among("ευθ", -1, 1),
        Among("αρκ", -1, 1),
        Among("ωφελ", -1, 1),
        Among("βολ", -1, 1),
        Among("αιν", -1, 1),
        Among("πον", -1, 1),
        Among("ρον", -1, 1),
        Among("συν", -1, 1),
        Among("βαρ", -1, 1),
        Among("βρ", -1, 1),
        Among("αιρ", -1, 1),
        Among("φορ", -1, 1),
        Among("ευρ", -1, 1),
        Among("πυρ", -1, 1),
        Among("χωρ", -1, 1),
        Among("νετ", -1, 1),
        Among("σχ", -1, 1)
    ]

    a_41 = [
        Among("παγ", -1, 1),
        Among("δ", -1, 1),
        Among("αδ", 1, 1),
        Among("θ", -1, 1),
        Among("αθ", 3, 1),
        Among("τοκ", -1, 1),
        Among("σκ", -1, 1),
        Among("παρακαλ", -1, 1),
        Among("σκελ", -1, 1),
        Among("απλ", -1, 1),
        Among("εμ", -1, 1),
        Among("αν", -1, 1),
        Among("βεν", -1, 1),
        Among("βαρον", -1, 1),
        Among("κοπ", -1, 1),
        Among("σερπ", -1, 1),
        Among("αβαρ", -1, 1),
        Among("εναρ", -1, 1),
        Among("αβρ", -1, 1),
        Among("μπορ", -1, 1),
        Among("θαρρ", -1, 1),
        Among("ντρ", -1, 1),
        Among("υ", -1, 1),
        Among("νιφ", -1, 1),
        Among("συρφ", -1, 1)
    ]

    a_42 = [
        Among("οντασ", -1, 1),
        Among("ωντασ", -1, 1)
    ]

    a_43 = [
        Among("ομαστε", -1, 1),
        Among("ιομαστε", 0, 1)
    ]

    a_44 = [
        Among("π", -1, 1),
        Among("απ", 0, 1),
        Among("ακαταπ", 1, 1),
        Among("συμπ", 0, 1),
        Among("ασυμπ", 3, 1),
        Among("αμεταμφ", -1, 1)
    ]

    a_45 = [
        Among("ζ", -1, 1),
        Among("αλ", -1, 1),
        Among("παρακαλ", 1, 1),
        Among("εκτελ", -1, 1),
        Among("μ", -1, 1),
        Among("ξ", -1, 1),
        Among("προ", -1, 1),
        Among("αρ", -1, 1),
        Among("νισ", -1, 1)
    ]

    a_46 = [
        Among("ηθηκα", -1, 1),
        Among("ηθηκε", -1, 1),
        Among("ηθηκεσ", -1, 1)
    ]

    a_47 = [
        Among("πιθ", -1, 1),
        Among("οθ", -1, 1),
        Among("ναρθ", -1, 1),
        Among("σκουλ", -1, 1),
        Among("σκωλ", -1, 1),
        Among("σφ", -1, 1)
    ]

    a_48 = [
        Among("θ", -1, 1),
        Among("διαθ", 0, 1),
        Among("παρακαταθ", 0, 1),
        Among("συνθ", 0, 1),
        Among("προσθ", 0, 1)
    ]

    a_49 = [
        Among("ηκα", -1, 1),
        Among("ηκε", -1, 1),
        Among("ηκεσ", -1, 1)
    ]

    a_50 = [
        Among("φαγ", -1, 1),
        Among("ληγ", -1, 1),
        Among("φρυδ", -1, 1),
        Among("μαντιλ", -1, 1),
        Among("μαλλ", -1, 1),
        Among("ομ", -1, 1),
        Among("βλεπ", -1, 1),
        Among("ποδαρ", -1, 1),
        Among("κυματ", -1, 1),
        Among("πρωτ", -1, 1),
        Among("λαχ", -1, 1),
        Among("πανταχ", -1, 1)
    ]

    a_51 = [
        Among("τσα", -1, 1),
        Among("χαδ", -1, 1),
        Among("μεδ", -1, 1),
        Among("λαμπιδ", -1, 1),
        Among("δε", -1, 1),
        Among("πλε", -1, 1),
        Among("μεσαζ", -1, 1),
        Among("δεσποζ", -1, 1),
        Among("αιθ", -1, 1),
        Among("φαρμακ", -1, 1),
        Among("αγκ", -1, 1),
        Among("ανηκ", -1, 1),
        Among("λ", -1, 1),
        Among("μ", -1, 1),
        Among("αμ", 13, 1),
        Among("βρομ", 13, 1),
        Among("υποτειν", -1, 1),
        Among("εκλιπ", -1, 1),
        Among("ρ", -1, 1),
        Among("ενδιαφερ", 18, 1),
        Among("αναρρ", 18, 1),
        Among("πατ", -1, 1),
        Among("καθαρευ", -1, 1),
        Among("δευτερευ", -1, 1),
        Among("λεχ", -1, 1)
    ]

    a_52 = [
        Among("ουσα", -1, 1),
        Among("ουσε", -1, 1),
        Among("ουσεσ", -1, 1)
    ]

    a_53 = [
        Among("πελ", -1, 1),
        Among("λλ", -1, 1),
        Among("σμην", -1, 1),
        Among("ρπ", -1, 1),
        Among("πρ", -1, 1),
        Among("φρ", -1, 1),
        Among("χορτ", -1, 1),
        Among("οφ", -1, 1),
        Among("ψοφ", 7, -1),
        Among("σφ", -1, 1),
        Among("λοχ", -1, 1),
        Among("ναυλοχ", 10, -1)
    ]

    a_54 = [
        Among("αμαλλι", -1, 1),
        Among("λ", -1, 1),
        Among("αμαλ", 1, 1),
        Among("μ", -1, 1),
        Among("ουλαμ", 3, 1),
        Among("εν", -1, 1),
        Among("δερβεν", 5, 1),
        Among("π", -1, 1),
        Among("αειπ", 7, 1),
        Among("αρτιπ", 7, 1),
        Among("συμπ", 7, 1),
        Among("νεοπ", 7, 1),
        Among("κροκαλοπ", 7, 1),
        Among("ολοπ", 7, 1),
        Among("προσωποπ", 7, 1),
        Among("σιδηροπ", 7, 1),
        Among("δροσοπ", 7, 1),
        Among("ασπ", 7, 1),
        Among("ανυπ", 7, 1),
        Among("ρ", -1, 1),
        Among("ασπαρ", 19, 1),
        Among("χαρ", 19, 1),
        Among("αχαρ", 21, 1),
        Among("απερ", 19, 1),
        Among("τρ", 19, 1),
        Among("ουρ", 19, 1),
        Among("τ", -1, 1),
        Among("διατ", 26, 1),
        Among("επιτ", 26, 1),
        Among("συντ", 26, 1),
        Among("ομοτ", 26, 1),
        Among("νομοτ", 30, 1),
        Among("αποτ", 26, 1),
        Among("υποτ", 26, 1),
        Among("αβαστ", 26, 1),
        Among("αιμοστ", 26, 1),
        Among("προστ", 26, 1),
        Among("ανυστ", 26, 1),
        Among("ναυ", -1, 1),
        Among("αφ", -1, 1),
        Among("ξεφ", -1, 1),
        Among("αδηφ", -1, 1),
        Among("παμφ", -1, 1),
        Among("πολυφ", -1, 1)
    ]

    a_55 = [
        Among("αγα", -1, 1),
        Among("αγε", -1, 1),
        Among("αγεσ", -1, 1)
    ]

    a_56 = [
        Among("ησα", -1, 1),
        Among("ησε", -1, 1),
        Among("ησου", -1, 1)
    ]

    a_57 = [
        Among("ν", -1, 1),
        Among("δωδεκαν", 0, 1),
        Among("επταν", 0, 1),
        Among("μεγαλον", 0, 1),
        Among("ερημον", 0, 1),
        Among("χερσον", 0, 1)
    ]

    a_58 = [
        Among("σβ", -1, 1),
        Among("ασβ", 0, 1),
        Among("απλ", -1, 1),
        Among("αειμν", -1, 1),
        Among("χρ", -1, 1),
        Among("αχρ", 4, 1),
        Among("κοινοχρ", 4, 1),
        Among("δυσχρ", 4, 1),
        Among("ευχρ", 4, 1),
        Among("παλιμψ", -1, 1)
    ]

    a_59 = [
        Among("ουνε", -1, 1),
        Among("ηθουνε", 0, 1),
        Among("ησουνε", 0, 1)
    ]

    a_60 = [
        Among("σπι", -1, 1),
        Among("ν", -1, 1),
        Among("εξων", 1, 1),
        Among("ρ", -1, 1),
        Among("στραβομουτσ", -1, 1),
        Among("κακομουτσ", -1, 1)
    ]

    a_61 = [
        Among("ουμε", -1, 1),
        Among("ηθουμε", 0, 1),
        Among("ησουμε", 0, 1)
    ]

    a_62 = [
        Among("αζ", -1, 1),
        Among("ωριοπλ", -1, 1),
        Among("ασουσ", -1, 1),
        Among("παρασουσ", 2, 1),
        Among("αλλοσουσ", -1, 1),
        Among("φ", -1, 1),
        Among("χ", -1, 1)
    ]

    a_63 = [
        Among("ματα", -1, 1),
        Among("ματων", -1, 1),
        Among("ματοσ", -1, 1)
    ]

    a_64 = [
        Among("α", -1, 1),
        Among("ιουμα", 0, 1),
        Among("ομουνα", 0, 1),
        Among("ιομουνα", 2, 1),
        Among("οσουνα", 0, 1),
        Among("ιοσουνα", 4, 1),
        Among("ε", -1, 1),
        Among("αγατε", 6, 1),
        Among("ηκατε", 6, 1),
        Among("ηθηκατε", 8, 1),
        Among("ησατε", 6, 1),
        Among("ουσατε", 6, 1),
        Among("ειτε", 6, 1),
        Among("ηθειτε", 12, 1),
        Among("ιεμαστε", 6, 1),
        Among("ουμαστε", 6, 1),
        Among("ιουμαστε", 15, 1),
        Among("ιεσαστε", 6, 1),
        Among("οσαστε", 6, 1),
        Among("ιοσαστε", 18, 1),
        Among("η", -1, 1),
        Among("ι", -1, 1),
        Among("αμαι", 21, 1),
        Among("ιεμαι", 21, 1),
        Among("ομαι", 21, 1),
        Among("ουμαι", 21, 1),
        Among("ασαι", 21, 1),
        Among("εσαι", 21, 1),
        Among("ιεσαι", 27, 1),
        Among("αται", 21, 1),
        Among("εται", 21, 1),
        Among("ιεται", 30, 1),
        Among("ονται", 21, 1),
        Among("ουνται", 21, 1),
        Among("ιουνται", 33, 1),
        Among("ει", 21, 1),
        Among("αει", 35, 1),
        Among("ηθει", 35, 1),
        Among("ησει", 35, 1),
        Among("οι", 21, 1),
        Among("αν", -1, 1),
        Among("αγαν", 40, 1),
        Among("ηκαν", 40, 1),
        Among("ηθηκαν", 42, 1),
        Among("ησαν", 40, 1),
        Among("ουσαν", 40, 1),
        Among("οντουσαν", 45, 1),
        Among("ιοντουσαν", 46, 1),
        Among("ονταν", 40, 1),
        Among("ιονταν", 48, 1),
        Among("ουνταν", 40, 1),
        Among("ιουνταν", 50, 1),
        Among("οταν", 40, 1),
        Among("ιοταν", 52, 1),
        Among("ομασταν", 40, 1),
        Among("ιομασταν", 54, 1),
        Among("οσασταν", 40, 1),
        Among("ιοσασταν", 56, 1),
        Among("ουν", -1, 1),
        Among("ηθουν", 58, 1),
        Among("ομουν", 58, 1),
        Among("ιομουν", 60, 1),
        Among("ησουν", 58, 1),
        Among("οσουν", 58, 1),
        Among("ιοσουν", 63, 1),
        Among("ων", -1, 1),
        Among("ηδων", 65, 1),
        Among("ο", -1, 1),
        Among("ασ", -1, 1),
        Among("εσ", -1, 1),
        Among("ηδεσ", 69, 1),
        Among("ησεσ", 69, 1),
        Among("ησ", -1, 1),
        Among("εισ", -1, 1),
        Among("ηθεισ", 73, 1),
        Among("οσ", -1, 1),
        Among("υσ", -1, 1),
        Among("ουσ", 76, 1),
        Among("υ", -1, 1),
        Among("ου", 78, 1),
        Among("ω", -1, 1),
        Among("αω", 80, 1),
        Among("ηθω", 80, 1),
        Among("ησω", 80, 1)
    ]

    a_65 = [
        Among("οτερ", -1, 1),
        Among("εστερ", -1, 1),
        Among("υτερ", -1, 1),
        Among("ωτερ", -1, 1),
        Among("οτατ", -1, 1),
        Among("εστατ", -1, 1),
        Among("υτατ", -1, 1),
        Among("ωτατ", -1, 1)
    ]


class lab0(BaseException): pass
