"""Test the pypdf._doc_common module."""
import itertools
import re
import shutil
import subprocess
from io import BytesIO
from operator import itemgetter
from pathlib import Path
from unittest import mock

import pytest

from pypdf import PdfReader, PdfWriter
from pypdf.errors import LimitReachedError, PdfReadError
from pypdf.filters import FlateDecode
from pypdf.generic import (
    ArrayObject,
    DictionaryObject,
    EmbeddedFile,
    EncodedStreamObject,
    NameObject,
    NullObject,
    NumberObject,
    RectangleObject,
    TextStringObject,
    TreeObject,
    ViewerPreferences,
)
from tests import RESOURCE_ROOT, SAMPLE_ROOT, get_data_from_url

PDFATTACH_BINARY = shutil.which("pdfattach")


@pytest.mark.skipif(PDFATTACH_BINARY is None, reason="Requires poppler-utils")
def test_attachments(tmpdir):
    tmpdir = Path(tmpdir)

    # No attachments.
    clean_path = SAMPLE_ROOT / "002-trivial-libre-office-writer" / "002-trivial-libre-office-writer.pdf"
    with PdfReader(clean_path) as pdf:
        assert pdf._list_attachments() == []
        assert list(pdf.attachment_list) == []

    # UF = name.
    attached_path = tmpdir / "attached.pdf"
    file_path = tmpdir / "test.txt"
    file_path.write_bytes(b"Hello World\n")
    subprocess.run([PDFATTACH_BINARY, clean_path, file_path, attached_path])  # noqa: S603
    with PdfReader(attached_path) as pdf:
        assert pdf._list_attachments() == ["test.txt"]
        assert pdf._get_attachments("test.txt") == {"test.txt": b"Hello World\n"}
        assert [(x.name, x.content) for x in pdf.attachment_list] == [("test.txt", b"Hello World\n")]
        assert next(pdf.attachment_list).alternative_name == "test.txt"

    # UF != name.
    different_path = tmpdir / "different.pdf"
    different_path.write_bytes(re.sub(rb" /UF [^/]+ /", b" /UF(my-file.txt) /", attached_path.read_bytes()))
    with PdfReader(different_path) as pdf:
        assert pdf._list_attachments() == ["test.txt", "my-file.txt"]
        assert pdf._get_attachments("test.txt") == {"test.txt": b"Hello World\n"}
        assert pdf._get_attachments("my-file.txt") == {"my-file.txt": b"Hello World\n"}
        assert [(x.name, x.content) for x in pdf.attachment_list] == [("test.txt", b"Hello World\n")]
        assert next(pdf.attachment_list).alternative_name == "my-file.txt"

    # Only name.
    no_f_path = tmpdir / "no-f.pdf"
    no_f_path.write_bytes(re.sub(rb" /UF [^/]+ /", b" /", attached_path.read_bytes()))
    with PdfReader(no_f_path) as pdf:
        assert pdf._list_attachments() == ["test.txt"]
        assert pdf._get_attachments("test.txt") == {"test.txt": b"Hello World\n"}
        assert [(x.name, x.content) for x in pdf.attachment_list] == [("test.txt", b"Hello World\n")]
        assert next(pdf.attachment_list).alternative_name is None

    # UF and F.
    uf_f_path = tmpdir / "uf-f.pdf"
    uf_f_path.write_bytes(attached_path.read_bytes().replace(b" /UF ", b"/F(file.txt) /UF "))
    with PdfReader(uf_f_path) as pdf:
        assert pdf._list_attachments() == ["test.txt"]
        assert pdf._get_attachments("test.txt") == {"test.txt": b"Hello World\n"}
        assert [(x.name, x.content) for x in pdf.attachment_list] == [("test.txt", b"Hello World\n")]
        assert next(pdf.attachment_list).alternative_name == "test.txt"

    # Only F.
    only_f_path = tmpdir / "f.pdf"
    only_f_path.write_bytes(attached_path.read_bytes().replace(b" /UF ", b" /F "))
    with PdfReader(only_f_path) as pdf:
        assert pdf._list_attachments() == ["test.txt"]
        assert pdf._get_attachments("test.txt") == {"test.txt": b"Hello World\n"}
        assert [(x.name, x.content) for x in pdf.attachment_list] == [("test.txt", b"Hello World\n")]
        assert next(pdf.attachment_list).alternative_name == "test.txt"


def test_get_attachments__same_attachment_more_than_twice():
    writer = PdfWriter()
    writer.add_blank_page(100, 100)
    for i in range(5):
        writer.add_attachment("test.txt", f"content{i}")
    assert writer._get_attachments("test.txt") == {
        "test.txt": [b"content0", b"content1", b"content2", b"content3", b"content4"]
    }
    assert [(x.name, x.content) for x in writer.attachment_list] == [
        ("test.txt", b"content0"),
        ("test.txt", b"content1"),
        ("test.txt", b"content2"),
        ("test.txt", b"content3"),
        ("test.txt", b"content4"),
    ]


def test_get_attachments__alternative_name_is_none():
    writer = PdfWriter()
    attachment = EmbeddedFile(name="test.txt", pdf_object=writer.root_object)
    assert attachment.alternative_name is None
    with mock.patch(
            "pypdf._writer.PdfWriter.attachment_list",
            new_callable=mock.PropertyMock(return_value=[attachment])
    ), mock.patch(
            "pypdf.generic._files.EmbeddedFile.content",
            new_callable=mock.PropertyMock(return_value=b"content")
    ):
        assert writer._get_attachments() == {"test.txt": b"content"}


@pytest.mark.enable_socket
def test_byte_encoded_named_destinations():
    url = "https://github.com/user-attachments/files/19820164/pypdf_issue.pdf"
    name = "issue3261.pdf"
    reader = PdfReader(BytesIO(get_data_from_url(url=url, name=name)))

    page = reader.pages[0]
    for annotation in page.annotations:
        if annotation.get("/Subtype") == "/Link":
            action = annotation["/A"]
            if action["/S"] == "/GoTo":
                named_dest = action["/D"]
                assert str(named_dest) in reader.named_destinations
                assert TextStringObject(named_dest) in reader.named_destinations

    assert reader.named_destinations == {
        "Doc-Start": {
            "/Title": "Doc-Start",
            "/Page": page.indirect_reference,
            "/Type": "/XYZ",
            "/Left": 133.768,
            "/Top": 667.198,
            "/Zoom": NullObject()
        },
        "cite.dacÃ\xadk2025racerflightweightstaticdata": {
            "/Title": "cite.dacÃ\xadk2025racerflightweightstaticdata",
            "/Page": page.indirect_reference,
            "/Type": "/XYZ",
            "/Left": 133.768,
            "/Top": 614.424,
            "/Zoom": NullObject()
        },
        # This is the same as the previous entry, but with `str(name)` instead of the title.
        "楣整搮捡귃㉫㈰爵捡牥汦杩瑨敷杩瑨瑳瑡捩慤慴": {
            "/Left": 133.768,
            "/Page": page.indirect_reference,
            "/Title": "cite.dacÃ\xadk2025racerflightweightstaticdata",
            "/Top": 614.424,
            "/Type": "/XYZ",
            "/Zoom": NullObject()
        },
        "page.1": {
            "/Title": "page.1",
            "/Page": page.indirect_reference,
            "/Type": "/XYZ",
            "/Left": 132.768,
            "/Top": 705.06,
            "/Zoom": NullObject()
        },
        "section*.1": {
            "/Title": "section*.1",
            "/Page": page.indirect_reference,
            "/Type": "/XYZ",
            "/Left": 133.768,
            "/Top": 642.222,
            "/Zoom": NullObject()
        }
    }


def test_viewer_preferences__indirect_reference():
    input_path = RESOURCE_ROOT / "git.pdf"
    reader = PdfReader(input_path)
    assert (0, 24) not in reader.resolved_objects
    viewer_preferences = reader.viewer_preferences
    assert isinstance(viewer_preferences, ViewerPreferences)
    assert viewer_preferences == {"/DisplayDocTitle": True}
    assert (0, 24) in reader.resolved_objects
    assert id(viewer_preferences) == id(reader.viewer_preferences)
    assert id(viewer_preferences) == id(reader.resolved_objects[(0, 24)])


def test_build_destination__short_array():
    writer = PdfWriter()
    writer.add_blank_page(width=72, height=72)

    # An array too short to hold a page reference and a fit type degrades to a
    # null destination instead of raising on the unpacking.
    dest = writer._build_destination("title", ArrayObject([NumberObject(0)]))
    assert isinstance(dest["/Page"], NullObject)

    # A trailing fit type with the wrong number of arguments still builds.
    dest = writer._build_destination(
        "title", ArrayObject([NumberObject(0), NameObject("/FitR"), NumberObject(1), NumberObject(2)])
    )
    assert dest["/Type"] == "/FitR"


def _reader_with_button_field(field: DictionaryObject) -> PdfReader:
    writer = PdfWriter()
    writer.add_blank_page(width=72, height=72)
    reference = writer._add_object(field)
    acroform = DictionaryObject()
    acroform[NameObject("/Fields")] = ArrayObject([reference])
    writer.root_object[NameObject("/AcroForm")] = writer._add_object(acroform)
    stream = BytesIO()
    writer.write(stream)
    stream.seek(0)
    return PdfReader(stream)


def test_build_field__checkbox_missing_normal_appearance():
    # A checkbox whose /AP is not a dictionary raises a clean PdfReadError
    # instead of an uncaught KeyError.
    field = DictionaryObject()
    field[NameObject("/T")] = TextStringObject("CheckBox")
    field[NameObject("/FT")] = NameObject("/Btn")
    field[NameObject("/AP")] = ArrayObject()
    with pytest.raises(PdfReadError, match="Expected appearance dictionary"):
        _reader_with_button_field(field).get_fields()

    # A checkbox whose /AP has no /N sub-dictionary raises likewise.
    field[NameObject("/AP")] = DictionaryObject()
    with pytest.raises(PdfReadError, match="Expected /N appearance dictionary"):
        _reader_with_button_field(field).get_fields()

    # A well-formed /AP /N still collects the appearance states.
    normal = DictionaryObject()
    normal[NameObject("/Yes")] = NumberObject(1)
    appearance = DictionaryObject()
    appearance[NameObject("/N")] = normal
    field[NameObject("/AP")] = appearance
    fields = _reader_with_button_field(field).get_fields()
    assert list(fields["CheckBox"]["/_States_"]) == ["/Yes", "/Off"]


def test_build_field__radio_kid_missing_appearance():
    # A radio kid lacking /AP raises a clean PdfReadError instead of a KeyError.
    field = DictionaryObject()
    field[NameObject("/T")] = TextStringObject("Radio")
    field[NameObject("/FT")] = NameObject("/Btn")
    field[NameObject("/Ff")] = NumberObject(1 << 15)
    field[NameObject("/Kids")] = ArrayObject([DictionaryObject()])
    with pytest.raises(PdfReadError, match="missing /AP"):
        _reader_with_button_field(field).get_fields()


@pytest.mark.enable_socket
def test_named_destinations__tree_is_null_object():
    url = "https://github.com/user-attachments/files/20885216/test.pdf"
    name = "issue3330.pdf"
    reader = PdfReader(BytesIO(get_data_from_url(url=url, name=name)))

    assert reader.named_destinations == {}


@pytest.mark.enable_socket
def test_outline__issue3462():
    url = "https://github.com/user-attachments/files/22293402/e371fffe0b_a7cccde95a.pdf"
    name = "issue3462.pdf"
    reader = PdfReader(BytesIO(get_data_from_url(url=url, name=name)))

    outline_flat = list(
        itertools.chain.from_iterable(
            entry if isinstance(entry, list) else [entry] for entry in reader.outline
        )
    )
    assert list(map(itemgetter("/Title"), outline_flat)) == [
        "AR 2021 - Daftar Isi",
        "Page 1",
        "Page 2",
        "Page 3",
        "Page 4",
        "Page 5",
        "AR 2021 Book 001 (Highlights - Ikhtisar Saham)",
        "Page 1",
        "Page 2",
        "Page 3",
        "Page 4",
        "Page 5",
        "AR 2021 Book 002 (Laporan Manajemen)",
        "Page 1",
        "Page 2",
        "Page 3",
        "Page 4",
        "Page 5",
        "Page 6",
        "Page 7",
        "Page 8",
        "Page 9",
        "AR 2021 Book 003-1 (Profil Perusahaan)",
        "Page 1",
        "Page 2",
        "Page 3",
        "Page 4",
        "Page 5",
        "Page 6",
        "Page 7",
        "Page 8",
        "Page 9",
        "Page 10",
        "Page 11",
        "Page 12",
        "Page 13",
        "Page 14",
        "Page 15",
        "Page 16",
        "Page 17",
        "Page 18",
        "Page 19",
        "Page 20",
        "Page 21",
        "Page 22",
        "Page 23",
        "Page 24",
        "Page 25",
        "Page 26",
        "Page 27",
        "Page 28",
        "Page 29",
        "Page 30",
        "Page 31",
        "Page 32",
        "Page 33",
        "Page 34",
        "Page 35",
        "Page 36",
        "Page 37",
        "Page 38",
        "Page 39",
        "Page 40",
        "Page 41",
        "Page 42",
        "Page 43",
        "Page 44",
        "Page 45",
        "Page 46",
        "Page 47",
        "AR 2021 Book 003-2 (Sumber Daya Manusia)",
        "Page 1",
        "Page 2",
        "Page 3",
        "Page 4",
        "Page 5",
        "Page 6",
        "Page 7",
        "Page 8",
        "Page 9",
        "Page 10",
        "Page 11",
        "Page 12",
        "AR 2021 Book 003-3 (Komposisi pemegang saham)",
        "Page 1",
        "Page 2",
        "Page 3",
        "Page 4",
        "Page 5",
        "Page 6",
        "AR 2021 Book 003-4 (Kronologis Pencatatan Saham)",
        "Page 1",
        "Page 2",
        "AR 2021 Book 003-5 (Akuntan Publik Independen)",
        "Page 1",
        "Page 2",
        "Page 3",
        "AR 2021 Book 004 (Analisa dan Pembahasan Manajemen)",
        "Page 1",
        "Page 2",
        "Page 3",
        "Page 4",
        "Page 5",
        "Page 6",
        "Page 7",
        "Page 8",
        "Page 9",
        "Page 10",
        "Page 11",
        "Page 12",
        "Page 13",
        "Page 14",
        "Page 15",
        "Page 16",
        "Page 17",
        "Page 18",
        "Page 19",
        "Page 20",
        "Page 21",
        "AR 2021 Book 005-1 (Tata Kelola Perusahaan)",
        "Page 1",
        "Page 2",
        "Page 3",
        "Page 4",
        "Page 5",
        "Page 6",
        "Page 7",
        "Page 8",
        "Page 9",
        "Page 10",
        "Page 11",
        "Page 12",
        "AR 2021 Book 005-2 (Direksi-Komisaris)",
        "Page 1",
        "Page 2",
        "Page 3",
        "Page 4",
        "Page 5",
        "Page 6",
        "Page 7",
        "Page 8",
        "Page 9",
        "Page 10",
        "Page 11",
        "Page 12",
        "Page 13",
        "Page 14",
        "Page 15",
        "Page 16",
        "Page 17",
        "Page 18",
        "Page 19",
        "Page 20",
        "Page 21",
        "Page 22",
        "Page 23",
        "Page 24",
        "Page 25",
        "Page 26",
        "Page 27",
        "Page 28",
        "Page 29",
        "Page 30",
        "Page 31",
        "Page 32",
        "Page 33",
        "Page 34",
        "Page 35",
        "Page 36",
        "Page 37",
        "Page 38",
        "AR 2021 Book 005-3 (Komite Audit)",
        "Page 1",
        "Page 2",
        "Page 3",
        "Page 4",
        "Page 5",
        "Page 6",
        "Page 7",
        "Page 8",
        "Page 9",
        "AR 2021 Book 005-4 (Sekretaris Perusahaan)",
        "Page 1",
        "Page 2",
        "Page 3",
        "Page 4",
        "Page 5",
        "Page 6",
        "Page 7",
        "Page 8",
        "Page 9",
        "Page 10",
        "AR 2021 Book 005-5 (Unit Audit Internal)",
        "Page 1",
        "Page 2",
        "Page 3",
        "Page 4",
        "Page 5",
        "Page 6",
        "AR 2021 Book 005-6 (Sistem Pengendalian Internal)",
        "Page 1",
        "Page 2",
        "Page 3",
        "Page 4",
        "Page 5",
        "Page 6",
        "Page 7",
        "Page 8",
        "AR 2021 Book 005-7 (Program Saham)",
        "Page 1",
        "AR 2021 Book 005-8 ( Whistleblowing)",
        "Page 1",
        "Page 2",
        "Page 3",
        "Page 4",
        "Page 5",
        "Page 6",
        "Page 7",
        "Page 8",
        "Page 9",
        "Page 10",
        "Page 11",
        "Page 12",
        "Page 13",
        "Page 14",
        "Page 15",
        "Page 16",
        "Page 17",
        "Page 18",
        "Page 19",
        "Page 20",
        "Page 21",
        "Page 22",
        "Page 23",
        "Page 24",
        "Page 25",
        "AR 2021 Book 006 (Tanggung Jawab Sosial - CSR)",
        "Page 1",
        "Page 2",
        "AR 2021 Book 007-1 (LAPORAN KEUANGAN KONSOLIDASIAN)",
        "Page 1",
        "AR 2021 Book 007-2 (Isi Laporan Keuangan)",
        "AR 2021 Book 008 (Tanggung Jawab Atas Laporan Tahunan)",
        "Page 1",
        "Page 2"
    ]


def test_flatten__cyclic_references():
    path = RESOURCE_ROOT / "crazyones.pdf"

    reader = PdfReader(path)
    assert len(reader.pages) == 1
    reader._flatten()

    # Make the first child point to the object itself.
    pages_object = reader.get_object(10)
    pages_object[NameObject("/Kids")][0].indirect_reference.idnum = 10
    reader.resolved_objects[(10, 0)] = pages_object

    with pytest.raises(expected_exception=PdfReadError, match=r"^Detected cyclic page references\.$"):
        reader._flatten()


def test_flatten__repeated_page_reference():
    writer = PdfWriter()
    writer.add_blank_page(width=612, height=792)
    pages = writer.root_object["/Pages"].get_object()
    pages[NameObject("/Rotate")] = NumberObject(180)
    kids = pages["/Kids"]
    kids[0].get_object()[NameObject("/Rotate")] = NumberObject(90)
    kids.append(kids[0])
    pages[NameObject("/Count")] = NumberObject(2)
    pdf = BytesIO()
    writer.write(pdf)
    pdf.seek(0)

    reader = PdfReader(pdf)

    assert len(reader.pages) == 2
    assert [page.rotation for page in reader.pages] == [90, 90]


@pytest.mark.parametrize("list_only", [False, True])
def test_flatten__repeated_page_reference_with_different_inheritance(list_only: bool):
    writer = PdfWriter()
    writer.add_blank_page(width=100, height=100)
    pages = writer.root_object["/Pages"].get_object()
    page = pages["/Kids"][0]
    del page.get_object()[NameObject("/MediaBox")]

    first_pages = writer._add_object(
        DictionaryObject(
            {
                NameObject("/Type"): NameObject("/Pages"),
                NameObject("/Kids"): ArrayObject([page]),
                NameObject("/Count"): NumberObject(1),
                NameObject("/MediaBox"): RectangleObject([0, 0, 100, 100]),
            }
        )
    )
    second_pages = writer._add_object(
        DictionaryObject(
            {
                NameObject("/Type"): NameObject("/Pages"),
                NameObject("/Kids"): ArrayObject([page]),
                NameObject("/Count"): NumberObject(1),
                NameObject("/MediaBox"): RectangleObject([0, 0, 200, 200]),
            }
        )
    )
    pages[NameObject("/Kids")] = ArrayObject([first_pages, second_pages])
    pages[NameObject("/Count")] = NumberObject(2)
    pdf = BytesIO()
    writer.write(pdf)
    pdf.seek(0)

    reader = PdfReader(pdf)
    reader._flatten(list_only=list_only)

    assert len(reader.pages) == 2
    assert reader.pages[0]["/MediaBox"] == RectangleObject([0, 0, 100, 100])
    assert reader.pages[1]["/MediaBox"] == RectangleObject([0, 0, 200, 200])


def test_flatten__depth_limit():
    writer = PdfWriter()
    page = writer._add_object(
        DictionaryObject(
            {
                NameObject("/Type"): NameObject("/Page"),
                NameObject("/MediaBox"): RectangleObject([0, 0, 100, 100]),
            }
        )
    )
    child = writer._add_object(
        DictionaryObject(
            {
                NameObject("/Type"): NameObject("/Pages"),
                NameObject("/Kids"): ArrayObject([page]),
                NameObject("/Count"): NumberObject(1),
            }
        )
    )
    writer.root_object[NameObject("/Pages")] = writer._add_object(
        DictionaryObject(
            {
                NameObject("/Type"): NameObject("/Pages"),
                NameObject("/Kids"): ArrayObject([child]),
                NameObject("/Count"): NumberObject(1),
            }
        )
    )

    with mock.patch("pypdf._doc_common.PAGE_TREE_MAX_DEPTH", 1), pytest.raises(
        LimitReachedError, match=r"^Maximum page tree depth reached: 2 > 1\.$"
    ):
        writer._flatten()


def test_flatten__entry_limit_for_reused_paths():
    writer = PdfWriter()
    child = writer._add_object(
        DictionaryObject(
            {
                NameObject("/Type"): NameObject("/Page"),
                NameObject("/MediaBox"): RectangleObject([0, 0, 100, 100]),
            }
        )
    )
    for _ in range(8):
        child = writer._add_object(
            DictionaryObject(
                {
                    NameObject("/Type"): NameObject("/Pages"),
                    NameObject("/Kids"): ArrayObject([child, child]),
                    NameObject("/Count"): NumberObject(2),
                }
            )
        )
    writer.root_object[NameObject("/Pages")] = child

    with mock.patch("pypdf._doc_common.PAGE_TREE_MAX_ENTRIES", 100), pytest.raises(
        LimitReachedError, match=r"^Maximum page tree entry limit reached: 101 > 100\.$"
    ):
        writer._flatten()


def test_flatten__pages_without_kids():
    # A malformed /Pages node may advertise "/Count 0" without providing any
    # /Kids entry. Flattening such a page tree used to raise a bare
    # ``KeyError: '/Kids'`` instead of being handled gracefully (#3811).
    reader = PdfReader(RESOURCE_ROOT / "crazyones.pdf")

    pages_object = reader.root_object["/Pages"]
    del pages_object["/Kids"]
    pages_object[NameObject("/Count")] = NumberObject(0)
    reader.flattened_pages = None

    assert len(reader.pages) == 0
    assert list(reader.pages) == []


def test_flatten__pages_with_null_kids():
    # A /Pages node whose /Kids resolve to a NullObject is treated the same as
    # a missing /Kids: no children rather than a crash (#3811).
    reader = PdfReader(RESOURCE_ROOT / "crazyones.pdf")

    pages_object = reader.root_object["/Pages"]
    pages_object[NameObject("/Kids")] = NullObject()
    pages_object[NameObject("/Count")] = NumberObject(0)
    reader.flattened_pages = None

    assert len(reader.pages) == 0
    assert list(reader.pages) == []


def test_flatten__pages_with_non_array_kids():
    # A /Pages node whose /Kids is neither an array nor null is malformed; we
    # raise a descriptive error instead of failing obscurely on iteration.
    reader = PdfReader(RESOURCE_ROOT / "crazyones.pdf")

    pages_object = reader.root_object["/Pages"]
    pages_object[NameObject("/Kids")] = NumberObject(0)
    reader.flattened_pages = None

    with pytest.raises(PdfReadError, match=r"^Expected /Kids to be an array, got NumberObject\.$"):
        list(reader.pages)


@pytest.mark.enable_socket
@pytest.mark.timeout(10)
def test_get_outline__cyclic_references(caplog):
    url = "https://github.com/user-attachments/files/24859044/circular_outline.pdf"
    name = "circular_outline.pdf"
    reader = PdfReader(BytesIO(get_data_from_url(url=url, name=name)))

    assert reader.outline == [
        {
            "/%is_open%": True,
            "/Page": reader.pages[0].indirect_reference,
            "/Title": "Bookmark A",
            "/Type": "/Fit"
        },
        {
            "/%is_open%": True,
            "/Page": reader.pages[0].indirect_reference,
            "/Title": "Bookmark B",
            "/Type": "/Fit"
        }
    ]
    assert caplog.messages[0].startswith("Detected cycle in outline structure for {")


@pytest.mark.enable_socket
@pytest.mark.timeout(10)
def test_get_outline__cyclic_references__nested_handling(caplog):
    url = "https://github.com/user-attachments/files/24859044/circular_outline.pdf"
    name = "circular_outline.pdf"
    writer = PdfWriter(clone_from=BytesIO(get_data_from_url(url=url, name=name)))

    nested_outline = DictionaryObject()
    writer._add_object(nested_outline)
    nested_outline.update({
        NameObject("/Title"): TextStringObject("Nested entry"),
        NameObject("/Parent"): writer.get_object(5),
        NameObject("/Dest"): ArrayObject([writer.pages[0].indirect_reference, NameObject("/Fit")]),
        NameObject("/Next"): writer.get_object(6),
    })
    writer.get_object(5)[NameObject("/First")] = nested_outline.indirect_reference
    writer.get_object(6)[NameObject("/First")] = nested_outline.indirect_reference

    assert writer.outline == [
        {
            "/%is_open%": True,
            "/Page": writer.pages[0].indirect_reference,
            "/Title": "Bookmark A",
            "/Type": "/Fit"
        },
        [
            {
                "/%is_open%": True,
                "/Page": writer.pages[0].indirect_reference,
                "/Title": "Nested entry",
                "/Type": "/Fit"
            },
            {
                "/%is_open%": True,
                "/Page": writer.pages[0].indirect_reference,
                "/Title": "Bookmark B",
                "/Type": "/Fit"
            }
        ],
        {
            "/%is_open%": True,
            "/Page": writer.pages[0].indirect_reference,
            "/Title": "Bookmark B",
            "/Type": "/Fit"
        },
        [
            {
                "/%is_open%": True,
                "/Page": writer.pages[0].indirect_reference,
                "/Title": "Nested entry",
                "/Type": "/Fit"
            }
        ]
    ]
    assert caplog.messages[0].startswith("Detected cycle in outline structure for {")


def test_xfa__decompression_limit():
    payload = b"A" * 100_0000
    compressed = FlateDecode.encode(payload, 9)

    writer = PdfWriter()
    writer.add_blank_page(width=72, height=72)

    stream = EncodedStreamObject()
    stream._data = compressed
    stream[NameObject("/Filter")] = NameObject("/FlateDecode")
    stream_reference = writer._add_object(stream)

    acro = DictionaryObject()
    acro[NameObject("/XFA")] = ArrayObject([TextStringObject("datasets"), stream_reference])
    writer.root_object[NameObject("/AcroForm")] = writer._add_object(acro)

    data = BytesIO()
    writer.write(data)
    data.flush()

    reader = PdfReader(data)
    with mock.patch("pypdf.filters.ZLIB_MAX_OUTPUT_LENGTH", 75_000), pytest.raises(
            expected_exception=LimitReachedError, match=r"^Limit reached while decompressing. 902 bytes remaining.$"
    ):
        _ = reader.xfa


def test_get_form_text_fields__mapping_name_without_partial_name():
    writer = PdfWriter()
    writer.add_blank_page(width=72, height=72)

    # A text field carrying only a mapping name (/TM) and no partial name (/T)
    # is tolerated when building the field tree, so reading the text fields by
    # short name should fall back to the qualified name instead of raising.
    field = DictionaryObject()
    field[NameObject("/FT")] = NameObject("/Tx")
    field[NameObject("/TM")] = TextStringObject("mappingname")
    field[NameObject("/V")] = TextStringObject("hello")

    acro = DictionaryObject()
    acro[NameObject("/Fields")] = ArrayObject([writer._add_object(field)])
    writer.root_object[NameObject("/AcroForm")] = writer._add_object(acro)

    data = BytesIO()
    writer.write(data)
    data.seek(0)

    reader = PdfReader(data)
    assert reader.get_form_text_fields() == {"mappingname": "hello"}


@pytest.mark.timeout(5)
def test_get_pages_showing_field__cyclic() -> None:
    writer = PdfWriter()

    dictionary1 = DictionaryObject()
    reference1 = writer._add_object(dictionary1)
    dictionary2 = DictionaryObject()
    reference2 = writer._add_object(dictionary2)
    dictionary3 = DictionaryObject({NameObject("/Parent"): reference2})
    reference3 = writer._add_object(dictionary3)
    dictionary1[NameObject("/Parent")] = reference3
    dictionary2[NameObject("/Parent")] = reference1

    with pytest.raises(
            expected_exception=LimitReachedError,
            match=r"^Detected cycle in /Parent hierarchy when retrieving value for key 'key'\.$"
    ):
        dictionary1.get_inherited("key")


@pytest.mark.timeout(5)
def test_get_named_destinations__cyclic(caplog) -> None:
    writer = PdfWriter()

    tree1 = TreeObject()
    reference1 = writer._add_object(tree1)
    tree2 = TreeObject()
    reference2 = writer._add_object(tree2)
    tree1[NameObject("/Kids")] = ArrayObject([reference2.indirect_reference])
    tree2[NameObject("/Kids")] = ArrayObject([reference1.indirect_reference])

    assert writer._get_named_destinations(tree=tree1) == {}
    assert caplog.messages == ["Detected cycle in destination tree."]


@pytest.mark.timeout(5)
def test_get_qualified_field_name__cyclic() -> None:
    writer = PdfWriter()

    dictionary1 = DictionaryObject()
    reference1 = writer._add_object(dictionary1)
    dictionary2 = TreeObject()
    reference2 = writer._add_object(dictionary2)
    dictionary1[NameObject("/Parent")] = reference2.indirect_reference
    dictionary2[NameObject("/Parent")] = reference1.indirect_reference

    with pytest.raises(
            expected_exception=LimitReachedError,
            match=r"^Detected cycle in /Parent hierarchy when retrieving qualified field name\.$"
    ):
        _ = writer._get_qualified_field_name(parent=dictionary1)


def test_build_outline_item__non_array_color(caplog):
    """A malformed outline item whose /C is not an array must not crash."""
    writer = PdfWriter()
    writer.add_blank_page(72, 72)

    item = DictionaryObject()
    writer._add_object(item)
    item.update({
        NameObject("/Title"): TextStringObject("Bad color"),
        NameObject("/Dest"): ArrayObject(
            [writer.pages[0].indirect_reference, NameObject("/Fit")]
        ),
        NameObject("/C"): NumberObject(5),  # should be an [r, g, b] array
    })
    outlines = DictionaryObject()
    writer._add_object(outlines)
    outlines.update({
        NameObject("/Type"): NameObject("/Outlines"),
        NameObject("/First"): item.indirect_reference,
        NameObject("/Last"): item.indirect_reference,
    })
    item[NameObject("/Parent")] = outlines.indirect_reference
    writer._root_object[NameObject("/Outlines")] = outlines.indirect_reference

    outline = writer.outline
    assert outline[0]["/Title"] == "Bad color"
    assert "/C" not in outline[0]
    assert any("outline color" in message for message in caplog.messages)

    # The same value is read again, unsanitised, while cloning the outline
    # during append, so that path must tolerate it too.
    target = PdfWriter()
    target.append(writer)


def test_get_page_in_node__cycle():
    writer = PdfWriter()
    page1 = DictionaryObject({
        NameObject("/Count"): NumberObject(100)
    })
    page2 = DictionaryObject({
        NameObject("/Count"): NumberObject(100)
    })
    page3 = DictionaryObject({
        NameObject("/Count"): NumberObject(100),
        NameObject("/Kids"): ArrayObject([writer._add_object(page1)])
    })
    page1[NameObject("/Kids")] = ArrayObject([writer._add_object(page2)])
    page2[NameObject("/Kids")] = ArrayObject([writer._add_object(page3)])
    writer.root_object[NameObject("/Pages")] = writer._add_object(page1)

    with pytest.raises(LimitReachedError, match=r"^Detected cycle in /Pages hierarchy when retrieving page\.$"):
        writer._get_page_in_node(42)


def test_get_outline__depth():
    writer = PdfWriter()
    outlines = [
        DictionaryObject({NameObject("/Title"): TextStringObject(f"Title{i}")})
        for i in range(3)
    ]
    writer.root_object[NameObject("/Outlines")] = DictionaryObject({
        NameObject("/First"): writer._add_object(outlines[0])
    })
    for index, outline in enumerate(outlines[:-1]):
        outline[NameObject("/First")] = writer._add_object(outlines[index + 1])
        outline[NameObject("/Next")] = writer._add_object(outlines[index + 1])
        writer._add_object(outline)

    assert writer._get_outline() == [
        {"/%is_open%": True, "/Page": NullObject(), "/Title": "Title0", "/Type": "/Fit"},
        [
            {"/%is_open%": True, "/Page": NullObject(), "/Title": "Title1", "/Type": "/Fit"},
            [
                {"/%is_open%": True, "/Page": NullObject(), "/Title": "Title2", "/Type": "/Fit"}
            ],
            {"/%is_open%": True, "/Page": NullObject(), "/Title": "Title2", "/Type": "/Fit"}
        ],
        {"/%is_open%": True, "/Page": NullObject(), "/Title": "Title1", "/Type": "/Fit"},
        [
            {"/%is_open%": True, "/Page": NullObject(), "/Title": "Title2", "/Type": "/Fit"}
        ],
        {"/%is_open%": True, "/Page": NullObject(), "/Title": "Title2", "/Type": "/Fit"}
    ]

    with pytest.raises(expected_exception=LimitReachedError, match=r"^Maximum outline depth reached: 101 > 100\.$"):
        writer._get_outline(depth=99)


def test_get_outline__entry_count():
    writer = PdfWriter()
    outlines = [
        DictionaryObject({NameObject("/Title"): TextStringObject(f"Title{i}")})
        for i in range(10)
    ]
    writer.root_object[NameObject("/Outlines")] = DictionaryObject({
        NameObject("/First"): writer._add_object(outlines[0])
    })
    for index, outline in enumerate(outlines[:-1]):
        outline[NameObject("/First")] = writer._add_object(outlines[index + 1])
        outline[NameObject("/Next")] = writer._add_object(outlines[index + 1])
        writer._add_object(outline)

    with mock.patch("pypdf._doc_common.OUTLINE_MAX_ENTRIES", 1000), \
            pytest.raises(
                expected_exception=LimitReachedError, match=r"^Maximum outline entry limit reached: 1001 > 1000\.$"
            ):
        writer._get_outline()
