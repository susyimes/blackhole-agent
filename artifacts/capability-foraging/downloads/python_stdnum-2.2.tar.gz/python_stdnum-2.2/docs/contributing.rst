.. include:: ../CONTRIBUTING.md
